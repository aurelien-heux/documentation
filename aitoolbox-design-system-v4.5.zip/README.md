# AIToolbox design system · v4.5.0

Everything validated in the AIToolbox design system, in one package: palette M · Night & neon on Material Design 3, for Angular Material 21 (M2 theme) and 22 (M3 theme).

## Contents

| Folder | What it is | Start with |
|---|---|---|
| `brand/` | Production assets and code: logos (SVG, once / loop SVG and GIF, PNG), favicon and app icon, loaders and progress indicators, state marks, feature marks (Sweep, Docs, Environments, Chatbot, Notifications: static, once and loop SVGs and GIFs, lockups and PNGs in `feature-marks/<feature>/<light|dark>/`), `css/tokens.css`, `css/design-tokens.json`, `css/loading-states.css`, Angular theme files, BNPP Type font. | `brand/README.md` |
| `design-system/` | The rules: principles and colour roles (`README.md`), `tokens.json`, per-component rules with Angular M2 / M3 tokens (`component-rules.md`), the Angular map (`angular-material.md`), one page per component (`components/`), asset rules (`assets/`), and the domain reference with the design-system rules DSR / INV-DS / DEC-DS (`domain-reference.md`, section 14). | `design-system/README.md` |
| `storybook/` | A static storybook of the 35 components: open `storybook/index.html` in a browser; light / dark switch in the header. Each component is also a standalone page in `storybook/components/<Name>/preview.html` with its README. | `storybook/index.html` |
| `mockups/` | The validated boards of the Design canvas as standalone HTML pages plus a 2× PNG of each: colour roles, type and shape, components, logo, favicon, chatbot mark, loaders, progress, state marks, feature marks, and the application screens (desktop light / dark, drawer closed, dialog / date picker / dropdown open, phone), the header spec (states and the panels it opens), where the privacy / cookie links live, and the feedback feature configurable per feature (proposal). | `mockups/index.html` |

## Key decisions (v4.5.0)

- **Palette M · Night & neon** — deep violet primary (#35307E light / #C4C0FF dark), neon-green tertiary for the one action that starts work (#006C44 / #00F29E), light-teal `ai` for AI features only (#80D5D4), violet-tinted night surfaces in dark.
- **Light surfaces** — page and cards near-neutral (#FDF8FD / #FFFFFF); containers a pale purple (#FAF4FF · #F8F1FF · #F2EBFA · #ECE5F4); the navigation frame — top app bar, drawer, rail, bottom bars — on `nav-container` #EDE4FF with `nav-active` #D4D0F9 for the selected item; a 2 px gap of `surface` between header and drawer; no border on the drawer.
- **App header** — logo · a search-or-ask field centred on the bar (Ask sends the text to the assistant) · assistant (Chatbot mark: idle, typing dots, reply dot) · notifications (the bell mark with an error count badge) · help · user chip (avatar, name, role → user menu). No environment chip; the drawer no longer carries the assistant or the user block.
- **Privacy and cookies** — the drawer footer carries Privacy · Cookies · Terms · version; with the drawer closed, a Privacy destination in the rail opens the same links. Never in the header.
- **Shape** — 16 px is the ceiling on every rectangle; full radius only for circles.
- **Type** — BNPP Type 500 for UI (display, headline, title, label), Open Sans for body, Open Sans 600 for code and identifiers.
- **Logo family** — night box (#0D0B14) with a white prompt and neon cursor on light, lavender box on dark; AI badge in light teal; lockups centred on the visible mark.
- **Feature marks** — Sweep (broom & sparkle), Docs (shelf), Environments (promotion), Chatbot (brace box) and Notifications (bell): free-standing, design-system colours only; each with a *once* entrance (plays one time, holds the mark) and a different *loop* working motion; SVG, PNG and GIF per feature, then light / dark.
- **Feedback** — state marks (badge 24–40 px, circle 56–96 px, tile 18–20 px), the Constructor brand loader, pen-orbit / guide-line progress skins.
- **Angular** — `theme.m2.scss` (v21) and `theme.m3.scss` (v22) both compile cleanly; `.dt-nav` on navigation surfaces, `.dt-run`, `.dt-ai`, `.dt-chip-*` for the extended roles.

Fonts: BNPP Type is included (`brand/fonts/`, `design-system/fonts/`, `storybook/fonts/`); Open Sans and Manrope load from Google Fonts.

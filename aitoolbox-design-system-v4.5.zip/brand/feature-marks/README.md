# Feature marks · Sweep, Docs, Environments, Chatbot

Marks for the AIToolbox features, separate from the product logo. One folder per feature, then `light/` and `dark/`, like the rest of the brand package. Open `index.html` for a live preview (with a button to replay the single runs).

- `light/` — colours for **light backgrounds**: deep violet (primary #35307E), teal (ai 50 #278383), green (tertiary 60 #00A56B).
- `dark/` — colours for **dark backgrounds**: lavender (primary 70 #A6A2F8), light teal (ai 80 #80D5D4), neon green (tertiary #00F29E).
- Chatbot keeps its validated colours: deep violet #35307E with a #008857 cursor on light, lavender #C4C0FF with a neon #00F29E cursor on dark.

Colours are fixed in each file (no automatic switching), so you choose the file that matches the surface. All backgrounds are transparent except the GIFs.

| Feature | Mark | Single run | Cycling |
|---|---|---|---|
| **Sweep** · agentic SDLC pipeline | Broom & sparkle | 1.6 s: the broom winds up, sweeps across and settles; two sparkles pop where it passed | 2.8 s: the sparkles fade as the broom winds up, it sweeps, they pop back |
| **Docs** · documentation | Shelf: three books, the last one leaning | 1.5 s: the books slide up onto the shelf in turn; the last lands upright, then leans | 3.0 s: the first two books lift in turn; the leaning one straightens and falls back |
| **Environments** · environment management | Promotion: dev → staging → prod | 1.8 s: the path draws, each node pops, the check draws on prod | 2.8 s: a release token travels dev → staging → prod; nodes pulse; the check redraws |
| **Chatbot** · assistant | Brace box `{ >_ }`: one continuous outline | 1.8 s: the outline draws itself, the chevron follows, the cursor appears and blinks once | 2.4 s (responding): the chevron nudges, the cursor types out and back, then blinks twice |

## Files — in `<feature>/light/` and `<feature>/dark/`

| File | Use |
|---|---|
| `<feature>.svg` | Static mark, 64 × 64 viewBox. Apps, web, PowerPoint (still image). |
| `<feature>-run.svg` | Plays once and ends on the static mark: when the feature opens or an action completes. |
| `<feature>-loop.svg` | Cycles while work is in progress; each cycle starts and ends on the static mark. |
| `<feature>-lockup.svg` | Mark + "AIToolbox" label + feature name; text outlined (Manrope 700 / 800), no font needed. |
| `<feature>-<size>.png` | Static mark, transparent: 16, 24, 32, 48, 64, 128, 256, 512 px (Chatbot from 24 px). Google Slides, older Office, wikis, tool avatars (Teams, Slack, GitLab, Jira), email. |
| `<feature>-lockup@2x.png` | Lockup at 2×, transparent: title slides, document headers, release notes. |
| `<feature>-run.gif` / `<feature>-loop.gif` | 256 px on the surface colour: motion where SVG animation does not play (PowerPoint, Google Slides, Confluence, READMEs, chat posts, email). The run plays once. |

## Motion

- Single run: once, when the feature opens or an action completes (Sweep run finished, docs page loaded, promotion done, assistant opened). Always ends on the static mark.
- Cycling: while work is in progress (pipeline running, search indexing, deployment ongoing, assistant responding). Can stop at the end of any cycle without a jump.
- CSS inside the SVG: transform, opacity and stroke-dashoffset only; easing `cubic-bezier(.2, 0, 0, 1)` (MD emphasized). Under `prefers-reduced-motion: reduce` the static mark shows. Tools that ignore CSS animation (PowerPoint) also show the static mark.
- At most one cycling mark per screen; never run and loop on the same mark at once.

```html
<img src="sweep/light/sweep.svg" width="24" height="24" alt="">                       <!-- navigation -->
<img src="sweep/light/sweep-loop.svg" width="40" height="40" alt="Sweep running">     <!-- in progress -->
<picture>
  <source srcset="docs/dark/docs.svg" media="(prefers-color-scheme: dark)">
  <img src="docs/light/docs.svg" width="32" height="32" alt="Docs">
</picture>
```

```js
img.src = img.src.split('?')[0] + '?r=' + Date.now();   // replay a single run
```

## Rules

- The marks identify the features (navigation drawer and rail items, feature headers, empty states, the docs site, release notes). The AIToolbox logo stays the product brand; never place the two marks side by side as equals.
- Sizes: 16 px minimum (Chatbot: 24 px minimum — bubble avatar 24, assistant panel header 32, launcher 48); 24 px in navigation; 32–48 px in headers; 64 px and up for empty states and splash.
- Never recolour: pick the `light/` or `dark/` file for the background; on colour or photos, place the mark on a `surface` tile.
- Lockup: use the supplied files, don't retype.

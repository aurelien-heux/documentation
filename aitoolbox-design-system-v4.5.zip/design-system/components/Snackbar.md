# Snackbar
Brief confirmation at the bottom of the screen: `inverse-surface` ground, `inverse-on-surface` text, one optional action in `inverse-primary`, optional close icon.
- 48 px single line, 68 px two lines; radius-xs; elevation-3; 4–10 s then auto-dismiss.
- Never use it for errors that need a decision (use a dialog) and never stack more than one.
- **Angular Material:** `MatSnackBar`. M2 hard-codes a dark container: set `--mdc-snackbar-container-color` to `inverse-surface` and `--mdc-snackbar-supporting-text-color` to `inverse-on-surface` (done in `theme.m2.scss`); M3 follows `--mat-sys-inverse-surface` on its own. Leading 24 px state mark (StateMark A, badge in `inverse-primary` on the inverse surface). Full map and theme files: `angular-material.md`.

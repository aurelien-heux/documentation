# NavigationRail
80 px wide vertical navigation for tablet and desktop: menu button, optional FAB, then 3–7 destinations.
- Active: 56×32 px `nav-active` pill; labels in label-medium under the icon.
- The rail sits on `nav-container` (violet band in light) with no border, like the drawer; it is the closed state of the drawer (menu button on top); it expands into a NavigationDrawer when there's room.
- **Angular Material:** No Angular Material equivalent — a `mat-sidenav mode="side"` at 80 px with `mat-icon-button`s and labels; expand into the NavigationDrawer on wide screens. Full map and theme files: `angular-material.md`.

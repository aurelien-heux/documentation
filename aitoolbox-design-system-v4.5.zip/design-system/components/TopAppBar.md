# TopAppBar
- **Small** 64 px: leading navigation icon, title-large, up to three trailing icon buttons. On `nav-container`, the same colour as the NavigationDrawer, separated from it by a 2 px gap of the page `surface` (no outline); with a drawer the menu button sits at the top of the drawer, not in the bar; search field on `surface-container-lowest` (light) / `surface-container-high` (dark), avatar on `nav-active`.
- **Medium / Large** 112 / 152 px: the title drops under the icons in headline-medium / headline-large and collapses to small on scroll.
- Icon buttons are 40 px in a 48 px slot; titles truncate with an ellipsis, never wrap in the small bar.
- **Angular Material:** `mat-toolbar` — never `color="primary"`. Add `class="dt-nav"`: both theme files set its `container-background-color` to `nav-container`. Medium / large bars are a custom header, not a toolbar row. Full map and theme files: `angular-material.md`.

## App header (AIToolbox shell)
Left to right: **logo** · **search-or-ask field, centred on the bar** (600 × 44, radius 16; ⌘K focuses it; Enter searches; the **Ask** chip — `ai-container`, Chatbot mark — sends the text to the assistant and opens the assistant block) · **assistant** icon button with the Chatbot mark (idle · typing dots while it writes in the background · tertiary dot when a reply waits) · **notifications**: the Notifications feature-mark bell (no dot) with an `error` count badge (1–9, 9+, 99+), ringing once when one arrives · **help** · divider · **user chip** (avatar on `nav-active`, name title-small, role body-small, chevron → user menu).
- No environment chip: the environment is a page filter.
- Under 1200 px the user chip shows the avatar only.
- The drawer carries neither the assistant entry nor the user block; on phones the top bar is logo · bell · avatar and the assistant is a NavigationBar destination.

# TopAppBar
- **Small** 64 px: leading navigation icon, title-large, up to three trailing icon buttons. On `nav-container`, the same colour as the NavigationDrawer, separated from it by a 2 px gap of the page `surface` (no outline); with a drawer the menu button sits at the top of the drawer, not in the bar; search field on `surface-container-lowest` (light) / `surface-container-high` (dark), environment chip and avatar on `nav-active`.
- **Medium / Large** 112 / 152 px: the title drops under the icons in headline-medium / headline-large and collapses to small on scroll.
- Icon buttons are 40 px in a 48 px slot; titles truncate with an ellipsis, never wrap in the small bar.
- **Angular Material:** `mat-toolbar` — never `color="primary"`. Add `class="dt-nav"`: both theme files set its `container-background-color` to `nav-container`. Medium / large bars are a custom header, not a toolbar row. Full map and theme files: `angular-material.md`.

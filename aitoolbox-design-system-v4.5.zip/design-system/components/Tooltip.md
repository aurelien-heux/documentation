# Tooltip
- **Plain** — 24 px high, label-medium, `inverse-surface`; appears on hover/focus after 500 ms. Labels an icon button; never holds information that isn't available another way.
- **Rich** — title + supporting text, optional action, `surface-container-high` with elevation-2, radius-md; opens on hover or on an info icon's click, stays while hovered.
- **Angular Material:** `matTooltip` (plain). M2: `--mdc-plain-tooltip-container-color` = `inverse-surface`; M3: `--mat-sys-inverse-surface`. Rich tooltips are a `mat-card` in a CDK overlay. Full map and theme files: `angular-material.md`.

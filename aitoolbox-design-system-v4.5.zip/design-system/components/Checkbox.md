# Checkbox
18 px box, radius 2 px, inside a 44–48 px touch target with a 12 px gap to its label.
- Unchecked: 2 px `on-surface-variant` border. Checked / indeterminate: `primary` fill with an `on-primary` mark. Error: `error` fill. Disabled: on-surface at 38 %.
- Use for independent options and multi-select lists; for a single on/off setting use a Switch.
- **Angular Material:** `mat-checkbox color="primary"` (M2) / default (M3 uses `--mat-sys-primary`). `indeterminate` for partial table selections. Full map and theme files: `angular-material.md`.

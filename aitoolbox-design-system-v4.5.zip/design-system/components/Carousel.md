# Carousel
Horizontally scrolling items with the multi-browse layout: one large item, one medium, small items at the edge, 8 px gaps, radius-lg (16 px).
- Items are `*-container` tones or images; the item title sits bottom-left in title-medium.
- Use for browsing tool galleries or templates; for lists of equal items use List or a grid of Cards.
- **Angular Material:** No Angular Material equivalent — CSS `scroll-snap` over `mat-card` items; the CDK `ListKeyManager` for keyboard navigation. Full map and theme files: `angular-material.md`.

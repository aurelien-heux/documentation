# NavigationBar
Phone bottom navigation, 80 px, 3–5 destinations on `nav-container` (violet tint in light; `class="dt-nav"` on the `mat-toolbar`).
- Active destination: 64×32 px `nav-active` pill behind the icon, label in `on-surface` at weight 600; inactive icons and labels in `on-surface-variant`.
- Badges sit on the icon. On tablet and desktop the same destinations move to the NavigationRail.
- **Angular Material:** No Angular Material equivalent — a bottom `mat-toolbar` with `mat-button`s, or `mat-tab-nav-bar` with icons. The active pill is a class on `secondary-container` in both. Full map and theme files: `angular-material.md`.

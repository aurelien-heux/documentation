# Slider
Material 3 slider: 4 px track in `primary-container`, active segment in `primary`, a 4×24 px handle, value label in `inverse-surface` while dragging.
- Continuous or discrete (tick marks every step); range sliders have two handles.
- Use for values with a meaningful visual range (CPU limit, replica count 1–20). For exact numbers pair it with a text field or use the field alone.
- **Angular Material:** `mat-slider` (`discrete`, `showTickMarks`; two `matSliderThumb`s for a range). `color="primary"` (M2) / `--mat-sys-primary` (M3). Full map and theme files: `angular-material.md`.

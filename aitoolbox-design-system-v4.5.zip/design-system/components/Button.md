# Button

Material 3 buttons at 40 px, radius-lg (16 px — never full-round), label-large. Five emphasis levels plus the neon-green "run" button.

- **Filled (primary)** — the one decision on a screen: Save, Create, Open.
- **Tonal (secondary-container)** — secondary actions beside a filled one: Filter, Cancel-but-visible.
- **Elevated** — filled-like emphasis on a patterned or tinted ground; elevation-1.
- **Outlined / Text** — low emphasis; Text is the dialog dismiss.
- **Run (tertiary)** — the single action that starts work: Run, Deploy, Apply. At most one per screen, leading play icon, never inside a dialog.
- **Disabled** — on-surface at 12 % fill / 38 % text.

Horizontal padding is space-6 (24 px); with a leading icon the left padding drops to 16 px. Icon-only buttons are 40 px circles and need an `aria-label`. Destructive actions are Text buttons in `error`, never a filled red.
- **Angular Material:** `mat-flat-button` = filled, `mat-raised-button` = elevated, `mat-stroked-button` = outlined, `mat-button` = text. Tonal: M2 has none — `mat-flat-button color="accent"` on the `lighter` hue (set in `theme.m2.scss`); M3: `mat.button-overrides` with `secondary-container`. Run: `class="dt-run"` in both. Destructive: `mat-button color="warn"`. Full map and theme files: `angular-material.md`.

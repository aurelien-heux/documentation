# NavigationDrawer
360 px (300 px shown) drawer on `nav-container` (violet band #EDE4FF in light — darker than the pale containers — night tone 10 in dark), 12 px inset, items 56 px at radius-lg (16 px); hover and active share that shape.
- The menu button (open / collapse to the rail) is the first row of the drawer, aligned with the item icons; a 2 px gap of the page `surface` separates the drawer from the top app bar; no border on the content side.
- Active item: `nav-active` (#D4D0F9 in light, secondary-container in dark) with `on-secondary-container`; others `on-surface-variant`. Trailing counts in label-medium.
- Section headers in label-medium `on-surface-variant` after an inset divider. Modal on phones (with scrim), standard on desktop.
- **Footer** under Settings: *Privacy · Cookies · Terms · version* in body-small `on-surface-variant`, links underlined, opening the policies in a new tab — the cookie policy stays one click away on every page (never in the top app bar).
- **Keyboard and screen reader:** the active item has `aria-current="page"`, the `nav-active` pill and a 3 px `primary` leading bar (`dt-nav-active`), because the pill alone is 1.2:1 on the band.
- **Angular Material:** `mat-sidenav-container` + `mat-sidenav` (`mode="over"` phones, `"side"` desktop) holding a `mat-nav-list`. Add `class="dt-nav"` on the `mat-sidenav`: both theme files set its `container-background-color` to `nav-container` (side sheets, also `mat-sidenav`, stay neutral). Shape `0 16px 16px 0` via `mat.sidenav-overrides`. Full map and theme files: `angular-material.md`.

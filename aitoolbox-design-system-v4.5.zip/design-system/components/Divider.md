# Divider
1 px line in `outline-variant`. Full-width between sections, inset 16 px between list items that share a leading element; vertical between side-by-side controls.
- Prefer spacing or a surface-container change over a divider; use dividers where items would otherwise merge (dense lists, tables).
- **Angular Material:** `mat-divider` (`[inset]`, `[vertical]`). Colour from `foreground.divider` (M2) / `--mat-sys-outline-variant` (M3). Full map and theme files: `angular-material.md`.

# Chatbot

Marks reserved for the assistant avatar. They are deliberately not the brand mark, so a user can tell the AI from the product.

- `chatbot-brace-box-*` — the `{ >_ }` brace box drawn as **one continuous outline**: left brace, top brace and right brace flow into each other through 9-unit corners, with the hooks at the bottom — a speech bubble with three brace tips. Deep violet on light, tone-80 lavender on dark, neon-green cursor. No handle, no separate cap.

Use at 24 px as the bubble avatar, 32 px in the assistant panel header, 48 px in the assistant launcher. Never below 24 px, never recoloured, never as the app logo. The brand mark (toolbox prompt) stays the product's; this one is the assistant's.

Files: `brand/feature-marks/chatbot/light/` and `/dark/` — `chatbot.svg`, `chatbot-once.svg` (entrance, plays one time: the outline draws itself, the chevron follows, the cursor blinks once; 1.8 s), `chatbot-loop.svg` (repeats while the assistant responds: the chevron nudges, the cursor types out and back, then blinks; 2.4 s), `chatbot-lockup.svg`, PNGs 24–512 px, once / loop GIFs. The Chatbot is part of the feature-mark family; see `brand/feature-marks/README.md`.

# AIToolbox

The design system for AIToolbox, an IT platform of utilities for infrastructure and development teams. It is Material Design 3 with a AIToolbox palette, type pairing and a small set of rules that keep the product calm in daily use and unmistakable when something matters.

## Principles

1. **Calm chrome, loud signals.** In light, the page surface and cards are near-neutral, containers (dialogs, menus, pickers, panels) are a pale purple and the navigation frame — top app bar and drawer together — is the one deeper violet band; in dark everything sits on night tones with a deep-violet primary used as tints, so the neon-green Run, the teal AI badge and the status colours are the brightest things on screen.
2. **One colour, one meaning.** Deep violet decides, violet-grey groups and filters, neon green executes, teal is AI (the features and the brand’s own tag), green/amber/red are health. A colour is never borrowed for decoration.
3. **Dense but breathable.** Ops screens hold a lot; the 4 px grid, 56 px fields and 40 px buttons keep them scannable without becoming cramped.
4. **Data looks like data.** Keys, paths, IDs, timestamps and log output are set in Open Sans at weight 600 and, where it helps, on a container tone, so the eye can tell data from prose without a monospace face.
5. **Accessible as built.** Every text/ground pair in the tokens clears 7:1 in both themes; colours that must be told apart also differ in lightness.

## Colour

Dark is the first-class theme — "night" — and light is its daytime counterpart, not an inversion. Both are generated from Material's HCT tonal palettes (Tonal Spot scheme) from three seeds: **deep violet** #1E1B4B for the primary (hue 288, chroma 46; the secondary is the same hue at chroma 24), **neon green** #00F5A0 for the tertiary (hue 161, chroma 71) and **night** #0D0B14 for the neutrals (hue 296): chroma 12 in dark, so night surfaces are visibly violet; in light the page surface, the lowest container (cards) and the outlines drop to chroma 4 (near-neutral), while the four containers are a light purple (chroma 10) one step lighter than Material's — tones 97 / 96 / 94 / 92 (#FAF4FF · #F8F1FF · #F2EBFA · #ECE5F4) — and the navigation is the deepest light surface, `nav-container` #EDE4FF (chroma 20, tone 92), with `nav-active` #D4D0F9 for its active item. Tuning: light roles sit at tone 25 (primary) and 40 (tertiary, a readable emerald on white) with containers at 90 and on-container text at tone 10, outlines at tone 50/80; dark surfaces are night — surface at tone 6 with containers stepping 4 → 22 — with the primary at tone 80 (lavender) and the tertiary at tone 85, the full neon, where it reads perfectly.

### Roles and what they do

| Role | Use for | Never for |
|---|---|---|
| `primary` (deep violet) | filled buttons, active nav, selected tab, focused field, switches on, links, “Toolbox” in the wordmark (the box of the logo is `logo-box`) | status, decoration |
| `secondary-container` (violet-grey tint) | tonal buttons, filter chips, nav-rail active pill, env badges, avatars | emphasis |
| `tertiary` (neon green) | the one action that starts work: Run, Deploy, Apply — max one filled per screen; the cursor in the logo | dialogs, destructive actions, status (health green is `success`, hue 145, always with its ✓ tile) |
| `ai` (light teal, the same tone 80 in both themes; only `ai-container` changes) | AI suggestion cards, Explain/Generate actions, AI chips — always with the sparkle icon, so a teal tint is never read as a selection — and the AI badge on the mark | chrome, navigation, non-AI buttons |
| `success` / `warning` / `error` | health chips, log levels, badges, validation | brand, decoration |
| `surface-container-*` | tonal layering instead of shadows | — |

Surfaces layer tonally: page `surface` → panels `surface-container-low` → app bar `surface-container` → dialogs and menus `surface-container-high`. Shadows (`elevation-*`) appear only where Material asks for them: elevated buttons and cards, FAB, dialogs, snackbars.

### Contrast

`on-surface-variant` is the lightest "muted" text allowed on `surface` (8.9:1 light, 9.7:1 dark). `outline` is for borders only, never text. White text sits only on `primary`, `tertiary`, `error`, `success` and `warning`; `ai` is light teal in both themes and takes `on-ai` (dark teal #003737); everything else uses the matching `on-*-container`.

## Typography

- **UI family: BNPP Type** (weight 500) for every display, headline, title and label style: app bars, buttons, chips, navigation, dialog titles.
- **Body family: Open Sans** (400, 600 for emphasis) for body-large/medium/small, and for code, keys, paths, IDs and log output (set at 600 so data reads apart from prose). There is no monospace face in the system.

BNPP Type ships as a font file in `fonts/` and is declared by `tokens.css`. Open Sans loads from Google Fonts: `https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&display=swap`. BNPP Type is supplied in one weight, so UI emphasis comes from size and colour, not from bold. The wordmark stays the outlined SVG in `assets/Logos`.

## Shape

The Material shape scale with a **16 px ceiling**: `radius-lg` (16) is the largest corner on any rectangle — buttons, segmented buttons, search bars, navigation items (hover and active), dialogs, bottom and side sheets, pickers, the large FAB; `radius-md` (12) for cards, tables and panels; `radius-sm` (8) for chips; `radius-xs` (4) for text fields, menus, tooltips and snackbars. `radius-xl` is pinned to 16 px and `radius-full` is reserved for circles (avatars, badges, radio, switch, icon-button state layers) — never for a button or a pill. The logo's box corner is 10/64 of its height, which lands on `radius-lg` at 64 px.

## Spacing

A 4 px grid. Inside components: `space-2` between chips and buttons, `space-4` for field and card padding, `space-6` for dialog padding and filled-button horizontal padding. Between things: `space-6` between fields in a form, `space-8` between page sections, `space-16` side gutters at desktop (16 px minimum on phones).

## Iconography

Outlined icons, 2 px stroke, 24 px grid (18 px inside buttons and chips, 22 px in app bars). Icons take the colour of the text next to them. Never emoji as icons. Icon-only buttons carry an `aria-label`.

## Logo

The mark is the **toolbox prompt**: a toolbox silhouette with a squared handle, holding a terminal `>_` with a neon-green cursor. The box is **night** — `logo-box` #0D0B14, the seed of the palette, with a white `>` (`on-logo-box`) and the full neon cursor (`logo-cursor` #00F29E) on light backgrounds; on dark backgrounds the box is lavender (`primary` #C4C0FF) with a night `>` and an emerald cursor (#006C44). The night box is the one place the raw seed appears; UI surfaces use the tonal `surface-*` roles. The mark carries the **AI badge**: a light-teal `ai` tile (#80D5D4 in both themes) with “AI” in `on-ai` (#003737) on the box's top-right corner, cut out of the silhouette so the two never touch (from 24 px; the favicon and app icon use the plain mark). The wordmark is “AIToolbox” in Manrope 800, “AI” in `on-surface` and “Toolbox” in `primary`. In prose the name is one word, AIToolbox. Alignment: the `>_` is centred in the box on one baseline; in the horizontal lockup the capitals of “AIToolbox” are as tall as the box and centred vertically on the whole mark (badge to box bottom); in the stacked lockup the mark and the wordmark are centred on one vertical axis. Use the horizontal lockup by default, the stacked lockup in square slots, the mark alone from 24 px up. Below 32 px the favicon glyph (the `>_` on a night tile) replaces the mark. Clear space is a quarter of the mark's height on every side. Do not rotate, outline, add gradients, or set the wordmark in another face. All files are in `assets/Logos`; the chatbot avatar is the brace box in `assets/Chatbot` — `{ >_ }` as one continuous outline — never the brand mark.

## State marks

Feedback components carry a state mark that is the logo's construction with the state in the badge instead of "AI": the toolbox never changes (the night `logo-box` with its `>_`), the corner badge takes the state role and a symbol — ✓ success, i info, ! warning, ✕ error. Logo, loader and states share one grammar. The same mark is dressed by size: **alone** on a surface at 24–40 px (snackbars, popin headers, inline alerts); **in a circle** at 56–96 px (empty states, table-, panel- or popin-level errors: disc in the state role, dark on light and light on dark, toolbox reversed, badge in the state container); as a **tile glyph** at 18–20 px (chips, table cells, dropdown options: the `>` and the reply on a tile, since the badge does not survive that small). Loading is not a state: the slot shows the pen-orbit ring around the plain mark and, when the request resolves, takes the state in place — warning after a timeout, error with Retry on failure. Info is the one status that uses `primary`. No entrance animation. Full table in `assets/States`.

## Motion

Material emphasized easing `cubic-bezier(0.2, 0, 0, 1)` for state changes; standard durations 150 / 300 / 500 ms. The brand loader is "Constructor" — the AI builds the toolbox: the AI badge arrives alone, dashed construction guides appear, a teal pen leaves the badge, draws the toolbox in one trip and goes home, then the violet toolbox becomes solid and the badge pulses once (4.4 s loop with a clean cut, or play once for a splash). Nothing is ever clipped: the badge, guides and pen all sit inside the loader's frame. The in-screen indicators belong to the same family — the circular indicator is a violet arc led by the teal pen (pen orbit), the linear track is a dashed construction guide the bar runs along (guide line), a known-value operation is the pen drawing the box until it fills (Constructor determinate), and the working dots are green when a command runs and teal when a model thinks. Material roles and sizes are unchanged; these are skins for `mat-progress-spinner` and `mat-progress-bar`. Everything animated respects `prefers-reduced-motion`.

## Status and logs

Health chips are `*-container` fills with `on-*-container` text and a solid dot; log levels colour only the level word (`success` INFO, `warning` WARN, `error` ERR), Open Sans 600. The brand colours never appear in a status column.

## Writing

Short, specific, active. Buttons say what happens ("Create workspace", "Run pipeline"). Errors say what went wrong and how to fix it. Technical identifiers are shown verbatim, Open Sans 600.

## Angular Material

The product is built on Angular Material. `angular-material.md` is the engineering companion: the version timeline (M2 theming on 21 today, `mat.theme` on 22), `angular/theme.m2.scss` and `angular/theme.m3.scss` generated from these tokens, `angular/mat-sys-bridge.css`, the role-to-slot mapping, and every Angular Material component mapped to its AIToolbox component with M2 and M3 notes. `component-rules.md` lists every component's design rules with the Angular Material tokens (same names under M2 and M3) and their AIToolbox values. Each component README ends with its Angular Material line.

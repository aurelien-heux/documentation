# Chatbot

Marks reserved for the assistant avatar. They are deliberately not the brand mark, so a user can tell the AI from the product.

- `chatbot-brace-box-*` — the `{ >_ }` brace box drawn as **one continuous outline**: left brace, top brace and right brace flow into each other through 9-unit corners, with the hooks at the bottom — a speech bubble with three brace tips. Deep violet on light, tone-80 lavender on dark, neon-green cursor. No handle, no separate cap.

Use at 24 px as the bubble avatar, 32 px in the assistant panel header, 48 px in the assistant launcher. Never below 24 px, never recoloured, never as the app logo. The brand mark (toolbox prompt) stays the product's; this one is the assistant's.

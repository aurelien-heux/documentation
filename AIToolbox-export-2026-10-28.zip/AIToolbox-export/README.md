# AIToolbox · export bundle

Snapshot of 28 October 2026. Everything in this folder was taken from the latest published versions.

| Folder | Content | Source |
|---|---|---|
| `design-system/` | Design system: README, tokens (`tokens.json`, `tokens.css`), per-component rules, Angular Material themes (M2 / M3), breakpoints, component READMEs and HTML previews, BNPP Type font, brand assets (logos, favicon, app icon, state marks, chatbot mark) as SVG | Design System artifact "AIToolbox" (version 1793168006-6cbc) |
| `canvas/` | Design canvas "AIToolbox design system": 37 boards (`.dc.html`) on two pages, Design system and Prototypes, plus `canvas.json` (layout, titles, pages) | Design artifact (version 1793173366-5f9d) |
| `project-docs/` | Project knowledge docs: domain reference, component rules, feature marks, architecture components, architecture notes, delivery and repositories | claude.ai Project "AIToolbox" |
| `tooling/` | Generators used to build the navigation and the Community prototype | Working scripts |

## Latest decisions included

- **Navigation.** The rail is the default from 600 px, and the drawer opens on demand from the rail menu. Destinations are Sweep, Environments, Docs and Community. At the bottom sit **Administration** (admins only) and then Cookie policy. Settings is in the account menu. There is no Dashboard, Secrets, Logs, Tools, Terms or version in the navigation.
- **Administration.** It is one entry, visible only to people with at least one admin right. Features have no admin entry of their own. Each feature ships its admin as a remote module, which the Administration shell loads according to the user's rights.
- **Community.** It has three tabs, What's new, Guides and Ideas, used by everyone. Its admin module covers Releases, Tours, Listening (feedback profiles, surveys, inbox), Ideas triage and Insights. One solicitation cap per user applies to every prompt (7 days by default).

## Notes

- **The canvas boards need the canvas viewer.** They are written in the canvas format and load `./support.js` from it, so opening a `.dc.html` file directly in a browser will not render it. Use the canvas for viewing and exporting (PDF or image); keep these files as the source.
- **`project-docs/aitoolbox-component-rules.md` is the newest rules file.** It includes the Administration section. The copy in `design-system/project/component-rules.md` dates from before that change.
- **`design-system/design-system.json` and `project/design-system.json`** are the design system's index files. The asset `blob` ids in them refer to the artifact's asset store; the files themselves are under `design-system/project/assets/<group>/`.

## Tooling

- `navgen.py`: canonical rail and drawer (light and dark), including the Administration entry.
- `shell.py`: shared header and base CSS for the prototype boards.
- `add_admin.py`: inserts the Administration entry into every navigation of a folder of boards (idempotent).
- `community_build.py` + `community-prototype-src/p1–p5.html`: build `CommunityLive.dc.html`. The script expects the sources in `../adoption/src/live/` relative to the script; adjust `SRC` if you move them.

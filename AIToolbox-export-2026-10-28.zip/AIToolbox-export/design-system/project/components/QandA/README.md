# QandA

Questions and their answers about one item, a What's new release or an Idea, in **one expansion panel** at the end of the item. The same component, anatomy and rules apply to both, so a user who has asked a question once knows how it works everywhere. It is live in the Community prototype and in the What's new, Ideas and Q&A pattern labs.

## Where it appears

- **What's new.** Every ReleaseItem (layout D · Changelog) ends with a Questions panel instead of a free discussion: people do not debate a release, they ask questions about it.
- **Ideas.** Ideas use layout E (a 320 px stack with the idea beside it). The idea detail ends with the Questions panel and nothing else; there is no separate discussion, because the two threads duplicated each other. List rows, the admin triage and notifications use the compact summary "3 questions · 1 waiting". The list can be sorted by Most questions.
- It is not a support channel: a question about a broken run goes to Feedback, and a question that needs a decision becomes an Idea. Moderators can move a question to either.

## The expansion panel

- **Container.** One panel per item: 1 px `outline-variant` border, radius 12, `surface` background, `overflow: hidden`. There is only one panel on an item, never an accordion of several.
- **Header = summary bar.** A full-width button, 48 px minimum, `surface-container-low`. From left to right:
  - chevron;
  - "Questions" in title-small and a count badge;
  - up to three asker avatars, 24 px;
  - StatusChips "n answered" (`success-container`) and "n waiting" (`warning-container`), each shown only when it is not zero;
  - "Last answer 2 days ago" (or "No answer yet");
  - **Show** or **Hide**, right-aligned in `primary`.

  The header is the panel's only control: there is no chip in the action line and no Hide button in the body.
- **Expanded.**
  - The panel border turns `primary` and the panel takes elevation 1.
  - The header takes the `secondary-container` tint, its chevron turns up, its label becomes Hide, and a 1 px `outline-variant` divider separates it from the body.
  - The body (padding 0 16 12) fades in over 200 ms with a 4 px slide; there is no motion under reduced motion.
  - The same header collapses the panel.
- **Collapsed by default**, everywhere. A link to a question (notification, answer received, inbox) opens the panel with that question in view.

## The body

- **Questions, newest first**, your own new questions on top. Each question:
  - a 32 px avatar, the author in label-large and the date in body-small `on-surface-variant`;
  - the question in body-medium **600**, 72 characters max per line;
  - while unanswered, a "Waiting for an answer" StatusChip, plus an **Answer** text button for people who can answer.
- **Answer.** It sits under its question on `surface-container` (radius 8, padding 8 × 12). It shows:
  - an "Answered" StatusChip;
  - who answered, with **their role chip**: Platform team (neutral), Champion (`primary-container`), Author (neutral);
  - the date, then the answer in body-medium 400.

  A question has one answer; follow-ups are new questions.
- Questions are separated by 1 px `outline-variant` dividers; there is no divider under the header and no card inside the panel.
- **Show more**, pages of three:
  - The panel opens on the first three questions.
  - Under them, a **text link "Show 3 more questions"** (or "Show 1 more question") in `primary`, body-medium 600, underlined, with no border and no icon, followed by where you are: "3 of 7 shown". The link stays a `button` (it reveals content, it does not navigate).
  - Each press adds the next three below the others, moves the focus to the first new question and announces "3 more questions shown, 6 of 7" from a polite live region.
  - There are no numbered pages and no Show fewer: collapsing the panel goes back to the first three.
- **Ask field**, always last: your avatar, an outlined text field "Ask a question" whose placeholder names who answers ("Ask about this release…", "Ask the author or the platform team…"), and a tonal **Ask** button.
- **Empty panel:** one line in body-small, "No questions yet. Ask the first one: champions and the platform team answer within 2 working days."

## Behaviour

- **Who answers.** The platform team and the feature's admins answer everywhere; champions answer on releases and ideas of their topics; the author answers on their own idea. An answer shows as "Answered" at once, and the asker is notified (bell, and the digest if they chose it).
- **Service level.** Questions left unanswered for 2 working days appear in Administration › Community › Listening › Inbox, with the source "Question" and the item they belong to.
- Questions follow the moderation rules of Community: report, hide, move to Feedback or to an Idea.

## Responsive

The panel takes the full width of its item and never sits in a side column of its own. Under 600 px the header wraps onto two lines (the chips and the last answer go to the second line) and Show / Hide stays on the first; the ask field keeps its button on the same row.

## Keyboard and screen reader

- The header is a `button` with `aria-expanded` and `aria-controls` pointing to the body, a `region` named "Questions". Enter and Space toggle it, and focus stays on it.
- The header's accessible name starts with its visible label and carries the summary: "Questions · 7, 5 answered, 2 waiting, last answer today". The state never lives in the label alone: the chevron, the expanded look and `aria-expanded` carry it.
- Show more references the list (`aria-controls`) and moves focus to the first new question (each question has `tabindex="-1"`). A posted question or answer is announced once.
- The focus ring of the header is drawn inside the panel (offset −3 px), so the panel's rounded corners do not clip it.

## Angular Material

`mat-expansion-panel` (one panel, not in a `mat-accordion`), `hideToggle` with our own chevron in `mat-expansion-panel-header` (`collapsedHeight` and `expandedHeight` 48px). The body uses `mat-button` for Show more, styled as a link; `mat-form-field` outline and a tonal `mat-button` for Ask. The panel overrides are in the theme files (`expansion-overrides`).

## Don't

- Don't put several Questions panels, or an accordion, on one item.
- Don't add a second toggle (a chip in the action line, a Hide button in the body): the panel header is the only one.
- Don't add votes on questions or a "same question" count: newest first and the waiting count are enough.
- Don't load questions on scroll: Show more is explicit and keeps the ask field reachable.
- Don't nest replies under answers, and don't add a discussion next to the questions.
- Don't use teal for answers, even when the assistant suggested the text: a person gives the answer and their role is shown.

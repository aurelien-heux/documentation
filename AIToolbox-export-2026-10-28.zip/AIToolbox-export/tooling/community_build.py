"""Assemble CommunityLive.dc.html from live/p1..p5 with the shared shell, nav variants and header handlers."""
import sys, os, re
sys.path.insert(0, os.path.dirname(__file__))
import navgen as N, shell as S

SRC = os.path.join(os.path.dirname(__file__), '..', 'adoption', 'src', 'live')
DST = sys.argv[1]
parts = ''.join(open(os.path.join(SRC, f'p{i}.html'), encoding='utf-8').read() for i in range(1, 6))

# header with handlers
h = S.header(False)
h = h.replace('<button type="button" class="ui" style="display: inline-flex; align-items: center; gap: 6px; height: 32px;', '<button type="button" class="ui" onClick="{{askAssistant}}" style="display: inline-flex; align-items: center; gap: 6px; height: 32px;')
h = h.replace('aria-label="Open assistant">', 'aria-label="Open assistant" onClick="{{askAssistant}}">')
h = h.replace('aria-label="Notifications, 3 unread">', 'aria-label="Notifications, 3 unread" aria-expanded="{{panel}}" onClick="{{togglePanel}}" style="background: {{bellBg}}">')
h = h.replace('aria-expanded="false" style=""', 'aria-expanded="{{help}}" onClick="{{toggleHelp}}" style="background: {{helpBg}}"')
h = h.replace('aria-haspopup="menu" style="display: inline-flex; align-items: center; gap: 10px; height: 44px; padding: 0 10px 0 6px; border: 0; border-radius: 16px; background: transparent;',
              'aria-haspopup="menu" aria-expanded="{{menu}}" onClick="{{toggleMenu}}" style="display: inline-flex; align-items: center; gap: 10px; height: 44px; padding: 0 10px 0 6px; border: 0; border-radius: 16px; background: {{menuBg}};')
assert h.count('{{') == 11, h.count('{{')

# nav variants
def wire(nav, drawer):
    nav = nav.replace('href="#sweep"', 'href="#sweep" onClick="{{goSweep}}"').replace('href="#new"', 'href="#new" onClick="{{goCommunity}}"').replace('href="#admin"', 'href="#admin" onClick="{{goAdmin}}"')
    i = nav.index('<a href="#admin"'); j = nav.index('</a>', i) + 4
    nav = nav[:i] + '<sc-if value="{{showAdminNav}}" hint-placeholder-val="{{true}}">' + nav[i:j] + '</sc-if>' + nav[j:]
    lab = 'Collapse navigation' if drawer else 'Open navigation'
    nav = nav.replace(f'aria-label="{lab}"', f'aria-label="{lab}" aria-expanded="{"true" if drawer else "false"}" onClick="{{{{toggleNav}}}}"')
    assert 'toggleNav' in nav
    return nav
nav = (f'<sc-if value="{{{{navNewD}}}}" hint-placeholder-val="{{{{false}}}}">{wire(N.drawer(N.LIGHT, "new"), True)}</sc-if>'
       f'<sc-if value="{{{{navSweepD}}}}" hint-placeholder-val="{{{{false}}}}">{wire(N.drawer(N.LIGHT, "sweep"), True)}</sc-if>'
       f'<sc-if value="{{{{navNewR}}}}" hint-placeholder-val="{{{{true}}}}">{wire(N.rail(N.LIGHT, "new"), False)}</sc-if>'
       f'<sc-if value="{{{{navSweepR}}}}" hint-placeholder-val="{{{{false}}}}">{wire(N.rail(N.LIGHT, "sweep"), False)}</sc-if>'
       f'<sc-if value="{{{{navAdminD}}}}" hint-placeholder-val="{{{{false}}}}">{wire(N.drawer(N.LIGHT, "admin"), True)}</sc-if>'
       f'<sc-if value="{{{{navAdminR}}}}" hint-placeholder-val="{{{{false}}}}">{wire(N.rail(N.LIGHT, "admin"), False)}</sc-if>')

for k in ['sweep','env','docs','new']:
    parts = parts.replace(f'<!--MARK:{k}-->', N.mark(k, N.LIGHT, 26))
out = parts.replace('<!--CSS-->', S.CSS).replace('<!--HEADER-->', h).replace('<!--NAV-->', nav)
out = re.sub(r'<!--[^\n]*?-->', '', out)  # strip authoring comments
assert '<!--' not in out
open(DST, 'w', encoding='utf-8').write(out)
print(len(out))

"""Shared AIToolbox shell (header + default rail) and base CSS for the Adoption boards.
Replaces <!--CSS-->, <!--HEADER-->, <!--RAIL--> in a board source."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import navgen as N
UI = N.UI

CSS = """body{margin:0;font-family:'Open Sans',system-ui,sans-serif}
button{cursor:pointer} a{color:#35307E}a:hover{color:#14085E}
:focus-visible{outline:2px solid #35307E;outline-offset:2px}
.ui{font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif}
.ib{position:relative;width:40px;height:40px;border:0;border-radius:999px;background:transparent;color:#48454E;display:inline-flex;align-items:center;justify-content:center;margin:4px}
.ib:hover{background:rgba(53,48,126,.06)}
.btn{height:40px;padding:0 24px;border:0;border-radius:16px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:600;display:inline-flex;align-items:center;gap:8px;white-space:nowrap;text-decoration:none}
.btn-i{padding-left:16px}
.f{background:#35307E;color:#FFFFFF}.t{background:#E3DFFF;color:#191836}.o{background:transparent;border:1px solid #79757F;color:#35307E}.x{background:transparent;color:#35307E;padding:0 12px}
.chip{height:32px;padding:0 12px;border-radius:8px;border:1px solid #79757F;background:transparent;color:#1C1B1E;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:500;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;text-decoration:none}
.chip:hover{background:rgba(53,48,126,.06)}
.chip-on{background:#E3DFFF;border-color:#E3DFFF;color:#191836}
.tag{display:inline-flex;align-items:center;gap:6px;height:24px;padding:0 8px;border-radius:4px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;white-space:nowrap}
.tagt{padding-left:4px}
.env{display:inline-flex;align-items:center;height:24px;padding:0 10px;border-radius:8px;background:#E3DFFF;color:#191836;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;white-space:nowrap}
.mono{font-family:'Open Sans',system-ui,sans-serif;font-weight:600}
.card{background:#FFFFFF;border-radius:12px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.3),0 1px 3px 1px rgba(0,0,0,.15)}
.ocard{background:#FDF8FD;border:1px solid #CAC4CF;border-radius:12px;padding:16px}
.tab{height:48px;padding:0 16px;border:0;background:transparent;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:600;display:inline-flex;align-items:center;gap:8px;border-radius:3px 3px 0 0;color:#48454E;border-bottom:3px solid transparent}
.tab-on{color:#35307E;border-bottom:3px solid #35307E}
.n{font-size:11px;padding:1px 6px;border-radius:6px;background:#F2EBFA;color:#48454E}
.fld{position:relative;box-sizing:border-box;min-height:56px;border:1px solid #79757F;border-radius:4px;padding:16px 16px 10px;background:#FDF8FD}
.fld label{position:absolute;top:-9px;left:12px;padding:0 4px;background:#FDF8FD;font-size:12px;line-height:16px;color:#48454E}
.fld input,.fld textarea,.fld select{width:100%;border:0;outline:0;background:transparent;font:400 16px/24px 'Open Sans',system-ui,sans-serif;color:#1C1B1E;padding:0;resize:none}
.av{width:32px;height:32px;border-radius:999px;background:#D4D0F9;color:#191836;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:13px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;flex:none}
.h2{margin:0;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:18px;line-height:24px;font-weight:600;color:#1C1B1E}
.th{height:48px;padding:0 12px;text-align:left;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:#48454E;white-space:nowrap}
.td{height:52px;padding:6px 12px;font-size:14px;color:#1C1B1E;border-top:1px solid #CAC4CF;vertical-align:middle}
.mi{width:100%;height:48px;padding:0 16px;border:0;background:transparent;display:flex;align-items:center;gap:12px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:500;color:#1C1B1E;text-align:left;text-decoration:none}
.mi:hover{background:rgba(53,48,126,.06)}"""

ST = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"'
BOT = '<svg width="24" height="24" viewBox="0 0 64 64" aria-hidden="true" style="overflow:visible"><g transform="translate(-3.200 -8.150) scale(1.1)"><path d="M26 56h-3a9 9 0 0 1-9-9v-4.0l-5-4 5-4v-4.0a9 9 0 0 1 9-9h2.0l7-5 7 5h2.0a9 9 0 0 1 9 9v4.0l5 4-5 4v4.0a9 9 0 0 1-9 9h-3" fill="none" stroke="#35307E" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M26 37l6 5-6 5" fill="none" stroke="#35307E" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M35 49h5" fill="none" stroke="#008857" stroke-width="4.5" stroke-linecap="round"/></g></svg>'
BELL = '<svg width="24" height="24" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="8" r="3.6" fill="#35307E"/><path d="M32 9C22 9 17 17 17 27V38L12 46Q11 48.5 13.5 48.5H50.5Q53 48.5 52 46L47 38V27C47 17 42 9 32 9Z" fill="#35307E"/><circle cx="32" cy="53.5" r="5" fill="#278383"/></svg>'
LOGO = '<svg width="32" height="28" viewBox="0 0 74 64" aria-hidden="true"><mask id="sh-lg" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64"><rect width="74" height="64" fill="#fff"/><rect x="37" y="3" width="36" height="24" rx="7" fill="#000"/></mask><g mask="url(#sh-lg)"><path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" stroke="#0D0B14" stroke-width="6" stroke-linecap="round"/><rect x="4" y="22" width="56" height="36" rx="10" fill="#0D0B14"/><path d="M17.5 33l8 7-8 7" fill="none" stroke="#FFFFFF" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M33.5 47h13" fill="none" stroke="#00F29E" stroke-width="5.5" stroke-linecap="round"/></g><rect x="39.5" y="5.5" width="31" height="19" rx="5" fill="#80D5D4"/><text x="55" y="20" text-anchor="middle" font-family="Manrope, sans-serif" font-weight="800" font-size="14" fill="#003737">AI</text></svg>'

def ctx(feature, summary, dark=False):
    """Page context block of the top app bar: feature name (line 1) and summary (line 2), right of the logo.
    Replaces page titles and breadcrumbs; going back uses a subheader."""
    fg, mut, div = ('#ECE5F8', '#CAC3DC', '#494458') if dark else ('#1C1B1E', '#48454E', '#CAC4CF')
    return (f'<div class="hctx" style="display: flex; flex-direction: column; justify-content: center; gap: 1px; min-width: 0; margin-left: 16px; padding-left: 16px; border-left: 1px solid {div}">'
            f'<span class="hf" style="font-family: {UI}; font-size: 14px; line-height: 18px; font-weight: 600; color: {fg}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis">{feature}</span>'
            f'<span class="hs" style="font-family: \'Open Sans\', system-ui, sans-serif; font-size: 12px; line-height: 16px; color: {mut}; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 380px">{summary}</span></div>')

def header(help_open=False, feature='{{hdrFeature}}', summary='{{hdrSummary}}'):
    hb = 'background: #D4D0F9; color: #191836' if help_open else ''
    return f'''<header class="hdr" style="height: 64px; flex: none; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 16px; padding: 0 8px 0 24px; background: #EDE4FF; border-bottom: 2px solid #FDF8FD">
    <div style="justify-self: stretch; display: flex; align-items: center; min-width: 0; overflow: hidden"><button type="button" class="ib hdr-menu" aria-label="Open navigation"><svg width="22" height="22" viewBox="0 0 24 24" {ST}><path d="M4 7h16M4 12h16M4 17h16"/></svg></button><a href="#home" aria-label="AIToolbox home" style="display: flex; align-items: center; gap: 10px; text-decoration: none">{LOGO}<span class="hdr-wm" style="font-family: Manrope, sans-serif; font-weight: 800; font-size: 20px; letter-spacing: -0.035em; line-height: 1"><span style="color: #1C1B1E">AI</span><span style="color: #35307E">Toolbox</span></span></a>{ctx(feature, summary)}</div>
    <div role="search" class="hdr-search" style="width: 600px; height: 44px; box-sizing: border-box; display: flex; align-items: center; gap: 10px; padding: 0 6px 0 14px; border-radius: 16px; background: #FFFFFF; color: #48454E">
      <svg width="20" height="20" viewBox="0 0 24 24" {ST}><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
      <label for="sh-q" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0)">Search, or ask the assistant</label>
      <input id="sh-q" type="text" placeholder="Search, or ask the assistant…" style="flex: 1; min-width: 0; border: 0; outline: 0; background: transparent; font: 400 14px 'Open Sans', system-ui, sans-serif; color: #1C1B1E">
      <span class="mono hdr-kbd" style="font-size: 11px; padding: 2px 8px; border-radius: 6px; border: 1px solid #CAC4CF">⌘K</span>
      <button type="button" class="ui" style="display: inline-flex; align-items: center; gap: 6px; height: 32px; padding: 0 12px 0 8px; border: 0; border-radius: 12px; background: #9CF1F0; color: #002020; font-size: 12px; font-weight: 700">{BOT.replace('width="24" height="24"','width="22" height="22"')}<span class="hdr-asklabel">Ask</span></button>
    </div>
    <div style="justify-self: end; display: flex; align-items: center">
      <button type="button" class="ib hdr-sbtn" aria-label="Search"><svg width="22" height="22" viewBox="0 0 24 24" {ST}><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg></button>
      <button type="button" class="ib hdr-asst" aria-label="Open assistant">{BOT}</button>
      <button type="button" class="ib hdr-bell" aria-label="Notifications, 3 unread">{BELL}<span class="ui" style="position: absolute; top: 3px; left: 22px; min-width: 18px; height: 18px; padding: 0 5px; box-sizing: border-box; border-radius: 9px; background: #93000A; color: #FFFFFF; font-size: 11px; font-weight: 700; line-height: 18px; text-align: center; box-shadow: 0 0 0 2px #EDE4FF">3</span></button>
      <button type="button" class="ib hdr-help" aria-label="Help" aria-haspopup="menu" aria-expanded="{'true' if help_open else 'false'}" style="{hb}"><svg width="22" height="22" viewBox="0 0 24 24" {ST}><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7M12 17h.01"/></svg></button>
      <span class="hdr-div" style="width: 1px; height: 24px; background: #CAC4CF; margin: 0 6px"></span>
      <button type="button" class="hdr-user" aria-label="Aurélien Heux, platform admin, account menu" aria-haspopup="menu" style="display: inline-flex; align-items: center; gap: 10px; height: 44px; padding: 0 10px 0 6px; border: 0; border-radius: 16px; background: transparent; color: #48454E; margin-right: 8px"><span class="av">AH</span><span class="hdr-uname" style="display: flex; flex-direction: column; align-items: flex-start; line-height: 1.15"><span class="ui" style="font-size: 13px; font-weight: 700; color: #1C1B1E; white-space: nowrap">Aurélien Heux</span><span style="font-size: 11px; color: #48454E">platform · admin</span></span><svg class="hdr-chev" width="18" height="18" viewBox="0 0 24 24" {ST}><path d="M6 9l6 6 6-6"/></svg></button>
    </div>
  </header>'''

def tabs(active):
    items = [("What's new", '3 new'), ('Guides', ''), ('Ideas', '12'), ('Manage', 'admin')]
    out = ['<div role="tablist" aria-label="Community" style="display: flex; align-items: center; border-bottom: 1px solid #CAC4CF">']
    for name, n in items:
        on = name == active
        out.append(f'<button type="button" role="tab" class="tab{" tab-on" if on else ""}" aria-selected="{"true" if on else "false"}">{name}{f"<span class=n>{n}</span>" if n else ""}</button>')
    out.append('</div>')
    return ''.join(out)

def build(src, dst, active='new', help_open=False):
    s = open(src, encoding='utf-8').read()
    s = s.replace('<!--CSS-->', CSS).replace('<!--HEADER-->', header(help_open)).replace('<!--RAIL-->', N.rail(N.LIGHT, active))
    for a in ["What's new", 'Guides', 'Ideas']:
        s = s.replace(f'<!--TABS:{a}-->', tabs(a))
    assert '<!--' not in s.replace('<!--TABS', ''), 'placeholder left'
    open(dst, 'w', encoding='utf-8').write(s)
    return len(s)

# ---------------------------------------------------------------------------
# Window-width simulator: a control bar outside the frame, and container queries
# inside it (the frame is the `win` container, so every proposal reacts to the
# simulated width, not to the canvas width). Size classes follow the DS:
# Compact <600 · Medium 600–839 · Expanded 840–1199 · Large 1200–1599 · XL ≥1600.
# ---------------------------------------------------------------------------
SIM_CSS = """.simbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:8px 12px;border-radius:12px;background:#FFFFFF;border:1px solid #CAC4CF}
.simbar .chip{height:28px;padding:0 10px;font-size:12px}
.simlab{font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:700;color:#48454E;letter-spacing:.3px}
.simrange{flex:1 1 180px;min-width:140px;max-width:360px;accent-color:#35307E;margin:0 4px}
.simval{font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:13px;color:#48454E;white-space:nowrap}
.simval b{color:#1C1B1E}
.simhost{width:100%;display:flex;justify-content:center;align-items:flex-start;overflow:clip;background-color:#ECE5F4;background-image:radial-gradient(#CAC4CF 1px,transparent 1px);background-size:12px 12px}
.simframe{container:win / inline-size;flex:none;box-sizing:border-box}
.nav-bar{display:none}
.hdr-sbtn,.hdr-menu{display:none!important}
@container win (max-width: 1199px){
.hdr{grid-template-columns:minmax(0,1fr) minmax(180px,340px) auto!important;gap:12px!important}
.hdr-search{width:100%!important}
.hctx .hs,.hdr-uname,.hdr-div,.hdr-asklabel,.hdr-wm{display:none!important}
.hdr-search button{padding:0 6px!important}
main{padding-left:24px!important;padding-right:24px!important}
}
@container win (max-width: 839px){
.hdr{grid-template-columns:minmax(0,1fr) minmax(150px,260px) auto!important;gap:8px!important;padding-left:16px!important}
.hdr-kbd,.hdr-help,.hdr-chev{display:none!important}
.nav-drawer{position:absolute!important;left:0;top:0;height:100vh;max-height:100%;overflow:auto;z-index:30;box-shadow:0 1px 3px rgba(0,0,0,.3),0 4px 8px 3px rgba(0,0,0,.15);border-radius:0 16px 16px 0}
}
@container win (max-width: 599px){
.hdr{height:56px!important;grid-template-columns:minmax(0,1fr) auto!important;padding:0 4px 0 12px!important}
.hdr-search{display:none!important}
.hdr-sbtn,.hdr-menu{display:inline-flex!important}
.hdr-asst{display:none!important}
.hdr-menu{margin:0 4px 0 -8px!important}
.hdr .ib{margin:4px 0!important}
.hctx{margin-left:10px!important;padding-left:10px!important}
.hdr-user{padding:0 4px!important;margin-right:0!important}
.nav-rail{display:none!important}
.nav-bar{display:flex!important}
main{padding-left:16px!important;padding-right:16px!important;padding-top:16px!important}
}"""

def sim_bar(extra=''):
    """Width controls; `extra` is markup placed before them (e.g. the prototype role chips)."""
    return (f'<div class="simbar" role="group" aria-label="Simulated window width">{extra}'
            '<span class="simlab">WINDOW</span>'
            '<sc-for list="{{simPresets}}" as="sp" hint-placeholder-count="7"><button type="button" class="chip {{sp.cls}}" aria-pressed="{{sp.on}}" title="{{sp.title}}" onClick="{{sp.pick}}">{{sp.label}}</button></sc-for>'
            '<input type="range" class="simrange" min="360" max="1920" step="10" value="{{simW}}" aria-label="Window width in pixels" onChange="{{simInput}}">'
            '<span class="simval"><b>{{simW}} px</b> · {{simClass}}<sc-if value="{{simScaled}}" hint-placeholder-val="{{false}}"> · shown at {{simPct}}</sc-if></span></div>')

def sim_open(host_id, extra_style=''):
    return (f'<div class="simhost" id="{host_id}"><div class="simframe" style="width: {{{{simW}}}}px; zoom: {{{{simZoom}}}}; {extra_style}">')

SIM_CLOSE = '</div></div>'

def navbar(t=None, active='new'):
    """Bottom NavigationBar for Compact windows: the rail destinations and the Assistant (the top-bar menu opens the drawer: Administration, Cookie policy)."""
    t = t or N.LIGHT
    items = [('sweep', 'Sweep'), ('env', 'Envs'), ('docs', 'Docs'), ('new', 'Community')]
    out = [f'<nav aria-label="Primary" class="nav-bar" style="position: sticky; bottom: 0; z-index: 3; height: 80px; flex: none; box-sizing: border-box; justify-content: space-around; align-items: center; padding: 0 4px; background: {t["bg"]}; border-top: 1px solid #CAC4CF">']
    def cell(k, label, g, on, tag='a'):
        pill = f'background: {t["abg"]}; color: {t["afg"]}' if on else f'background: transparent; color: {t["fg"]}'
        lab = f'font-weight: 700; color: {t["alab"]}' if on else f'font-weight: 500; color: {t["fg"]}'
        cur = ' aria-current="page"' if on else ''
        attrs = f'href="#{k}"{cur}' if tag == 'a' else 'type="button" aria-label="Open assistant"'
        return (f'<{tag} {attrs} style="display: flex; flex-direction: column; align-items: center; gap: 4px; min-width: 56px; padding: 0; border: 0; background: transparent; text-decoration: none">'
                f'<span style="width: 64px; height: 32px; border-radius: 16px; {pill}; display: inline-flex; align-items: center; justify-content: center">{g}</span>'
                f'<span style="font-family: {UI}; font-size: 11px; {lab}; white-space: nowrap">{label}</span></{tag}>')
    for k, label in items:
        out.append(cell(k, label, N.mark(k, t), k == active))
    out.append(cell('assistant', 'Assistant', BOT, False, 'button'))
    out.append('</nav>')
    return ''.join(out)

# Methods pasted into each board's Component (ES5). The board sets this.simHostId and this.simDefault.
SIM_JS = r"""
  simSync() {
    if (typeof document === 'undefined') return;
    var h = document.getElementById(this.simHostId); if (!h) return;
    var a = Math.round(h.clientWidth);
    if (a > 0 && Math.abs((this.state.simAvail || 0) - a) > 1) this.setState({ simAvail: a });
  }
  simScale() {
    // rects are divided by this before positioning anything inside the (possibly zoomed) frame
    if (typeof document === 'undefined') return 1;
    var h = document.getElementById(this.simHostId), f = h && h.firstElementChild;
    if (!f || !this._simW) return 1;
    var z = f.getBoundingClientRect().width / this._simW;
    return z > 0.05 ? z : 1;
  }
  simVals() {
    var s = this.state, self = this, avail = s.simAvail || this.simDefault;
    var fit = s.simW == null, W = fit ? Math.max(360, Math.min(1920, avail)) : s.simW;
    var z = W > avail ? avail / W : 1;
    this._simW = W;
    var cls = W < 600 ? 'Compact' : W < 840 ? 'Medium' : W < 1200 ? 'Expanded' : W < 1600 ? 'Large' : 'Extra-large';
    var pick = function (v) { return function (e) { if (e && e.preventDefault) e.preventDefault(); self.setState({ simW: v }); }; };
    var P = [[null, 'Fit'], [360, 'Compact'], [600, 'Medium'], [840, 'Expanded'], [1200, 'Large'], [1440, 'Large'], [1920, 'Extra-large']];
    return {
      simW: W, simZoom: String(Math.round(z * 1000) / 1000), simClass: cls, simScaled: z < 0.999, simPct: Math.round(z * 100) + ' %',
      simCompact: W < 600, simMediumUp: W >= 600, simExpandedUp: W >= 840, simLargeUp: W >= 1200,
      simPresets: P.map(function (p) { var v = p[0], on = fit ? v === null : v === W; return { label: v === null ? 'Fit · ' + Math.round(avail) : String(v), title: p[1], on: on, cls: on ? 'chip-on' : '', pick: pick(v) }; }),
      simInput: function (e) { var v = parseInt((e && e.target && e.target.value) || W, 10); if (v && v !== self.state.simW) self.setState({ simW: v }); }
    };
  }
"""

# ---------------------------------------------------------------------------
# Q&A: one expansion panel for What's new items and Ideas. Header = summary bar;
# body = questions (newest first, pages of three), each with its status
# (Answered / Waiting) and the answer nested under it with who answered
# (Platform team, Champion, Author), Show more, and the ask field.
# Same markup and same logic (qaVals) everywhere it appears.
# ---------------------------------------------------------------------------
QA_CSS = """.qa{display:flex;flex-direction:column}
.qa-h{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding-bottom:10px}
.qa-q{display:flex;gap:12px;padding:12px 0;border-top:1px solid #CAC4CF}
.qa-q p{margin:4px 0 0;font-size:14px;line-height:20px;color:#1C1B1E;max-width:72ch}
.qa-q .qtext{font-weight:600}
.qa-a{margin-top:8px;padding:8px 12px;border-radius:8px;background:#F2EBFA}
.qa-a p{font-weight:400}
.qa .sm{height:32px;padding:0 14px;border-radius:12px;font-size:13px}
.qa-empty{padding:12px 0;border-top:1px solid #CAC4CF;font-size:13px;line-height:18px;color:#48454E}
.qa-ask{display:flex;gap:12px;align-items:center;padding-top:12px;border-top:1px solid #CAC4CF}
.qa .meta{font-size:12px;color:#48454E;white-space:nowrap}
.qa{animation:qa-in .2s cubic-bezier(.2,0,0,1) both}
@keyframes qa-in{from{opacity:0;transform:translateY(-4px)}}
.qa-tog[aria-expanded="true"]{background:#E3DFFF;border-color:#E3DFFF;color:#191836}
.qa-tog svg.chev{transition:transform .2s cubic-bezier(.2,0,0,1)}
.qa-tog[aria-expanded="true"] svg.chev{transform:rotate(180deg)}
.qa-hide{margin-left:auto;height:32px;padding:0 8px 0 12px;border:0;border-radius:8px;background:transparent;color:#35307E;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:13px;font-weight:600;display:inline-flex;align-items:center;gap:4px}
.qa-hide:hover{background:rgba(53,48,126,.08)}
.qa-wait{width:8px;height:8px;border-radius:50%;background:#E8A400;flex:none}
/* summary bar: the one control of every thread, and its summary */
.qa-bar{width:100%;min-height:48px;box-sizing:border-box;display:flex;align-items:center;gap:6px 10px;flex-wrap:wrap;padding:8px 14px 8px 10px;border:1px solid #CAC4CF;border-radius:12px;background:#F7F2FA;color:#1C1B1E;text-align:left;font:inherit;cursor:pointer}
.qa-bar .meta{font-size:12px;color:#48454E;white-space:nowrap}
.qa-bar>*{flex:none}.qa-bar>.meta{flex:0 1 auto;min-width:0;overflow:hidden;text-overflow:ellipsis}
.qa-bar:hover{background:#EFE7F7}
.qa-bar[aria-expanded="true"]{border-color:#35307E;background:#F2EBFA;box-shadow:inset 0 0 0 1px #35307E}
.qa-bar .chev{color:#35307E;transition:transform .2s cubic-bezier(.2,0,0,1)}
.qa-bar[aria-expanded="true"] .chev{transform:rotate(180deg)}
.qa-bar-t{font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:700}
.qa-bar-act{margin-left:auto;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:13px;font-weight:600;color:#35307E}
.qa-ppl{display:inline-flex;padding-left:4px}.qa-ppl .av{width:24px;height:24px;font-size:9px;letter-spacing:-.2px;margin-left:-4px;box-shadow:0 0 0 2px #F7F2FA}
/* expansion panel: one container per thread, the summary bar is its header */
.qa-panel{border:1px solid #CAC4CF;border-radius:12px;background:#FDF8FD;overflow:hidden}
.qa-panel.open{border-color:#35307E;box-shadow:0 1px 2px rgba(0,0,0,.3),0 1px 3px 1px rgba(0,0,0,.15)}
.qa-panel .qa-bar{border:0;border-radius:0;background:#F7F2FA;padding:8px 16px 8px 12px}
.qa-panel .qa-bar:hover{background:#EFE7F7}
.qa-panel .qa-bar[aria-expanded="true"]{background:#F2EBFA;box-shadow:none;border-bottom:1px solid #CAC4CF}
.qa-panel .qa-bar:focus-visible{outline:2px solid #35307E;outline-offset:-3px;border-radius:10px}
.qa-panel .qa{padding:0 16px 12px}
.qa-panel .qa-list>.qa-q:first-child,.qa-panel .qa-empty{border-top:0}
.qa-q:focus{outline:none}.qa-q:focus-visible{outline:2px solid #35307E;outline-offset:2px;border-radius:8px}
/* show more: pages of three questions */
.qa-morebar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 0 8px;border-top:1px solid #CAC4CF}
.qa-more{min-height:32px;padding:0;border:0;background:transparent;color:#35307E;font-family:'Open Sans',system-ui,sans-serif;font-size:14px;font-weight:600;text-decoration:underline;text-underline-offset:3px;text-decoration-thickness:1px;cursor:pointer}
.qa-more:hover{text-decoration-thickness:2px;color:#14085E}
.qa-live{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
@container win (max-width: 599px){.qa-bar{flex-wrap:wrap!important}}
@media (prefers-reduced-motion: reduce){.qa{animation:none}.qa-tog svg.chev,.qa-bar .chev{transition:none}}"""

_PLUS = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>'

_CHEV = '<svg class="chev" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>'
_CHEV_UP = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg>'

def qa_toggle(x):
    """Disclosure button for a Q&A thread: label, waiting dot, chevron; aria-expanded / aria-controls; selected look when open."""
    return (f'<button type="button" class="chip qa-tog" id="{{{{{x}.qaTogId}}}}" aria-expanded="{{{{{x}.qaOpen}}}}" aria-controls="{{{{{x}.qaRegionId}}}}" aria-label="{{{{{x}.qaTogAria}}}}" onClick="{{{{{x}.qaToggle}}}}">'
            f'{{{{{x}.qaTogLabel}}}}<sc-if value="{{{{{x}.qaHasWaiting}}}}" hint-placeholder-val="{{{{false}}}}"><span class="qa-wait" aria-hidden="true"></span></sc-if>{_CHEV}</button>')

def qa_empty(x):
    return (f'<sc-if value="{{{{{x}.qaEmpty}}}}" hint-placeholder-val="{{{{false}}}}"><div class="qa-empty">No questions yet. Ask the first one: champions and the platform team answer within 2 working days.</div></sc-if>')

def qa_items(x, lst='qa'):
    """The questions of a thread (each with its answer). `lst` picks the list field (qa, or qaTopList for a preview)."""
    return (f'<sc-for list="{{{{{x}.{lst}}}}}" as="q" hint-placeholder-count="2"><div class="qa-q" id="qa-q-{{{{q.id}}}}" tabindex="-1">'
            '<span class="av" style="background: {{q.bg}}">{{q.ini}}</span><div style="flex: 1; min-width: 0">'
            '<div class="row" style="gap: 8px; flex-wrap: wrap"><b class="ui" style="font-size: 13px">{{q.who}}</b><span class="meta">{{q.when}}</span></div>'
            '<p class="qtext">{{q.text}}</p>'
            '<sc-if value="{{q.waiting}}" hint-placeholder-val="{{false}}"><div class="row" style="gap: 8px; flex-wrap: wrap; margin-top: 8px"><span class="tile wn"><i></i>Waiting for an answer</span>'
            '<sc-if value="{{q.canAnswer}}" hint-placeholder-val="{{false}}"><button type="button" class="lnk" onClick="{{q.startAnswer}}">Answer</button></sc-if></div></sc-if>'
            '<sc-if value="{{q.answered}}" hint-placeholder-val="{{true}}"><div class="qa-a"><div class="row" style="gap: 8px; flex-wrap: wrap"><span class="tile ok"><i></i>Answered</span><b class="ui" style="font-size: 13px">{{q.aWho}}</b><span class="tile {{q.aTile}}"><i></i>{{q.aRole}}</span><span class="meta">{{q.aWhen}}</span></div><p>{{q.aText}}</p></div></sc-if>'
            '<sc-if value="{{q.answering}}" hint-placeholder-val="{{false}}"><div class="row" style="margin-top: 8px"><div class="fld" style="flex: 1; min-height: 40px; padding: 8px 12px"><label for="{{q.ansId}}">Answer as {{q.answerAs}}</label><input id="{{q.ansId}}" type="text" value="{{q.ansDraft}}" onChange="{{q.onAnsDraft}}" placeholder="Shown under the question; the asker is notified"></div><button type="button" class="btn f sm" onClick="{{q.sendAnswer}}">Answer</button></div></sc-if>'
            '</div></div></sc-for>')

def qa_ask(x):
    return (f'<div class="qa-ask"><span class="av">AH</span><div class="fld" style="flex: 1; min-height: 44px; padding: 10px 12px"><label for="{{{{{x}.qaAskId}}}}">Ask a question</label><input id="{{{{{x}.qaAskId}}}}" type="text" value="{{{{{x}.qaDraft}}}}" onChange="{{{{{x}.qaOnDraft}}}}" placeholder="{{{{{x}.qaPlaceholder}}}}"></div><button type="button" class="btn t" onClick="{{{{{x}.qaAsk}}}}">Ask</button></div>')

def qa_block_chip(x):
    """Former pattern (B in the Q&A pattern lab): thread header with Hide questions, opened by qa_toggle(). Kept for the record."""
    return (f'<sc-if value="{{{{{x}.qaOpen}}}}" hint-placeholder-val="{{{{true}}}}"><div class="qa" id="{{{{{x}.qaRegionId}}}}" role="region" aria-label="Questions">'
            f'<div class="qa-h"><span class="ui" style="font-size: 14px; font-weight: 600">Questions · {{{{{x}.qaN}}}}</span>'
            f'<sc-if value="{{{{{x}.qaHasAnswered}}}}" hint-placeholder-val="{{{{true}}}}"><span class="tile ok"><i></i>{{{{{x}.qaAnsweredLabel}}}}</span></sc-if>'
            f'<sc-if value="{{{{{x}.qaHasWaiting}}}}" hint-placeholder-val="{{{{true}}}}"><span class="tile wn"><i></i>{{{{{x}.qaWaitingLabel}}}}</span></sc-if>'
            f'<button type="button" class="qa-hide" aria-controls="{{{{{x}.qaRegionId}}}}" aria-expanded="true" onClick="{{{{{x}.qaHide}}}}">Hide questions{_CHEV_UP}</button>'
            '</div>'
            + qa_empty(x) + qa_items(x) + qa_ask(x) +
            '</div></sc-if>')

def qa_bar(x):
    """Summary bar: the only control of a thread and its summary (pattern A). Same in every feature."""
    chev = _CHEV.replace('width="18" height="18"', 'width="20" height="20"')
    return (f'<button type="button" class="qa-bar" id="{{{{{x}.qaTogId}}}}" aria-expanded="{{{{{x}.qaOpen}}}}" aria-controls="{{{{{x}.qaRegionId}}}}" aria-label="{{{{{x}.qaBarAria}}}}" onClick="{{{{{x}.qaToggle}}}}">'
            f'{chev}<span class="qa-bar-t">Questions</span><span class="n">{{{{{x}.qaN}}}}</span>'
            f'<sc-if value="{{{{{x}.qaHasPeople}}}}" hint-placeholder-val="{{{{true}}}}"><span class="qa-ppl" aria-hidden="true"><sc-for list="{{{{{x}.qaPeople}}}}" as="p" hint-placeholder-count="3"><span class="av" style="background: {{{{p.bg}}}}">{{{{p.ini}}}}</span></sc-for></span></sc-if>'
            f'<sc-if value="{{{{{x}.qaHasAnswered}}}}" hint-placeholder-val="{{{{true}}}}"><span class="tile ok"><i></i>{{{{{x}.qaAnsweredLabel}}}}</span></sc-if>'
            f'<sc-if value="{{{{{x}.qaHasWaiting}}}}" hint-placeholder-val="{{{{true}}}}"><span class="tile wn"><i></i>{{{{{x}.qaWaitingLabel}}}}</span></sc-if>'
            f'<span class="meta">{{{{{x}.qaLastLabel}}}}</span><span class="qa-bar-act">{{{{{x}.qaAction}}}}</span></button>')

def qa_more(x):
    """Show more: the next page of questions (3 at a time), with where you are; focus moves to the first new question."""
    return (f'<sc-if value="{{{{{x}.qaHasNext}}}}" hint-placeholder-val="{{{{true}}}}"><div class="qa-morebar">'
            f'<button type="button" class="qa-more" aria-controls="{{{{{x}.qaListId}}}}" onClick="{{{{{x}.qaShowMore}}}}">{{{{{x}.qaMoreBtn}}}}</button>'
            f'<span class="meta">{{{{{x}.qaShownLabel}}}}</span></div></sc-if>'
            f'<span class="qa-live" role="status" aria-live="polite">{{{{{x}.qaLive}}}}</span>')

def qa_block(x):
    """Q&A as one expansion panel: the summary bar is the header; open, the body holds the questions (pages of three), Show more and the ask field."""
    return (f'<div class="qa-panel {{{{{x}.qaPanelCls}}}}">' + qa_bar(x) + f'<sc-if value="{{{{{x}.qaOpen}}}}" hint-placeholder-val="{{{{false}}}}"><div class="qa" id="{{{{{x}.qaRegionId}}}}" role="region" aria-label="Questions">'
            + qa_empty(x) + f'<div class="qa-list" id="{{{{{x}.qaListId}}}}">' + qa_items(x, 'qaPage') + '</div>' + qa_more(x) + qa_ask(x) + '</div></sc-if></div>')

QA_JS = r"""
  qaSeed() {
    var T = 'Platform team';
    // newest question first; a.d = days since the answer (for "Last answer")
    return {
      r1: [
        { id: 'r1q3', ini: 'PS', bg: '#9CF1F0', who: 'Priya Sharma', when: '3 h ago', text: 'Can a repository opt out of PR summaries?' },
        { id: 'r1q6', ini: 'EL', bg: '#FFDEA0', who: 'Emma Laurent', when: '5 h ago', text: 'Do PR summaries run on draft pull requests?' },
        { id: 'r1q5', ini: 'NR', bg: '#E3DFFF', who: 'Nadia Rahal', when: 'yesterday', text: 'Is the approval card shown in the VS Code extension too?', a: { who: 'Sami Ben Ali', role: T, when: 'today', d: 0, text: 'Not yet: the extension opens the approval in the browser. Native cards come with 4.7.' } },
        { id: 'r1q2', ini: 'YD', bg: '#C3F4DC', who: 'Yann Dupont', when: 'yesterday', text: 'Do the ratings on PR summaries change anything, or are they just stats?', a: { who: 'Marta Kowalski', role: 'Champion', when: 'yesterday', d: 1, text: 'They feed the summary prompt directly, so ask your reviewers to rate them: that is how summaries get better for your repositories.' } },
        { id: 'r1q7', ini: 'KO', bg: '#9CF1F0', who: 'Karim Ouali', when: 'yesterday', text: 'Is there a size limit on the diff for a summary?', a: { who: 'Marta Kowalski', role: 'Champion', when: 'yesterday', d: 1, text: 'Above 5 000 changed lines the summary covers the files with the most changes and says so at the top.' } },
        { id: 'r1q1', ini: 'LB', bg: '#FFDEA0', who: 'Lucas Bernard', when: '2 days ago', text: 'Does the approval card also show up when a skill calls the tool, not only in chat?', a: { who: 'Sami Ben Ali', role: T, when: '2 days ago', d: 2, text: 'Yes. Any tool that deploys, deletes or edits asks first, whoever calls it: chat, a skill or an MCP server.' } },
        { id: 'r1q4', ini: 'TD', bg: '#C3F4DC', who: 'Thomas Durand', when: '2 days ago', text: 'Can I see afterwards who approved a tool call?', a: { who: 'Sami Ben Ali', role: T, when: '2 days ago', d: 2, text: 'Yes, in the activity log of the run: who approved, when, and the arguments that were sent.' } }
      ],
      r2: [
        { id: 'r2q1', ini: 'YD', bg: '#C3F4DC', who: 'Yann Dupont', when: '3 days ago', text: 'Will the old model stay available for a fallback period?', a: { who: 'Sami Ben Ali', role: T, when: '3 days ago', d: 3, text: 'Two weeks, per workspace, from Settings › Assistant. After 17 Nov the switch is final.' } },
        { id: 'r2q2', ini: 'LB', bg: '#FFDEA0', who: 'Lucas Bernard', when: '3 days ago', text: 'Do MCP servers pinned to the old tool schema need a redeploy before 3 November?' }
      ],
      r3: [], r4: [],
      i1: [
        { id: 'i1q5', ini: 'EL', bg: '#FFDEA0', who: 'Emma Laurent', when: '15 Oct', text: 'Will the partial re-run work from the CLI as well?', a: { who: 'Marta Kowalski', role: 'Author', when: '16 Oct', d: 12, text: 'That is the next step if the PR page works out; I opened a separate idea for it.' } },
        { id: 'i1q4', ini: 'YD', bg: '#C3F4DC', who: 'Yann Dupont', when: '12 Oct', text: 'Could the PR page list the checks that will run again before I confirm?' },
        { id: 'i1q3', ini: 'NR', bg: '#E3DFFF', who: 'Nadia Rahal', when: '6 Oct', text: 'Would the re-run reuse the build cache of the failed run?', a: { who: 'Sami Ben Ali', role: T, when: '9 Oct', d: 19, text: 'Yes, when the commit is the same, the artefacts of the failed run are reused.' } },
        { id: 'i1q2', ini: 'LB', bg: '#FFDEA0', who: 'Lucas Bernard', when: '4 Oct', text: 'Would scheduled sweeps get the partial re-run too, or only runs started from a pull request?', a: { who: 'Marta Kowalski', role: 'Author', when: '5 Oct', d: 23, text: 'From the PR page first: that is where the 10 minutes are lost. Scheduled sweeps could follow.' } },
        { id: 'i1q1', ini: 'PS', bg: '#9CF1F0', who: 'Priya Sharma', when: '25 Sep', text: 'Will a partial re-run report on the same check names, so branch protection still sees one result per check?', a: { who: 'Sami Ben Ali', role: T, when: '2 Oct', d: 26, text: 'Yes: the re-run updates the existing checks instead of adding new ones.' } }
      ],
      i2: [ { id: 'i2q1', ini: 'MK', bg: '#9CF1F0', who: 'Marta Kowalski', when: '6 Oct', text: 'Would the exported conversation include the tool calls, or only the messages?' } ],
      i3: [], i4: [], i5: [], i6: []
    };
  }
  qaFocusSync() {
    // after "Hide questions", focus goes back to the Questions button; after opening from a button that
    // disappears while the thread is open (idea detail), focus moves to the thread's Hide questions button
    if (typeof document === 'undefined') return;
    var el = null;
    if (this._qaFocus) { el = document.getElementById(this._qaFocus); this._qaFocus = null; }
    else if (this._qaFocusQ) { el = document.getElementById(this._qaFocusQ); this._qaFocusQ = null; }
    else if (this._qaOpened) { var k = this._qaOpened; this._qaOpened = null; if (!document.getElementById('qa-t-' + k)) el = document.querySelector('#qa-r-' + k + ' .qa-hide'); }
    if (el) try { el.focus(); } catch (e) {}
  }
  qaVals(key, base, placeholder, answerAs, defOpen) {
    // answerAs: { who, role } when the viewer may answer (platform team, champion, author), else null
    // defOpen: open until the viewer closes it (newest release, idea detail)
    var s = this.state, self = this, om = s.qaOpen || {}, open = om[key] === undefined ? !!defOpen : !!om[key];
    var ex = (s.qaExtra || {})[key] || [], ans = s.qaAns || {}, ing = s.qaAnswering || {}, ad = s.qaAnsDrafts || {}, dr = s.qaDrafts || {};
    var up = function (path, k, v) { var o = {}; o[path] = Object.assign({}, self.state[path] || {}); o[path][k] = v; return o; };
    var click = function (f) { return function (e) { if (e && e.preventDefault) e.preventDefault(); self.setState(f()); }; };
    var typed = function (path, k) { return function (e) { self.setState(up(path, k, e && e.target ? e.target.value : '')); }; };
    // order: newest first (your own new questions on top); the seed lists are written newest first
    var ordered = ex.slice().reverse().concat(base || []);
    var list = ordered.map(function (q) {
      var a = ans[q.id] || q.a || null;
      return { id: q.id, ini: q.ini, bg: q.bg, who: q.who, when: q.when, text: q.text,
        answered: !!a, waiting: !a, aD: a ? (a.d == null ? 0 : a.d) : 999, aWho: a ? a.who : '', aRole: a ? a.role : '', aTile: a && a.role === 'Champion' ? 'in' : 'ne', aWhen: a ? a.when : '', aText: a ? a.text : '',
        canAnswer: !a && !!answerAs && !ing[q.id], answering: !a && !!answerAs && !!ing[q.id], answerAs: answerAs ? answerAs.role.toLowerCase() === 'platform team' ? 'the platform team' : answerAs.role.toLowerCase() : '',
        startAnswer: click(function () { return up('qaAnswering', q.id, true); }),
        ansId: 'qa-a-' + q.id, ansDraft: ad[q.id] || '', onAnsDraft: typed('qaAnsDrafts', q.id),
        sendAnswer: click(function () { var t = ((self.state.qaAnsDrafts || {})[q.id] || '').trim(); if (!t) return {}; return Object.assign(up('qaAns', q.id, { who: answerAs.who, role: answerAs.role, when: 'just now', text: t }), up('qaAnswering', q.id, false)); })
      };
    });
    var nA = list.filter(function (q) { return q.answered; }).length, nW = list.length - nA;
    var setOpen = function (v, focus) { return function (e) { if (e && e.preventDefault) e.preventDefault(); if (focus) self._qaFocus = 'qa-t-' + key; else if (v) self._qaOpened = key;
      var o = Object.assign({}, self.state.qaOpen || {}); o[key] = v; var sh = Object.assign({}, self.state.qaShown || {}); delete sh[key]; var lv = Object.assign({}, self.state.qaLive || {}); delete lv[key];
      self.setState({ qaOpen: o, qaShown: sh, qaLive: lv }); }; };
    // pages of three: Show more reveals the next three and moves focus to the first of them
    var PAGE = 3, shown = Math.max(PAGE, (s.qaShown || {})[key] || PAGE), nextN = Math.min(PAGE, Math.max(0, list.length - shown));
    var showMore = function (e) { if (e && e.preventDefault) e.preventDefault(); var first = list[shown]; if (first) self._qaFocusQ = 'qa-q-' + first.id;
      var n = Math.min(list.length, shown + PAGE), sh = Object.assign({}, self.state.qaShown || {}); sh[key] = n; var lv = Object.assign({}, self.state.qaLive || {}); lv[key] = (n - shown) + (n - shown > 1 ? ' more questions shown, ' : ' more question shown, ') + n + ' of ' + list.length;
      self.setState({ qaShown: sh, qaLive: lv }); };
    var lastAns = (function () { var w = list.filter(function (q) { return q.answered; }).sort(function (a, b) { return a.aD - b.aD; }); return w.length ? w[0].aWhen : ''; })();
    return { qaOpen: open, qaClosed: !open, qaPanelCls: open ? 'open' : '', qaAction: open ? 'Hide' : 'Show', qaListId: 'qa-l-' + key,
      qaPage: list.slice(0, shown), qaHasNext: nextN > 0, qaNextN: nextN, qaMoreBtn: 'Show ' + nextN + ' more question' + (nextN > 1 ? 's' : ''), qaShowMore: showMore, qaShownLabel: Math.min(shown, list.length) + ' of ' + list.length + ' shown', qaLive: (s.qaLive || {})[key] || '',
      qaBarAria: 'Questions · ' + list.length + (nA ? ', ' + nA + ' answered' : '') + (nW ? ', ' + nW + ' waiting' : '') + (lastAns ? ', last answer ' + lastAns : ''),
      qaHasPeople: list.length > 0, qaToggle: setOpen(!open, false), qaHide: setOpen(false, true), qaTogId: 'qa-t-' + key, qaRegionId: 'qa-r-' + key,
      qaTogLabel: 'Questions · ' + list.length, qaTogAria: 'Questions · ' + list.length + (nW ? ', ' + nW + ' waiting' : ''),
      qaSummary: list.length + (list.length === 1 ? ' question' : ' questions') + (nW ? ' · ' + nW + ' waiting' : ''),
      qaLastLabel: lastAns ? 'Last answer ' + lastAns : (list.length ? 'No answer yet' : 'No questions yet'),
      qaPeople: list.slice(0, 3).map(function (q) { return { ini: q.ini, bg: q.bg }; }), qaMorePeople: list.length > 3 ? '+' + (list.length - 3) : '', qaHasMorePeople: list.length > 3,
      qaTopList: list.filter(function (q) { return q.answered; }).slice(0, 1),
      qaMoreLabel: 'Show all ' + list.length + ' questions' + (nW ? ' · ' + nW + ' waiting' : ''), qaHasMore: list.length > 1,
      qa: list, qaN: list.length, qaEmpty: !list.length, qaHasAnswered: nA > 0, qaAnsweredLabel: nA + ' answered', qaHasWaiting: nW > 0, qaWaitingLabel: nW + ' waiting',
      qaAskId: 'qa-ask-' + key, qaDraft: dr[key] || '', qaPlaceholder: placeholder, qaOnDraft: typed('qaDrafts', key),
      qaAsk: click(function () { var t = ((self.state.qaDrafts || {})[key] || '').trim(); if (!t) return {}; var cur = (self.state.qaExtra || {})[key] || []; return Object.assign(up('qaExtra', key, cur.concat([{ id: key + '-n' + (cur.length + 1), ini: 'AH', bg: '#D4D0F9', who: 'Aurélien Heux', when: 'just now', text: t }])), up('qaDrafts', key, '')); }) };
  }
"""

"""Shared AIToolbox shell (header + default rail) and base CSS for the Adoption boards.
Replaces <!--CSS-->, <!--HEADER-->, <!--RAIL--> in a board source."""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import navgen as N

CSS = """body{margin:0;font-family:'Open Sans',system-ui,sans-serif}
button{cursor:pointer} a{color:#35307E}a:hover{color:#14085E}
:focus-visible{outline:2px solid #35307E;outline-offset:2px}
.ui{font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif}
.ib{position:relative;width:40px;height:40px;border:0;border-radius:999px;background:transparent;color:#48454E;display:inline-flex;align-items:center;justify-content:center;margin:4px}
.ib:hover{background:rgba(53,48,126,.06)}
.btn{height:40px;padding:0 24px;border:0;border-radius:16px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:600;display:inline-flex;align-items:center;gap:8px;white-space:nowrap;text-decoration:none}
.btn-i{padding-left:16px}
.f{background:#35307E;color:#FFFFFF}.t{background:#E3DFFF;color:#191836}.o{background:transparent;border:1px solid #79757F;color:#35307E}.x{background:transparent;color:#35307E;padding:0 12px}
.chip{height:32px;padding:0 12px;border-radius:8px;border:1px solid #79757F;background:transparent;color:#1C1B1E;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:500;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;text-decoration:none}
.chip:hover{background:rgba(53,48,126,.06)}
.chip-on{background:#E3DFFF;border-color:#E3DFFF;color:#191836}
.tag{display:inline-flex;align-items:center;gap:6px;height:24px;padding:0 8px;border-radius:4px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;white-space:nowrap}
.tagt{padding-left:4px}
.env{display:inline-flex;align-items:center;height:24px;padding:0 10px;border-radius:8px;background:#E3DFFF;color:#191836;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;white-space:nowrap}
.mono{font-family:'Open Sans',system-ui,sans-serif;font-weight:600}
.card{background:#FFFFFF;border-radius:12px;padding:16px;box-shadow:0 1px 2px rgba(0,0,0,.3),0 1px 3px 1px rgba(0,0,0,.15)}
.ocard{background:#FDF8FD;border:1px solid #CAC4CF;border-radius:12px;padding:16px}
.tab{height:48px;padding:0 16px;border:0;background:transparent;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:600;display:inline-flex;align-items:center;gap:8px;border-radius:3px 3px 0 0;color:#48454E;border-bottom:3px solid transparent}
.tab-on{color:#35307E;border-bottom:3px solid #35307E}
.n{font-size:11px;padding:1px 6px;border-radius:6px;background:#F2EBFA;color:#48454E}
.fld{position:relative;box-sizing:border-box;min-height:56px;border:1px solid #79757F;border-radius:4px;padding:16px 16px 10px;background:#FDF8FD}
.fld label{position:absolute;top:-9px;left:12px;padding:0 4px;background:#FDF8FD;font-size:12px;line-height:16px;color:#48454E}
.fld input,.fld textarea,.fld select{width:100%;border:0;outline:0;background:transparent;font:400 16px/24px 'Open Sans',system-ui,sans-serif;color:#1C1B1E;padding:0;resize:none}
.av{width:32px;height:32px;border-radius:999px;background:#D4D0F9;color:#191836;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:13px;font-weight:700;display:inline-flex;align-items:center;justify-content:center;flex:none}
.h2{margin:0;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:18px;line-height:24px;font-weight:600;color:#1C1B1E}
.th{height:48px;padding:0 12px;text-align:left;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:12px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;color:#48454E;white-space:nowrap}
.td{height:52px;padding:6px 12px;font-size:14px;color:#1C1B1E;border-top:1px solid #CAC4CF;vertical-align:middle}
.mi{width:100%;height:48px;padding:0 16px;border:0;background:transparent;display:flex;align-items:center;gap:12px;font-family:Manrope,'BNPP Type','Segoe UI',system-ui,sans-serif;font-size:14px;font-weight:500;color:#1C1B1E;text-align:left;text-decoration:none}
.mi:hover{background:rgba(53,48,126,.06)}"""

ST = 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"'
BOT = '<svg width="24" height="24" viewBox="0 0 64 64" aria-hidden="true" style="overflow:visible"><g transform="translate(-3.200 -8.150) scale(1.1)"><path d="M26 56h-3a9 9 0 0 1-9-9v-4.0l-5-4 5-4v-4.0a9 9 0 0 1 9-9h2.0l7-5 7 5h2.0a9 9 0 0 1 9 9v4.0l5 4-5 4v4.0a9 9 0 0 1-9 9h-3" fill="none" stroke="#35307E" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M26 37l6 5-6 5" fill="none" stroke="#35307E" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M35 49h5" fill="none" stroke="#008857" stroke-width="4.5" stroke-linecap="round"/></g></svg>'
BELL = '<svg width="24" height="24" viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="8" r="3.6" fill="#35307E"/><path d="M32 9C22 9 17 17 17 27V38L12 46Q11 48.5 13.5 48.5H50.5Q53 48.5 52 46L47 38V27C47 17 42 9 32 9Z" fill="#35307E"/><circle cx="32" cy="53.5" r="5" fill="#278383"/></svg>'
LOGO = '<svg width="32" height="28" viewBox="0 0 74 64" aria-hidden="true"><mask id="sh-lg" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64"><rect width="74" height="64" fill="#fff"/><rect x="37" y="3" width="36" height="24" rx="7" fill="#000"/></mask><g mask="url(#sh-lg)"><path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" stroke="#0D0B14" stroke-width="6" stroke-linecap="round"/><rect x="4" y="22" width="56" height="36" rx="10" fill="#0D0B14"/><path d="M17.5 33l8 7-8 7" fill="none" stroke="#FFFFFF" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M33.5 47h13" fill="none" stroke="#00F29E" stroke-width="5.5" stroke-linecap="round"/></g><rect x="39.5" y="5.5" width="31" height="19" rx="5" fill="#80D5D4"/><text x="55" y="20" text-anchor="middle" font-family="Manrope, sans-serif" font-weight="800" font-size="14" fill="#003737">AI</text></svg>'

def header(help_open=False):
    hb = 'background: #D4D0F9; color: #191836' if help_open else ''
    return f'''<header style="height: 64px; flex: none; display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 16px; padding: 0 8px 0 24px; background: #EDE4FF; border-bottom: 2px solid #FDF8FD">
    <a href="#home" aria-label="AIToolbox home" style="justify-self: start; display: flex; align-items: center; gap: 10px; text-decoration: none">{LOGO}<span style="font-family: Manrope, sans-serif; font-weight: 800; font-size: 20px; letter-spacing: -0.035em; line-height: 1"><span style="color: #1C1B1E">AI</span><span style="color: #35307E">Toolbox</span></span></a>
    <div role="search" style="width: 600px; height: 44px; box-sizing: border-box; display: flex; align-items: center; gap: 10px; padding: 0 6px 0 14px; border-radius: 16px; background: #FFFFFF; color: #48454E">
      <svg width="20" height="20" viewBox="0 0 24 24" {ST}><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>
      <label for="sh-q" style="position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0)">Search, or ask the assistant</label>
      <input id="sh-q" type="text" placeholder="Search, or ask the assistant…" style="flex: 1; min-width: 0; border: 0; outline: 0; background: transparent; font: 400 14px 'Open Sans', system-ui, sans-serif; color: #1C1B1E">
      <span class="mono" style="font-size: 11px; padding: 2px 8px; border-radius: 6px; border: 1px solid #CAC4CF">⌘K</span>
      <button type="button" class="ui" style="display: inline-flex; align-items: center; gap: 6px; height: 32px; padding: 0 12px 0 8px; border: 0; border-radius: 12px; background: #9CF1F0; color: #002020; font-size: 12px; font-weight: 700">{BOT.replace('width="24" height="24"','width="22" height="22"')}Ask</button>
    </div>
    <div style="justify-self: end; display: flex; align-items: center">
      <button type="button" class="ib" aria-label="Open assistant">{BOT}</button>
      <button type="button" class="ib" aria-label="Notifications, 3 unread">{BELL}<span class="ui" style="position: absolute; top: 3px; left: 22px; min-width: 18px; height: 18px; padding: 0 5px; box-sizing: border-box; border-radius: 9px; background: #93000A; color: #FFFFFF; font-size: 11px; font-weight: 700; line-height: 18px; text-align: center; box-shadow: 0 0 0 2px #EDE4FF">3</span></button>
      <button type="button" class="ib" aria-label="Help" aria-haspopup="menu" aria-expanded="{'true' if help_open else 'false'}" style="{hb}"><svg width="22" height="22" viewBox="0 0 24 24" {ST}><circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.3-1 .9-1 1.7M12 17h.01"/></svg></button>
      <span style="width: 1px; height: 24px; background: #CAC4CF; margin: 0 6px"></span>
      <button type="button" aria-label="Aurélien Heux, platform admin, account menu" aria-haspopup="menu" style="display: inline-flex; align-items: center; gap: 10px; height: 44px; padding: 0 10px 0 6px; border: 0; border-radius: 16px; background: transparent; color: #48454E; margin-right: 8px"><span class="av">AH</span><span style="display: flex; flex-direction: column; align-items: flex-start; line-height: 1.15"><span class="ui" style="font-size: 13px; font-weight: 700; color: #1C1B1E; white-space: nowrap">Aurélien Heux</span><span style="font-size: 11px; color: #48454E">platform · admin</span></span><svg width="18" height="18" viewBox="0 0 24 24" {ST}><path d="M6 9l6 6 6-6"/></svg></button>
    </div>
  </header>'''

def tabs(active):
    items = [("What's new", '3 new'), ('Guides', ''), ('Ideas', '12'), ('Manage', 'admin')]
    out = ['<div role="tablist" aria-label="Community" style="display: flex; align-items: center; border-bottom: 1px solid #CAC4CF">']
    for name, n in items:
        on = name == active
        out.append(f'<button type="button" role="tab" class="tab{" tab-on" if on else ""}" aria-selected="{"true" if on else "false"}">{name}{f"<span class=n>{n}</span>" if n else ""}</button>')
    out.append('</div>')
    return ''.join(out)

def build(src, dst, active='new', help_open=False):
    s = open(src, encoding='utf-8').read()
    s = s.replace('<!--CSS-->', CSS).replace('<!--HEADER-->', header(help_open)).replace('<!--RAIL-->', N.rail(N.LIGHT, active))
    for a in ["What's new", 'Guides', 'Ideas']:
        s = s.replace(f'<!--TABS:{a}-->', tabs(a))
    assert '<!--' not in s.replace('<!--TABS', ''), 'placeholder left'
    open(dst, 'w', encoding='utf-8').write(s)
    return len(s)

"""Data for the Docs lab: application views (LikeC4-style, ArchiMate layer colours), detailed design (DD) files,
and the SVG generator. Diagrams are generated from this data, as LikeC4 views are generated from the model: nothing
is drawn by hand, and every fact in a picture also exists as text the knowledge base can index."""
import math, json

LAYER = {  # design system ArchiMate layer tokens, light theme: fill, ink
    'business': ('#FFF2B3', '#5E5000', 'Business'),
    'application': ('#CFEDFA', '#0A5570', 'Application'),
    'technology': ('#D5EDC7', '#2C5A1C', 'Technology'),
}
ROUNDED = {'application-process', 'technology-service', 'application-service'}
VBW, VBH = 960, 420
NW, NH = 176, 64

# pl: base | target | both · chg: changed (both plateaus, different) · ext: element of another application
APPS = {
    'environments': {
        'name': 'Environments', 'slug': 'environments', 'portfolio': 'Delivery platform', 'owners': 'Yann Dupont · Environments team',
        'modes': ['base', 'target', 'gap'], 'plateaus': 'baseline → transition-1 → target',
        'nodes': [
            {'k': 'dev', 'name': 'Developer', 'kind': 'Business actor', 'layer': 'business', 'x': 24, 'y': 40, 'pl': 'both', 'id': 'mot.environments.developer'},
            {'k': 'rm', 'name': 'Release manager', 'kind': 'Business role', 'layer': 'business', 'x': 24, 'y': 190, 'pl': 'both', 'id': 'mot.environments.release-manager'},
            {'k': 'ui', 'name': 'Environments UI', 'kind': 'Application component', 'layer': 'application', 'x': 266, 'y': 40, 'pl': 'both', 'id': 'sbb.environments.frontend'},
            {'k': 'api', 'name': 'Environments API', 'kind': 'Application component', 'layer': 'application', 'x': 266, 'y': 190, 'pl': 'both', 'chg': 'changed', 'id': 'sbb.environments.backend'},
            {'k': 'res', 'name': 'Reservation API', 'kind': 'Application interface', 'layer': 'application', 'x': 508, 'y': 40, 'pl': 'target', 'id': 'sbb.environments.reservation-api'},
            {'k': 'pr', 'name': 'Descriptor pull request', 'kind': 'Application process', 'layer': 'application', 'x': 508, 'y': 190, 'pl': 'target', 'id': 'sbb.environments.descriptor-pr'},
            {'k': 'job', 'name': 'Descriptor job', 'kind': 'Jenkins job', 'layer': 'application', 'x': 508, 'y': 330, 'pl': 'base', 'id': 'sbb.environments.jenkins-descriptor-job'},
            {'k': 'pg', 'name': 'PostgreSQL', 'kind': 'System software', 'layer': 'technology', 'x': 760, 'y': 40, 'pl': 'both', 'id': 'sbb.environments.postgresql'},
            {'k': 'argo', 'name': 'ArgoCD', 'kind': 'System software', 'layer': 'technology', 'x': 760, 'y': 190, 'pl': 'both', 'id': 'std.argocd'},
            {'k': 'devops', 'name': 'DevOps platform', 'kind': 'Technology service', 'layer': 'technology', 'x': 760, 'y': 330, 'pl': 'both', 'id': 'std.devops-platform'},
        ],
        'edges': [
            ('dev', 'ui', 'uses', 'both'), ('rm', 'ui', 'approves in', 'both'), ('ui', 'api', 'calls', 'both'),
            ('api', 'pg', 'stores in', 'both'), ('api', 'res', 'exposes', 'target'), ('api', 'pr', 'opens', 'target'),
            ('pr', 'argo', 'synced by', 'target'), ('api', 'job', 'triggers', 'base'), ('job', 'argo', 'updates', 'base'),
            ('job', 'devops', 'runs on', 'base'), ('pr', 'devops', 'reviewed on', 'target'),
        ],
    },
    'credit-request': {
        'name': 'Credit request', 'slug': 'credit-request', 'portfolio': 'Request', 'owners': 'Karim Ouali · Request team',
        'modes': ['target'], 'plateaus': 'target only',
        'nodes': [
            {'k': 'portal', 'name': 'Advisor portal', 'kind': 'Application component', 'layer': 'application', 'x': 24, 'y': 40, 'pl': 'both', 'ext': True, 'id': 'sbb.advisor-portal.app'},
            {'k': 'rapi', 'name': 'Credit request API', 'kind': 'Application component', 'layer': 'application', 'x': 266, 'y': 40, 'pl': 'both', 'id': 'sbb.credit-request.backend'},
            {'k': 'wf', 'name': 'Request workflow', 'kind': 'Application process', 'layer': 'application', 'x': 508, 'y': 40, 'pl': 'both', 'id': 'sbb.credit-request.workflow'},
            {'k': 'cref', 'name': 'Client referential', 'kind': 'Application component', 'layer': 'application', 'x': 266, 'y': 220, 'pl': 'both', 'ext': True, 'id': 'sbb.client-referential.api'},
            {'k': 'kafka', 'name': 'Kafka', 'kind': 'System software', 'layer': 'technology', 'x': 760, 'y': 40, 'pl': 'both', 'id': 'std.kafka'},
            {'k': 'rpg', 'name': 'PostgreSQL', 'kind': 'System software', 'layer': 'technology', 'x': 508, 'y': 220, 'pl': 'both', 'id': 'sbb.credit-request.postgresql'},
        ],
        'edges': [('portal', 'rapi', 'submits to', 'both'), ('rapi', 'wf', 'starts', 'both'), ('wf', 'kafka', 'publishes to', 'both'),
                  ('rapi', 'cref', 'reads the client', 'both'), ('rapi', 'rpg', 'stores in', 'both')],
    },
    'facility-management': {
        'name': 'Facility management', 'slug': 'facility-management', 'portfolio': 'Facility', 'owners': 'Lucas Bernard · Facility team',
        'modes': ['target'], 'plateaus': 'target only',
        'nodes': [
            {'k': 'req', 'name': 'Credit request API', 'kind': 'Application component', 'layer': 'application', 'x': 24, 'y': 40, 'pl': 'both', 'ext': True, 'id': 'sbb.credit-request.backend'},
            {'k': 'eng', 'name': 'Facility engine', 'kind': 'Application component', 'layer': 'application', 'x': 300, 'y': 40, 'pl': 'both', 'id': 'sbb.facility-management.engine'},
            {'k': 'exp', 'name': 'Facility exports', 'kind': 'Application component', 'layer': 'application', 'x': 300, 'y': 220, 'pl': 'both', 'id': 'sbb.facility-exports.export-job', 'inferred': True},
            {'k': 'ora', 'name': 'Oracle', 'kind': 'System software', 'layer': 'technology', 'x': 576, 'y': 40, 'pl': 'both', 'id': 'std.oracle'},
            {'k': 'sched', 'name': 'Batch scheduler', 'kind': 'Technology service', 'layer': 'technology', 'x': 576, 'y': 220, 'pl': 'both', 'id': 'std.batch-scheduler'},
        ],
        'edges': [('req', 'eng', 'creates facilities in', 'both'), ('eng', 'ora', 'stores in', 'both'), ('exp', 'eng', 'reads from', 'both'), ('sched', 'exp', 'runs', 'both')],
    },
}

# element details (what the panel shows and the knowledge base indexes as one document per element)
DETAIL = {
    'sbb.environments.backend': {'owner': 'Environments team', 'desc': 'Reserves and deploys environments. In the target it exposes the Reservation API and opens descriptor pull requests instead of triggering the Jenkins job.',
        'realizes': 'abb.environments.environment-management', 'dd': ['dd.environments.domain', 'dd.environments.ports', 'dd.environments.application', 'dd.environments.infrastructure', 'dd.environments.api'],
        'contract': 'environments-back/contracts/deployments.openapi.yaml', 'adr': 'ADR-ENV-07 · Descriptors change through pull requests', 'origin': 'authored'},
    'sbb.environments.reservation-api': {'owner': 'Environments team', 'desc': 'Reserve, extend and release an environment for a module, with a reason and an end date.',
        'realizes': 'abb.environments.reservation', 'dd': ['dd.environments.api', 'dd.environments.domain'], 'contract': 'environments-back/contracts/deployments.openapi.yaml#createReservation', 'adr': 'ADR-ENV-09 · One reservation per module and environment', 'origin': 'authored'},
    'sbb.environments.descriptor-pr': {'owner': 'Environments team', 'desc': 'A deployment changes the environment descriptor through an auto-merge pull request; ArgoCD syncs it.',
        'realizes': 'abb.environments.deployment', 'dd': ['dd.environments.infrastructure'], 'contract': '', 'adr': 'ADR-ENV-07 · Descriptors change through pull requests', 'origin': 'authored'},
    'sbb.environments.jenkins-descriptor-job': {'owner': 'Environments team', 'desc': 'Baseline only: a Jenkins job edits descriptors directly. Retired by work package imp.delivery-platform.gitops-descriptors.',
        'realizes': 'abb.environments.deployment', 'dd': [], 'contract': '', 'adr': 'ADR-ENV-07 · Descriptors change through pull requests', 'origin': 'extracted'},
    'sbb.environments.frontend': {'owner': 'Environments team', 'desc': 'The Environments feature in AIToolbox: environments, reservations, deployments and approvals.',
        'realizes': 'abb.environments.environment-management', 'dd': ['dd.environments.frontend-structure'], 'contract': 'consumes environments/backend:deployments.openapi.yaml', 'adr': '', 'origin': 'authored'},
    'sbb.facility-exports.export-job': {'owner': 'Facility team (from the catalog)', 'desc': 'Nightly export of facilities and limits to reporting. Documented from its code; no architect has authored it yet.',
        'realizes': '—', 'dd': [], 'contract': '', 'adr': '', 'origin': 'inferred'},
    'sbb.credit-request.backend': {'owner': 'Request team', 'desc': 'Takes credit requests from advisors, reads the client from the client referential and starts the request workflow.',
        'realizes': 'abb.request.credit-request-intake', 'dd': [], 'contract': 'credit-request/contracts/requests.openapi.yaml', 'adr': 'ADR-REQ-03 · The client is read, never copied', 'origin': 'authored'},
}

def dd(id_, title, layer, module, sections, path):
    return {'id': id_, 'title': title, 'layer': layer, 'module': module, 'sections': sections, 'path': path}

DDS = {
    'dd.environments.domain': dd('dd.environments.domain', 'Environments API · Domain', 'Domain', 'environments/backend', [
        {'h': 'Responsibilities', 'b': ['Owns environments, reservations and deployments as aggregates.', 'Decides whether a deployment may start: the reservation, the promotion window and the approvals.', 'Never calls the DevOps platform: the application layer does, through a port.']},
        {'h': 'Reservation lifecycle', 'p': 'A reservation belongs to one module and one environment, with a reason and an end date.',
         'chain': [['Requested', 'by a developer'], ['Active', 'until the end date'], ['Expiring', '24 h before, owner notified'], ['Released', 'back to the pool']]},
        {'h': 'Invariants', 'b': ['One active reservation per module and environment.', 'A reservation can be extended once, by up to 5 days.', 'A deployment on a released reservation is refused.']},
        {'h': 'Main use case · Reserve an environment', 'seq': [['Developer', 'Environments UI', 'Reserve staging-2 until Friday'], ['Environments UI', 'Reservation API', 'POST /reservations'], ['Reservation API', 'Domain', 'reserve(module, env, until, reason)'], ['Domain', 'PostgreSQL', 'save Reservation (Active)'], ['Domain', 'Environments UI', 'ReservationCreated event']]},
        {'h': 'Local decisions', 'rows': [['Expiry is computed, not scheduled', 'No timer per reservation; a query finds those ending in 24 h.', 'local'], ['One reservation per module and environment', 'Avoids two teams deploying over each other.', 'ADR-ENV-09']]},
    ], 'environments-back/architecture/dd/domain.md'),
    'dd.environments.ports': dd('dd.environments.ports', 'Environments API · Ports', 'Ports', 'environments/backend', [
        {'h': 'Inbound ports', 'rows': [['ReserveEnvironment', 'use case', 'from the Reservation API'], ['DeployModule', 'use case', 'from the deployments API and Sweep'], ['ApproveDeployment', 'use case', 'from Environments UI']]},
        {'h': 'Outbound ports', 'rows': [['DescriptorRepository', 'opens a descriptor pull request', 'DevOps platform'], ['ReservationStore', 'persists reservations', 'PostgreSQL'], ['Notifier', 'expiry and approval notices', 'Teams, email']]},
    ], 'environments-back/architecture/dd/ports.md'),
    'dd.environments.application': dd('dd.environments.application', 'Environments API · Application', 'Application', 'environments/backend', [
        {'h': 'Use cases', 'b': ['Reserve, extend and release an environment.', 'Deploy a module branch: check the reservation, open the descriptor pull request, follow the first rollout.', 'Approve a deployment inside a promotion window.']},
        {'h': 'Deploy a module', 'chain': [['Check', 'reservation and window'], ['Open PR', 'descriptor change'], ['Auto-merge', 'when checks pass'], ['ArgoCD sync', 'first rollout followed']]},
    ], 'environments-back/architecture/dd/application.md'),
    'dd.environments.infrastructure': dd('dd.environments.infrastructure', 'Environments API · Infrastructure', 'Infrastructure', 'environments/backend', [
        {'h': 'Adapters', 'rows': [['DevOpsDescriptorAdapter', 'DescriptorRepository', 'DevOps platform REST, through CTX-INT'], ['JpaReservationStore', 'ReservationStore', 'PostgreSQL 16'], ['TeamsNotifier', 'Notifier', 'Microsoft Teams webhook']]},
        {'h': 'Runtime', 'b': ['Kubernetes, 2 replicas per environment class.', 'Credentials for the DevOps platform stay in CTX-INT; the service never holds them.']},
    ], 'environments-back/architecture/dd/infrastructure.md'),
    'dd.environments.api': dd('dd.environments.api', 'Environments API · API', 'API', 'environments/backend', [
        {'h': 'Operations', 'rows': [['POST /reservations', 'createReservation', 'new in target'], ['POST /reservations/{id}/extend', 'extendReservation', 'new in target'], ['POST /deployments', 'createDeployment', 'changed: returns the pull request'], ['GET /environments', 'listEnvironments', '']]},
        {'h': 'Contract', 'p': 'The contract is the source of truth: deployments.openapi.yaml. This page names the operations and never copies fields.'},
    ], 'environments-back/architecture/dd/api.md'),
    'dd.environments.frontend-structure': dd('dd.environments.frontend-structure', 'Environments UI · Structure', 'Front-end structure', 'environments/frontend', [
        {'h': 'Pages', 'rows': [['Environments', '/environments', 'list, reserve, deploy'], ['Approvals', '/environments/approvals', 'promotion windows']]},
        {'h': 'Consumes', 'b': ['environments/backend:deployments.openapi.yaml#createReservation', 'environments/backend:deployments.openapi.yaml#createDeployment']},
    ], 'environments-front/architecture/dd/frontend-structure.md'),
}

def _clip(ax, ay, bx, by):
    """Point where the segment from the centre of A to the centre of B leaves A's box."""
    dx, dy = bx - ax, by - ay
    if dx == 0 and dy == 0:
        return ax, ay
    tx = (NW / 2) / abs(dx) if dx else 1e9
    ty = (NH / 2) / abs(dy) if dy else 1e9
    t = min(tx, ty)
    return ax + dx * t, ay + dy * t

def visible(node_pl, mode):
    return mode == 'gap' or node_pl == 'both' or node_pl == mode

def height(a):
    return max(n['y'] for n in a['nodes']) + NH + 24

def svg(app_key, mode):
    a = APPS[app_key]; uid = f'{app_key}-{mode}'; VBH = height(a)
    nodes = {n['k']: n for n in a['nodes']}
    out = [f'<svg viewBox="0 0 {VBW} {VBH}" role="img" aria-label="{a["name"]} view, {dict(base="baseline", target="target", gap="gap baseline to target")[mode]}" xmlns="http://www.w3.org/2000/svg">',
           f'<defs><marker id="ar-{uid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M1 1L9 5L1 9" fill="none" stroke="#48454E" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></marker>'
           f'<marker id="ag-{uid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M1 1L9 5L1 9" fill="none" stroke="#B9B4BE" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></marker></defs>']
    labels = []
    for (s_, t_, lab, pl) in a['edges']:
        if not visible(pl, mode):
            continue
        A, B = nodes[s_], nodes[t_]
        ax, ay = A['x'] + NW / 2, A['y'] + NH / 2
        bx, by = B['x'] + NW / 2, B['y'] + NH / 2
        x1, y1 = _clip(ax, ay, bx, by); x2, y2 = _clip(bx, by, ax, ay)
        faded = mode == 'gap' and pl == 'both'
        gone = mode == 'gap' and pl == 'base'
        new = mode == 'gap' and pl == 'target'
        col = '#B9B4BE' if (faded or gone) else ('#35307E' if new else '#48454E')
        dash = ' stroke-dasharray="6 5"' if gone else ''
        mk = 'ag' if (faded or gone) else 'ar'
        out.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{col}" stroke-width="{2 if new else 1.5}"{dash} marker-end="url(#{mk}-{uid})"/>')
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        if abs(y2 - y1) < 2: my -= 11
        labels.append(f'<text x="{mx:.1f}" y="{my + 4:.1f}" text-anchor="middle" font-family="Open Sans, system-ui, sans-serif" font-size="11.5" fill="{"#79757F" if (faded or gone) else "#48454E"}" paint-order="stroke" stroke="#FFFFFF" stroke-width="5" stroke-linejoin="round">{lab}</text>')
    for n in a['nodes']:
        if not visible(n['pl'], mode):
            continue
        fill, ink, _ = LAYER[n['layer']]
        rx = 12 if n['kind'].lower().replace(' ', '-') in ROUNDED else 3
        op = 1
        dash = ''
        badge = ''
        if mode == 'gap':
            if n['pl'] == 'both' and not n.get('chg'):
                op = .45
            elif n['pl'] == 'base':
                op = .5; dash = ' stroke-dasharray="7 5"'; badge = 'Retired'
            elif n['pl'] == 'target':
                dash = ' stroke-dasharray="7 5"'; badge = 'New'
            elif n.get('chg'):
                dash = ' stroke-dasharray="2 4"'; badge = 'Changed'
        elif mode == 'target' and n['pl'] == 'target' and 'base' in a['modes']:
            badge = 'New'
        if n.get('ext'):
            dash = dash or ' stroke-dasharray="3 3"'
        sw = 2.5 if badge else 1.5
        g = [f'<g opacity="{op}">', f'<rect x="{n["x"]}" y="{n["y"]}" width="{NW}" height="{NH}" rx="{rx}" fill="{fill}" stroke="{ink}" stroke-width="{sw}"{dash}/>',
             f'<text x="{n["x"] + 12}" y="{n["y"] + 27}" font-family="Manrope, Segoe UI, system-ui, sans-serif" font-size="13.5" font-weight="700" fill="#1C1B1E">{n["name"]}</text>',
             f'<text x="{n["x"] + 12}" y="{n["y"] + 46}" font-family="Open Sans, system-ui, sans-serif" font-size="11.5" fill="{ink}">{"External application" if n.get("ext") else n["kind"]}{" · inferred" if n.get("inferred") else ""}</text>']
        if badge:
            bw = 8 + 7 * len(badge)
            bx = n['x'] + NW - bw - 6
            g.append(f'<rect x="{bx}" y="{n["y"] - 10}" width="{bw}" height="20" rx="10" fill="#35307E"/><text x="{bx + bw / 2}" y="{n["y"] + 4}" text-anchor="middle" font-family="Manrope, Segoe UI, system-ui, sans-serif" font-size="11" font-weight="700" fill="#FFFFFF">{badge}</text>')
        g.append('</g>')
        out.extend(g)
    out.extend(labels)
    out.append('</svg>')
    return ''.join(out)

def js_data():
    apps = {}
    for k, a in APPS.items():
        apps[k] = {kk: a[kk] for kk in ('name', 'slug', 'portfolio', 'owners', 'modes', 'plateaus')}
        H = height(a); apps[k]['h'] = H
        apps[k]['nodes'] = [dict(n, box=[round(n['x'] / VBW * 100, 3), round(n['y'] / H * 100, 3), round(NW / VBW * 100, 3), round(NH / H * 100, 3)]) for n in a['nodes']]
    return json.dumps({'apps': apps, 'detail': DETAIL, 'dds': DDS}, ensure_ascii=False)

DIAGRAM_KEYS = [(k, m) for k, a in APPS.items() for m in a['modes']]

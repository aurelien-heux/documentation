"""Data for the Docs lab architecture space: a practical example, the Corporate credit platform, a microservice
application for the corporate credit business, owned by the Request, Client and Facility teams.

The model is TOGAF / ArchiMate as data, drawn with the AIToolbox ArchiMate notation (archimate_ds): every element has a
design-system type (layer → colour, aspect → shape, type → glyph), every relationship an ArchiMate relationship type
(line style and end markers). One LikeC4 view per ADM phase and plateau (landscape, motivation, value stream,
application cooperation, data, deployment, migration), as LikeC4 generates them from the model; gap views compare two
plateaus. Every fact in a picture also exists as text the knowledge base can index."""
import json
import archimate_ds as AX

PL_NAME = {'base': 'Baseline', 'tr1': 'Transition 1', 'target': 'Target'}
PL_ID = {'base': 'baseline', 'tr1': 'transition_1', 'target': 'target'}
PL_TAG = {'base': '#baseline', 'tr1': '#transition-1', 'target': '#target'}
ALL = ['base', 'tr1', 'target']
GAPS = {'gap-base-tr1': ('base', 'tr1'), 'gap-tr1-target': ('tr1', 'target'), 'gap-base-target': ('base', 'target')}
FW, FH = 176, 72          # design-system figure, size M

def N(k, name, kind, c, r, pl=ALL, **kw):
    assert kind in AX.TYPES, kind
    d = {'k': k, 'name': name, 'kind': kind, 'c': c, 'r': r, 'pl': list(pl)}
    d.update(kw)
    return d

def E(s, t, rel, label='', pl=ALL):
    assert rel in AX.RELS, rel
    return (s, t, rel, label, list(pl))

# ------------------------------------------------------------------------------------------------------------------
# Views. Grid coordinates (column, row); cw / rh = column and row pitch in px. groups = LikeC4 compound nodes,
# drawn as ArchiMate groupings: (label, first column, last column, last row).
# ------------------------------------------------------------------------------------------------------------------
VIEWS = {
    'landscape': {
        'title': 'Landscape', 'phase': 'enterprise', 'sub': 'Applications of the corporate credit business, by portfolio',
        'modes': ['base', 'tr1', 'target', 'gap'], 'cw': 264, 'rh': 132, 'top': 112,
        'groups': [('Request portfolio', 0, 0, 2), ('Client portfolio', 1, 1, 2), ('Facility portfolio', 2, 2, 2), ('Shared and external', 3, 3, 2)],
        'nodes': [
            N('portal', 'Advisor portal', 'Application component', 0, 0, owner='Request team', id='app.advisor-portal'),
            N('mono', 'Credit origination', 'Application component', 0, 1, ['base', 'tr1'], chg=['base-tr1'], owner='Request team', id='app.credit-origination'),
            N('ccp', 'Corporate credit platform', 'Application component', 0, 2, ['tr1', 'target'], owner='Request, Client and Facility teams', id='app.corporate-credit'),
            N('cref', 'Client referential', 'Application component', 1, 0, owner='Client team', id='app.client-referential'),
            N('reng', 'Rating engine', 'Application component', 1, 1, ['base', 'tr1'], owner='Client team', id='app.rating-engine'),
            N('fcore', 'Facility core', 'Application component', 2, 0, ['base', 'tr1'], owner='Facility team', id='app.facility-core'),
            N('creg', 'Collateral register', 'Application component', 2, 1, ['base', 'tr1'], owner='Facility team', id='app.collateral-register'),
            N('lake', 'Data lake', 'Application component', 3, 0, owner='Data team', id='app.data-lake', ext=True),
            N('ledger', 'Core banking ledger', 'Application component', 3, 2, owner='Core banking', id='app.core-banking-ledger', ext=True),
        ],
        'edges': [E('mono', 'portal', 'serving', 'serves', ['base', 'tr1']), E('ccp', 'portal', 'serving', 'serves', ['tr1', 'target']),
                  E('mono', 'ccp', 'serving', 'facility set-up', ['tr1']),
                  E('cref', 'mono', 'serving', 'client data', ['base']), E('cref', 'ccp', 'serving', 'client data', ['tr1', 'target']),
                  E('reng', 'mono', 'serving', 'rating', ['base']), E('reng', 'ccp', 'serving', 'rating', ['tr1']),
                  E('creg', 'mono', 'serving', 'collateral', ['base', 'tr1']), E('mono', 'fcore', 'flow', 'facilities', ['base', 'tr1']),
                  E('fcore', 'lake', 'flow', 'nightly export', ['base', 'tr1']), E('fcore', 'ledger', 'flow', 'bookings', ['base', 'tr1']),
                  E('ccp', 'ledger', 'flow', 'bookings', ['target']), E('ccp', 'lake', 'flow', 'events', ['tr1', 'target'])],
    },
    'motivation': {
        'title': 'Motivation', 'phase': 'A', 'sub': 'Why the platform changes: stakeholders, drivers, goals, principles, requirements',
        'modes': ['target'], 'cw': 248, 'rh': 140, 'top': 88, 'groups': [],
        'nodes': [
            N('st1', 'Corporate clients', 'Stakeholder', 0, 0, id='mot.cc.corporate-clients'),
            N('dr1', 'Decisions take 15 days', 'Driver', 1, 0, id='mot.cc.decision-time'),
            N('dr2', 'EBA loan origination guidelines', 'Driver', 2, 0, id='mot.cc.eba-loan-origination'),
            N('st2', 'Credit risk', 'Stakeholder', 3, 0, id='mot.cc.credit-risk'),
            N('p1', 'Read client data, never copy it', 'Principle', 0, 1, id='mot.ent.read-never-copy'),
            N('g1', 'Decide in 5 days', 'Goal', 1, 1, id='mot.cc.decide-in-5-days'),
            N('g2', 'One view of exposure', 'Goal', 2, 1, id='mot.cc.one-view-of-exposure'),
            N('p2', 'Events over batch', 'Principle', 3, 1, id='mot.ent.events-over-batch'),
            N('r1', 'Decision in 5 working days', 'Requirement', 0, 2, id='req.corporate-credit.decision-time'),
            N('r2', 'Limit check before the decision', 'Requirement', 1, 2, id='req.corporate-credit.limit-check'),
            N('r3', 'Four-eyes above 5 M EUR', 'Requirement', 2, 2, id='req.corporate-credit.four-eyes'),
            N('r4', 'Every decision traceable', 'Requirement', 3, 2, id='req.corporate-credit.audit'),
        ],
        'edges': [E('st1', 'dr1', 'association', 'concerned by'), E('st2', 'dr2', 'association', 'concerned by'),
                  E('dr1', 'g1', 'influence'), E('dr2', 'g2', 'influence'),
                  E('r1', 'g1', 'realization'), E('r2', 'g1', 'realization'), E('r3', 'g2', 'realization'), E('r4', 'g2', 'realization'),
                  E('p1', 'r1', 'influence'), E('p2', 'r4', 'influence')],
    },
    'business': {
        'title': 'Value stream', 'phase': 'B', 'sub': 'The corporate credit value stream, who performs each stage, which services serve them',
        'modes': ['target'], 'cw': 216, 'rh': 140, 'top': 88, 'groups': [],
        'nodes': [
            N('s1', 'Request', 'Value stream', 0, 0, id='str.cc.request'),
            N('s2', 'Analyse', 'Value stream', 1, 0, id='str.cc.analyse'),
            N('s3', 'Decide', 'Value stream', 2, 0, id='str.cc.decide'),
            N('s4', 'Contract', 'Value stream', 3, 0, id='str.cc.contract'),
            N('s5', 'Set up the facility', 'Value stream', 4, 0, id='str.cc.set-up'),
            N('s6', 'Monitor', 'Value stream', 5, 0, id='str.cc.monitor'),
            N('a1', 'Relationship manager', 'Business role', 0, 1, id='bus.cc.relationship-manager'),
            N('a2', 'Credit analyst', 'Business role', 1, 1, id='bus.cc.credit-analyst'),
            N('a3', 'Credit committee', 'Business role', 2, 1, id='bus.cc.credit-committee'),
            N('a5', 'Facility officer', 'Business role', 4, 1, id='bus.cc.facility-officer'),
            N('v1', 'Credit request', 'Application service', 0, 2, id='sbb.corporate-credit.credit-request-api'),
            N('v2', 'Rating', 'Application service', 1, 2, id='sbb.corporate-credit.rating-api'),
            N('v3', 'Credit decision', 'Application service', 2, 2, id='sbb.corporate-credit.decision-api'),
            N('v4', 'Contract drafting', 'Application service', 3, 2, id='sbb.corporate-credit.document-api'),
            N('v5', 'Facility set-up', 'Application service', 4, 2, id='sbb.corporate-credit.facility-api'),
            N('v6', 'Limit check', 'Application service', 5, 2, id='sbb.corporate-credit.limit-api'),
        ],
        'edges': [E('s1', 's2', 'flow'), E('s2', 's3', 'flow'), E('s3', 's4', 'flow'), E('s4', 's5', 'flow'), E('s5', 's6', 'flow'),
                  E('a1', 's1', 'assignment'), E('a2', 's2', 'assignment'), E('a3', 's3', 'assignment'), E('a5', 's5', 'assignment'),
                  E('v1', 'a1', 'serving'), E('v2', 'a2', 'serving'), E('v3', 'a3', 'serving'), E('v4', 's4', 'serving'), E('v5', 'a5', 'serving'), E('v6', 's6', 'serving')],
    },
    'application': {
        'title': 'Application cooperation', 'phase': 'C', 'sub': 'The microservices and how they work together',
        'modes': ['base', 'tr1', 'target', 'gap'], 'cw': 264, 'rh': 136, 'top': 88, 'groups': [],
        'nodes': [
            N('portal', 'Advisor portal', 'Application component', 0, 0, ext=True, id='app.advisor-portal'),
            N('gw', 'API gateway', 'Application interface', 1, 0, ['tr1', 'target'], id='sbb.corporate-credit.api-gateway', wp='wp1'),
            N('req', 'credit-request-service', 'Application component', 2, 0, ['tr1', 'target'], id='sbb.corporate-credit.credit-request-service', wp='wp1'),
            N('cli', 'client-service', 'Application component', 3, 0, ['tr1', 'target'], id='sbb.corporate-credit.client-service', wp='wp1'),
            N('cref', 'Client referential', 'Application component', 4, 0, ext=True, id='app.client-referential'),
            N('mono', 'Credit origination', 'Application component', 0, 1, ['base', 'tr1'], chg=['base-tr1'], id='app.credit-origination', wp='wp4'),
            N('rat', 'rating-service', 'Application component', 1, 1, ['target'], id='sbb.corporate-credit.rating-service', wp='wp2'),
            N('wf', 'decision-workflow', 'Application process', 2, 1, ['tr1', 'target'], id='sbb.corporate-credit.decision-workflow', wp='wp1'),
            N('doc', 'document-service', 'Application component', 3, 1, ['target'], id='sbb.corporate-credit.document-service', wp='wp2'),
            N('reng', 'Rating engine', 'Application component', 4, 1, ['base', 'tr1'], id='app.rating-engine', wp='wp2'),
            N('lim', 'limit-service', 'Application component', 1, 2, ['target'], id='sbb.corporate-credit.limit-service', wp='wp2'),
            N('fac', 'facility-service', 'Application component', 2, 2, ['target'], id='sbb.corporate-credit.facility-service', wp='wp2'),
            N('col', 'collateral-service', 'Application component', 3, 2, ['target'], id='sbb.corporate-credit.collateral-service', wp='wp2'),
            N('creg', 'Collateral register', 'Application component', 0, 3, ['base', 'tr1'], id='app.collateral-register', wp='wp2'),
            N('fcore', 'Facility core', 'Application component', 1, 3, ['base', 'tr1'], id='app.facility-core', wp='wp4'),
            N('ledger', 'Core banking ledger', 'Application component', 2, 3, ext=True, id='app.core-banking-ledger'),
            N('kafka', 'cc.events', 'Application event', 4, 3, ['tr1', 'target'], id='sbb.corporate-credit.events', wp='wp1'),
            N('exp', 'Nightly facility exports', 'Application process', 1, 4, ['base', 'tr1'], id='app.facility-exports', wp='wp3'),
            N('lake', 'Data lake', 'Application component', 4, 4, ext=True, id='app.data-lake'),
        ],
        'edges': [
            E('mono', 'portal', 'serving', 'serves', ['base']), E('cref', 'mono', 'serving', 'client data', ['base']), E('reng', 'mono', 'serving', 'rating', ['base']),
            E('creg', 'mono', 'serving', 'collateral', ['base', 'tr1']), E('mono', 'fcore', 'flow', 'facilities', ['base', 'tr1']),
            E('fcore', 'ledger', 'flow', 'bookings', ['base', 'tr1']), E('fcore', 'exp', 'flow', 'facilities', ['base', 'tr1']), E('exp', 'lake', 'flow', 'nightly load', ['base', 'tr1']),
            E('gw', 'portal', 'serving', 'serves', ['tr1', 'target']), E('gw', 'req', 'flow', 'routes', ['tr1', 'target']), E('cli', 'req', 'serving', 'client', ['tr1', 'target']),
            E('cref', 'cli', 'serving', 'client data', ['tr1', 'target']), E('req', 'wf', 'triggering', 'starts', ['tr1', 'target']),
            E('mono', 'wf', 'serving', 'facility set-up', ['tr1']), E('reng', 'wf', 'serving', 'rating', ['tr1']), E('wf', 'kafka', 'triggering', 'publishes', ['tr1']),
            E('rat', 'wf', 'serving', 'rating', ['target']), E('doc', 'wf', 'serving', 'contract', ['target']), E('lim', 'wf', 'serving', 'limit check', ['target']),
            E('wf', 'fac', 'triggering', 'set up', ['target']), E('fac', 'lim', 'flow', 'books limit', ['target']), E('col', 'fac', 'serving', 'collateral', ['target']),
            E('fac', 'ledger', 'flow', 'bookings', ['target']), E('fac', 'kafka', 'triggering', 'publishes', ['target']), E('kafka', 'lake', 'flow', 'streams', ['tr1', 'target']),
        ],
    },
    'data': {
        'title': 'Data', 'phase': 'C', 'sub': 'Business data and the service that owns each',
        'modes': ['target'], 'cw': 248, 'rh': 140, 'top': 88, 'groups': [],
        'nodes': [
            N('d2', 'Client', 'Data object', 0, 0, owner='client-service', id='data.cc.client'),
            N('d1', 'Credit request', 'Data object', 1, 0, owner='credit-request-service', id='data.cc.credit-request'),
            N('d3', 'Rating', 'Data object', 2, 0, owner='rating-service', id='data.cc.rating'),
            N('d8', 'Credit event', 'Data object', 3, 0, owner='cc.events (Kafka)', id='data.cc.credit-event'),
            N('d5', 'Limit', 'Data object', 0, 1, owner='limit-service', id='data.cc.limit'),
            N('d4', 'Facility', 'Data object', 1, 1, owner='facility-service', id='data.cc.facility'),
            N('d6', 'Collateral', 'Data object', 2, 1, owner='collateral-service', id='data.cc.collateral'),
            N('d7', 'Contract', 'Data object', 1, 2, owner='document-service', id='data.cc.contract'),
        ],
        'edges': [E('d1', 'd2', 'association', 'for'), E('d1', 'd3', 'association', 'uses'), E('d4', 'd1', 'association', 'results from'),
                  E('d4', 'd5', 'association', 'consumes'), E('d4', 'd6', 'association', 'secured by'), E('d7', 'd4', 'association', 'formalises'),
                  E('d8', 'd4', 'association', 'about')],
    },
    'technology': {
        'title': 'Deployment', 'phase': 'D', 'sub': 'Where the platform runs',
        'modes': ['base', 'target', 'gap'], 'cw': 248, 'rh': 140, 'top': 120,
        'groups': [('OpenShift cluster · cc-prod', 1, 2, 1)],
        'nodes': [
            N('lb', 'API gateway (Kong)', 'Technology service', 0, 0, ['target'], id='std.kong'),
            N('ns1', 'Namespace cc-request', 'Node', 1, 0, ['target'], id='tec.cc.ns-request'),
            N('ns2', 'Namespace cc-client', 'Node', 2, 0, ['target'], id='tec.cc.ns-client'),
            N('pg', 'PostgreSQL 16', 'System software', 3, 0, ['target'], id='std.postgresql'),
            N('wls', 'WebLogic server', 'Node', 0, 1, ['base'], id='tec.cc.weblogic'),
            N('ns3', 'Namespace cc-facility', 'Node', 1, 1, ['target'], id='tec.cc.ns-facility'),
            N('kaf', 'Kafka', 'System software', 2, 1, ['target'], id='std.kafka'),
            N('vault', 'Vault', 'System software', 3, 1, ['target'], id='std.vault'),
            N('ora', 'Oracle 12c', 'System software', 0, 2, ['base'], id='tec.cc.oracle'),
            N('batch', 'Batch scheduler', 'Technology service', 1, 2, ['base'], id='std.batch-scheduler'),
            N('argo', 'ArgoCD', 'System software', 2, 2, ['target'], id='std.argocd'),
        ],
        'edges': [E('lb', 'ns1', 'serving', 'routes', ['target']), E('ns1', 'kaf', 'flow', 'events', ['target']), E('ns3', 'kaf', 'flow', 'events', ['target']),
                  E('pg', 'ns2', 'serving', 'stores', ['target']), E('vault', 'ns3', 'serving', 'secrets', ['target']), E('argo', 'ns3', 'serving', 'deploys', ['target']),
                  E('ora', 'wls', 'serving', 'stores', ['base']), E('batch', 'ora', 'access', 'reads', ['base'])],
    },
    'migration': {
        'title': 'Migration', 'phase': 'EF', 'sub': 'Plateaus, the gaps between them and the work packages that close them',
        'modes': ['target'], 'cw': 248, 'rh': 140, 'top': 88, 'groups': [],
        'nodes': [
            N('pb', 'Baseline · today', 'Plateau', 0, 0, id='imp.corporate-credit.baseline'),
            N('pt', 'Transition 1 · Dec 2026', 'Plateau', 2, 0, id='imp.corporate-credit.transition-1'),
            N('pg', 'Target · Jun 2027', 'Plateau', 4, 0, id='imp.corporate-credit.target'),
            N('g1', 'Strangle the monolith', 'Gap', 1, 1, id='imp.corporate-credit.gap-1'),
            N('g2', 'Retire the monolith and Oracle', 'Gap', 3, 1, id='imp.corporate-credit.gap-2'),
            N('w1', 'Extract client and request', 'Work package', 1, 2, id='imp.corporate-credit.wp1'),
            N('w2', 'Extract facility, limits, collateral', 'Work package', 2, 2, id='imp.corporate-credit.wp2'),
            N('w3', 'Events replace nightly exports', 'Work package', 3, 2, id='imp.corporate-credit.wp3'),
            N('w4', 'Retire Credit origination', 'Work package', 4, 2, id='imp.corporate-credit.wp4'),
        ],
        'edges': [E('pb', 'pt', 'triggering', 'Dec 2026'), E('pt', 'pg', 'triggering', 'Jun 2027'),
                  E('g1', 'pb', 'association'), E('g1', 'pt', 'association'), E('g2', 'pt', 'association'), E('g2', 'pg', 'association'),
                  E('w1', 'g1', 'realization', 'closes'), E('w2', 'g2', 'realization'), E('w3', 'g2', 'realization'), E('w4', 'g2', 'realization')],
    },
}
VIEW_ORDER = ['landscape', 'motivation', 'business', 'application', 'data', 'technology', 'migration']
PHASES = [('enterprise', 'Enterprise', 'Portfolio of applications'), ('A', 'Phase A · Architecture vision', 'Why the change'),
          ('B', 'Phase B · Business architecture', 'Who does what'), ('C', 'Phase C · Information systems', 'Applications and data'),
          ('D', 'Phase D · Technology architecture', 'Where it runs'), ('EF', 'Phases E–F · Opportunities and migration', 'How we get there')]

# ------------------------------------------------------------------------------------------------------------------
# Element details: what the panel shows and the knowledge base indexes, one document per element
# ------------------------------------------------------------------------------------------------------------------
def svc(owner, desc, realizes, dd, contract, adrs, origin='authored', arb=''):
    return {'owner': owner, 'desc': desc, 'realizes': realizes, 'dd': dd, 'contract': contract, 'adrs': adrs, 'origin': origin, 'arb': arb}

DETAIL = {
    'sbb.corporate-credit.credit-request-service': svc('Request team', 'Takes a corporate credit request from the advisor portal, reads the client from client-service and starts the decision workflow.', 'abb.corporate-credit.request-intake', ['dd.cc-request.domain', 'dd.cc-request.api'], 'credit-request-service/contracts/requests.openapi.yaml', ['ADR-CC-01', 'ADR-CC-04'], arb='arb.request.2026-09'),
    'sbb.corporate-credit.decision-workflow': svc('Request team', 'Runs the decision: rating, limit check, four-eyes approval above 5 M EUR, contract, facility set-up. Camunda process.', 'abb.corporate-credit.credit-decision', [], 'decision-workflow/bpmn/corporate-credit.bpmn', ['ADR-CC-03'], arb='arb.request.2026-09'),
    'sbb.corporate-credit.client-service': svc('Client team', 'The client as the credit platform sees it: legal entity, group, KYC status. Reads the client referential; never copies it.', 'abb.corporate-credit.client-view', [], 'client-service/contracts/clients.openapi.yaml', ['ADR-CC-04'], arb='arb.request.2026-09'),
    'sbb.corporate-credit.rating-service': svc('Client team', 'Internal rating of a corporate client, from financial statements and group links. Replaces the rating engine.', 'abb.corporate-credit.rating', [], 'rating-service/contracts/ratings.openapi.yaml', [], arb='arb.facility.2026-14'),
    'sbb.corporate-credit.document-service': svc('Platform team', 'Drafts the credit agreement from a template and the decision; stores the signed contract.', 'abb.corporate-credit.contracting', [], 'document-service/contracts/documents.openapi.yaml', [], arb='arb.facility.2026-14'),
    'sbb.corporate-credit.facility-service': svc('Facility team', 'Sets up the facility once the contract is signed: books the limit, links collateral, books in the ledger, then follows drawdowns and reviews.', 'abb.corporate-credit.facility-management', ['dd.cc-facility.domain', 'dd.cc-facility.ports', 'dd.cc-facility.application', 'dd.cc-facility.infrastructure', 'dd.cc-facility.api'], 'facility-service/contracts/facilities.openapi.yaml', ['ADR-CC-02', 'ADR-CC-03', 'ADR-CC-06'], arb='arb.facility.2026-14'),
    'sbb.corporate-credit.limit-service': svc('Facility team', 'Holds limits per client and group and answers the limit check in real time.', 'abb.corporate-credit.limits', ['dd.cc-limit.domain'], 'limit-service/contracts/limits.asyncapi.yaml', ['ADR-CC-03'], arb='arb.facility.2026-14'),
    'sbb.corporate-credit.collateral-service': svc('Facility team', 'Collateral linked to facilities and its valuation. Detailed design not written yet.', 'abb.corporate-credit.collateral', [], '', ['ADR-CC-05'], arb='arb.facility.2026-14'),
    'sbb.corporate-credit.api-gateway': svc('Platform team', 'Single entry for the advisor portal: authentication, routing, rate limits.', 'abb.corporate-credit.channel-access', [], '', ['ADR-CC-01'], arb='arb.request.2026-09'),
    'sbb.corporate-credit.events': svc('Platform team', 'Business events of the credit lifecycle: request submitted, decision taken, facility active.', 'abb.corporate-credit.credit-events', [], 'contracts/cc-events.asyncapi.yaml', ['ADR-CC-02'], arb='arb.facility.2026-14'),
    'app.credit-origination': svc('Request team', 'The monolith that runs corporate credit today. In transition 1 it keeps facilities, limits and collateral; it is retired in the target.', '—', [], '', ['ADR-CC-01'], origin='extracted'),
    'app.facility-core': svc('Facility team', 'Oracle schema of facilities and limits used by the monolith and the nightly exports. Retired in the target.', '—', [], '', ['ADR-CC-06'], origin='extracted'),
    'app.collateral-register': svc('Facility team (from the catalog)', 'Legacy register of collateral. Documented from its code; no architect has authored it yet.', '—', [], '', [], origin='inferred'),
    'app.facility-exports': svc('Facility team', 'Nightly batch that copies facilities to the data lake. Replaced by events in the target.', '—', [], '', ['ADR-CC-02'], origin='extracted'),
    'app.rating-engine': svc('Client team', 'Legacy rating engine, replaced by rating-service in the target.', '—', [], '', [], origin='extracted'),
    'app.client-referential': svc('Client team', 'Group-wide client referential. Read through client-service from transition 1.', '—', [], '', ['ADR-CC-04']),
}

# ------------------------------------------------------------------------------------------------------------------
# Detailed design (tier 1 design intent), per service
# ------------------------------------------------------------------------------------------------------------------
def dd(id_, title, layer, module, sections, path, commit):
    return {'id': id_, 'title': title, 'layer': layer, 'module': module, 'sections': sections, 'path': path, 'commit': commit,
            'realizes': 'sbb.corporate-credit.' + module.split('/')[0]}

DDS = {
    'dd.cc-facility.domain': dd('dd.cc-facility.domain', 'facility-service · Domain', 'Domain', 'facility-service', [
        {'h': 'Responsibilities', 'b': ['Owns the Facility aggregate: amount, currency, maturity, pricing, covenants.', 'Decides when a facility may become active: contract signed, limit booked, collateral covered.', 'Never reads the client directly: the decision carries the client id and rating.']},
        {'h': 'Facility lifecycle', 'p': 'A facility is created by the decision workflow and becomes active only when it is safe to draw.',
         'chain': [['Approved', 'by the decision'], ['Contracted', 'agreement signed'], ['Active', 'limit booked, collateral ≥ 100 %'], ['Under review', 'yearly or on a covenant breach'], ['Closed', 'repaid or cancelled']]},
        {'h': 'Invariants', 'b': ['A facility is active only if its limit is booked in limit-service.', 'A secured facility needs collateral covering at least 100 % of the amount.', 'Amount and maturity never change after Active: an amendment creates a new version.']},
        {'h': 'Main use case · Set up a facility', 'seq': [['decision-workflow', 'facility-service', 'setUpFacility(decision)'], ['facility-service', 'limit-service', 'bookLimit(client, amount)'], ['facility-service', 'collateral-service', 'linkCollateral(facility)'], ['facility-service', 'Core banking ledger', 'book facility'], ['facility-service', 'cc.events', 'FacilityActivated']]},
        {'h': 'Local decisions', 'rows': [['Amendments create versions', 'Keeps the audit trail required by EBA guidelines.', 'local'], ['Limit booked before activation', 'A facility can never be drawn without a limit.', 'ADR-CC-03']]},
    ], 'facility-service/architecture/dd/domain.md', '3e91c0a · 22 Oct'),
    'dd.cc-facility.ports': dd('dd.cc-facility.ports', 'facility-service · Ports', 'Ports', 'facility-service', [
        {'h': 'Inbound ports', 'rows': [['SetUpFacility', 'use case', 'from decision-workflow'], ['AmendFacility', 'use case', 'from the facility officer screen'], ['ReviewFacility', 'use case', 'yearly schedule, covenant events']]},
        {'h': 'Outbound ports', 'rows': [['LimitBooking', 'books and releases limits', 'limit-service'], ['CollateralLink', 'links and values collateral', 'collateral-service'], ['LedgerBooking', 'books the facility', 'Core banking ledger'], ['EventPublisher', 'facility events', 'cc.events (Kafka)']]},
    ], 'facility-service/architecture/dd/ports.md', '3e91c0a · 22 Oct'),
    'dd.cc-facility.application': dd('dd.cc-facility.application', 'facility-service · Application', 'Application', 'facility-service', [
        {'h': 'Use cases', 'b': ['Set up a facility from an approved decision.', 'Amend a facility: new version, same history.', 'Review a facility every year or when a covenant is breached.']},
        {'h': 'Set up a facility', 'chain': [['Check', 'contract signed'], ['Book limit', 'limit-service'], ['Link collateral', 'collateral-service'], ['Book', 'core banking ledger'], ['Publish', 'FacilityActivated']]},
    ], 'facility-service/architecture/dd/application.md', '3e91c0a · 22 Oct'),
    'dd.cc-facility.infrastructure': dd('dd.cc-facility.infrastructure', 'facility-service · Infrastructure', 'Infrastructure', 'facility-service', [
        {'h': 'Adapters', 'rows': [['RestLimitBooking', 'LimitBooking', 'limit-service REST, idempotent'], ['KafkaEventPublisher', 'EventPublisher', 'topic cc.events, outbox pattern'], ['LedgerMqBooking', 'LedgerBooking', 'IBM MQ to the core banking ledger'], ['JpaFacilityStore', 'FacilityStore', 'PostgreSQL 16']]},
        {'h': 'Runtime', 'b': ['Namespace cc-facility on OpenShift, 3 replicas.', 'Secrets from Vault; no credential in the image.']},
    ], 'facility-service/architecture/dd/infrastructure.md', '3e91c0a · 22 Oct'),
    'dd.cc-facility.api': dd('dd.cc-facility.api', 'facility-service · API', 'API', 'facility-service', [
        {'h': 'Operations', 'rows': [['POST /facilities', 'setUpFacility', 'from decision-workflow'], ['POST /facilities/{id}/amendments', 'amendFacility', 'creates a version'], ['GET /facilities?client=', 'listFacilities', 'exposure view']]},
        {'h': 'Events', 'rows': [['FacilityActivated', 'cc.events', 'after ledger booking'], ['FacilityAmended', 'cc.events', 'new version']]},
    ], 'facility-service/architecture/dd/api.md', '3e91c0a · 22 Oct'),
    'dd.cc-request.domain': dd('dd.cc-request.domain', 'credit-request-service · Domain', 'Domain', 'credit-request-service', [
        {'h': 'Responsibilities', 'b': ['Owns the credit request: client, amount, purpose, requested structure.', 'Checks completeness before the decision starts.']},
        {'h': 'Request lifecycle', 'chain': [['Draft', 'advisor'], ['Submitted', 'complete'], ['In decision', 'workflow running'], ['Decided', 'approved or declined']]},
    ], 'credit-request-service/architecture/dd/domain.md', 'b12f7d3 · 18 Oct'),
    'dd.cc-request.api': dd('dd.cc-request.api', 'credit-request-service · API', 'API', 'credit-request-service', [
        {'h': 'Operations', 'rows': [['POST /requests', 'createRequest', ''], ['POST /requests/{id}/submit', 'submitRequest', 'starts the workflow']]},
    ], 'credit-request-service/architecture/dd/api.md', 'b12f7d3 · 18 Oct'),
    'dd.cc-limit.domain': dd('dd.cc-limit.domain', 'limit-service · Domain', 'Domain', 'limit-service', [
        {'h': 'Responsibilities', 'b': ['Holds limits per client and per group.', 'Answers a limit check in under 200 ms, before the decision.']},
        {'h': 'Limit check', 'chain': [['Request', 'client, group, amount'], ['Group exposure', 'all facilities'], ['Answer', 'within or above limit']]},
    ], 'limit-service/architecture/dd/domain.md', '7a0c2e1 · 20 Oct'),
}
SERVICES = [  # Design tab
    ('credit-request-service', 'Request team', 'sbb.corporate-credit.credit-request-service'),
    ('decision-workflow', 'Request team', 'sbb.corporate-credit.decision-workflow'),
    ('client-service', 'Client team', 'sbb.corporate-credit.client-service'),
    ('rating-service', 'Client team', 'sbb.corporate-credit.rating-service'),
    ('facility-service', 'Facility team', 'sbb.corporate-credit.facility-service'),
    ('limit-service', 'Facility team', 'sbb.corporate-credit.limit-service'),
    ('collateral-service', 'Facility team', 'sbb.corporate-credit.collateral-service'),
    ('document-service', 'Platform team', 'sbb.corporate-credit.document-service'),
]

# ------------------------------------------------------------------------------------------------------------------
# Architecture decisions (MADR)
# ------------------------------------------------------------------------------------------------------------------
ADRS = [
    {'id': 'ADR-CC-01', 't': 'Split the credit origination monolith by business capability', 'status': 'Accepted', 'date': '3 Jun 2026', 'by': 'Corporate credit architects', 'ref': 'DEC-07', 'plateau': 'Transition 1',
     'context': 'One release a month for the whole monolith; three teams wait on each other; decisions take 15 days.',
     'decision': 'Split by capability: request, client, rating, facility, limits, collateral, documents. Strangle the monolith behind an API gateway.',
     'options': ['Keep the monolith and modularise it inside', 'Split by technical layer', 'Split by capability (chosen)'],
     'consequences': ['Each team releases on its own.', 'Data is owned by one service; others read it through its API or events.', 'A transition plateau runs both the new services and the monolith.'],
     'els': ['req', 'cli', 'gw', 'mono']},
    {'id': 'ADR-CC-02', 't': 'Events on Kafka replace the nightly facility exports', 'status': 'Accepted', 'date': '12 Sep 2026', 'by': 'Facility team, Data team', 'ref': 'DEC-KB-02', 'plateau': 'Target',
     'context': 'The data lake sees facilities a day late; the export fails about twice a month and nobody owns it.',
     'decision': 'facility-service publishes FacilityActivated and FacilityAmended on cc.events with an outbox; the data lake streams the topic.',
     'options': ['Keep the batch, add monitoring', 'Change data capture on Oracle', 'Business events with an outbox (chosen)'],
     'consequences': ['Exposure is visible within a minute.', 'The nightly exports are retired with the monolith.', 'Event contracts are versioned in AsyncAPI.'],
     'els': ['kafka', 'fac', 'exp', 'lake']},
    {'id': 'ADR-CC-03', 't': 'Check limits synchronously before the decision', 'status': 'Accepted', 'date': '30 Sep 2026', 'by': 'Facility team, Credit risk', 'ref': 'req.corporate-credit.limit-check', 'plateau': 'Target',
     'context': 'Limits are checked after the decision today; some approved credits exceed the group limit.',
     'decision': 'decision-workflow calls limit-service before the committee; facility-service books the limit before activation.',
     'options': ['Check after the decision', 'Check asynchronously and alert', 'Check synchronously before the decision (chosen)'],
     'consequences': ['limit-service must answer in under 200 ms.', 'A limit-service outage pauses decisions, not requests.'],
     'els': ['wf', 'lim', 'fac']},
    {'id': 'ADR-CC-04', 't': 'Read the client from client-service, never copy it', 'status': 'Accepted', 'date': '10 Jun 2026', 'by': 'Client team', 'ref': 'mot.ent.read-never-copy', 'plateau': 'Transition 1',
     'context': 'Three copies of client data drift apart; KYC status is often stale in credit files.',
     'decision': 'Services keep only the client id and read the client from client-service, which reads the group referential.',
     'options': ['Replicate the referential nightly', 'Read through client-service (chosen)'],
     'consequences': ['One place to change client data.', 'client-service needs 99.9 % availability.'],
     'els': ['cli', 'req', 'cref']},
    {'id': 'ADR-CC-05', 't': 'Value collateral through an external provider', 'status': 'Proposed', 'date': '24 Oct 2026', 'by': 'Facility team', 'ref': '—', 'plateau': 'Target',
     'context': 'Collateral is revalued by hand once a year; real-estate values move faster.',
     'decision': 'collateral-service calls a valuation provider for real estate quarterly; other collateral stays manual.',
     'options': ['Manual valuation', 'External provider for real estate (proposed)'],
     'consequences': ['A new external dependency to contract and secure.', 'The detailed design of collateral-service must cover it.'],
     'els': ['col']},
    {'id': 'ADR-CC-06', 't': 'Keep Oracle for facilities until the target', 'status': 'Superseded', 'date': '15 Mar 2026', 'by': 'Facility team', 'ref': '—', 'plateau': 'Transition 1',
     'context': 'Moving facilities out of Oracle during transition 1 was too risky.',
     'decision': 'Facilities stay in Facility core until facility-service exists. Superseded by ADR-CC-02 for the exports.',
     'options': ['Migrate in transition 1', 'Keep until target (chosen)'],
     'consequences': ['The monolith keeps facilities in transition 1.'],
     'els': ['fcore', 'mono']},
]

# ------------------------------------------------------------------------------------------------------------------
# Plateaus, work packages, ARB submissions, ASD
# ------------------------------------------------------------------------------------------------------------------
PLATEAUS = [
    {'k': 'base', 'name': 'Baseline', 'when': 'today', 'state': 'Live', 'tile': 'ok', 'desc': 'The Credit origination monolith on WebLogic and Oracle, nightly exports to the data lake.'},
    {'k': 'tr1', 'name': 'Transition 1', 'when': 'Dec 2026', 'state': 'In progress', 'tile': 'in', 'desc': 'API gateway, credit-request-service, client-service and decision-workflow in front of the monolith.'},
    {'k': 'target', 'name': 'Target', 'when': 'Jun 2027', 'state': 'Planned', 'tile': 'ne', 'desc': 'All capabilities in services on OpenShift, events on Kafka, the monolith and Oracle retired.'},
]
WPS = {
    'wp1': {'name': 'Extract client and request', 'from': 'base', 'to': 'tr1', 'team': 'Request and Client teams', 'when': 'Jul – Dec 2026', 'state': 'In progress'},
    'wp2': {'name': 'Extract facility, limits, collateral', 'from': 'tr1', 'to': 'target', 'team': 'Facility team', 'when': 'Jan – Apr 2027', 'state': 'Planned'},
    'wp3': {'name': 'Events replace nightly exports', 'from': 'tr1', 'to': 'target', 'team': 'Facility and Data teams', 'when': 'Feb – Mar 2027', 'state': 'Planned'},
    'wp4': {'name': 'Retire Credit origination', 'from': 'tr1', 'to': 'target', 'team': 'Request team', 'when': 'May – Jun 2027', 'state': 'Planned'},
}
ARBS = [
    {'id': 'arb.facility.2026-14', 't': 'Extract facility, limits and collateral', 'from': 'tr1', 'to': 'target', 'board': '6 Nov', 'by': 'Lucas Bernard', 'status': 'In review',
     'checks': [
         ['S', 'S1–S3 · Structure', 'pass', '', False], ['T', 'T1 · new ABB realizes a requirement', 'pass', '', False],
         ['T', 'T6 · collateral-service has no detailed design', 'warn', 'Draft it from the code, or write it before the board', False],
         ['P', 'P1–P4 · plateaus and gaps', 'pass', '', False],
         ['O', 'O2 · contract missing for the limit events channel', 'fail', 'limit-service/contracts/limits.asyncapi.yaml has no channel cc.limits', True],
         ['D', 'D2 · new component collateral-service needs an ADR', 'warn', 'ADR-CC-05 is still proposed', False],
     ],
     'reviewers': [['Enterprise architecture', 'Emma Laurent', 'Pending'], ['Security', 'Hugo Martin', 'Approved'], ['Credit risk', 'Nina Rossi', 'Approve with conditions']],
     'conditions': ['limit-service answers the limit check in under 200 ms in the performance test (Credit risk)'],
     'asd': {'context': 'Second step of the corporate credit modernisation: facilities, limits and collateral leave the monolith; the nightly exports are replaced by events.',
             'need': 'Decide on a corporate credit in 5 days; check group limits before the decision; see exposure within a minute.',
             'overview': 'facility-service, limit-service and collateral-service on OpenShift; decision-workflow orchestrates; events on cc.events feed the data lake.',
             'nfr': '', 'security': 'Secrets in Vault; service-to-service mTLS; client data read from client-service only.',
             'risks': 'Ledger booking over MQ during cut-over; collateral valuation provider not contracted yet.'}},
    {'id': 'arb.request.2026-09', 't': 'Client and request services in front of the monolith', 'from': 'base', 'to': 'tr1', 'board': '24 Jul', 'by': 'Karim Ouali', 'status': 'Approved with conditions',
     'checks': [['S', 'S1–S3 · Structure', 'pass', '', False], ['T', 'T1–T6 · traceability', 'pass', '', False], ['P', 'P1–P4 · plateaus and gaps', 'pass', '', False], ['O', 'O1–O3 · ownership and contracts', 'pass', '', False], ['D', 'D1–D3 · decisions', 'pass', '', False]],
     'reviewers': [['Enterprise architecture', 'Emma Laurent', 'Approved'], ['Security', 'Hugo Martin', 'Approve with conditions'], ['Credit risk', 'Nina Rossi', 'Approved']],
     'conditions': ['Pen test of the API gateway before go-live (done 14 Oct)'], 'asd': None, 'decided': 'Recorded in Git · 5d2a9f1 · 24 Jul'},
    {'id': 'arb.client.2026-11', 't': 'rating-service replaces the rating engine', 'from': 'tr1', 'to': 'target', 'board': '20 Nov', 'by': 'Marta Kowalski', 'status': 'Draft',
     'checks': [['S', 'S1–S3 · Structure', 'pass', '', False], ['T', 'T6 · rating-service has no detailed design', 'warn', '', False]],
     'reviewers': [], 'conditions': [], 'asd': None},
]
ASD_SECTIONS = [  # 13 sections: w = written in the submission, m = assembled from the model
    ('Context and scope', 'w', 'context'), ('Business need', 'w', 'need'), ('Architecture overview', 'w', 'overview'),
    ('Requirements', 'm', 'requirements'), ('Baseline', 'm', 'baseline'), ('Target', 'm', 'target'), ('Gap and transition', 'm', 'gap'),
    ('Detailed design', 'm', 'dd'), ('Non-functional requirements', 'w', 'nfr'), ('Security', 'w', 'security'), ('Decisions', 'm', 'decisions'),
    ('Risks', 'w', 'risks'), ('Open questions', 'm', 'questions'),
]

# ------------------------------------------------------------------------------------------------------------------
# Changes: what the architecture process carries, one per work package
# ------------------------------------------------------------------------------------------------------------------
CHANGES = [
    {'k': 'wp1', 'adrs': ['ADR-CC-01', 'ADR-CC-04'], 'arbs': ['arb.request.2026-09'], 'why': 'Release request and client on their own, in front of the monolith.'},
    {'k': 'wp2', 'adrs': ['ADR-CC-03', 'ADR-CC-05'], 'arbs': ['arb.facility.2026-14', 'arb.client.2026-11'], 'why': 'Facilities, limits, collateral and rating leave the monolith.'},
    {'k': 'wp3', 'adrs': ['ADR-CC-02'], 'arbs': ['arb.facility.2026-14'], 'why': 'Exposure visible within a minute instead of the next morning.'},
    {'k': 'wp4', 'adrs': ['ADR-CC-01', 'ADR-CC-06'], 'arbs': [], 'why': 'Switch off the monolith, WebLogic and Oracle.'},
]

# ------------------------------------------------------------------------------------------------------------------
# Geometry, routing and rendering of a view
# ------------------------------------------------------------------------------------------------------------------
LEFT = 40

def modes_of(v):
    out = []
    for m in v['modes']:
        if m == 'gap':
            out += [g for g in GAPS if all(p in v['modes'] for p in GAPS[g])]
        else:
            out.append(m)
    return out

def mode_name(m):
    if m in GAPS:
        a, b = GAPS[m]
        return f'Gap · {PL_NAME[a]} → {PL_NAME[b]}'
    return PL_NAME[m]

def view_id(k, m):
    if m in GAPS:
        a, b = GAPS[m]
        return f'{k}_gap_{PL_ID[a]}_{PL_ID[b]}'
    return f'{k}_{PL_ID[m]}' if len(VIEWS[k]['modes']) > 1 else k

def pos(v, n):
    return LEFT + n['c'] * v['cw'], v['top'] + n['r'] * v['rh']

def size(v):
    cols = max(n['c'] for n in v['nodes']) + 1
    rows = max(n['r'] for n in v['nodes']) + 1
    return LEFT * 2 + (cols - 1) * v['cw'] + FW, v['top'] + (rows - 1) * v['rh'] + FH + (56 if v['groups'] else 48)

def state_of(n, m):
    """visible?, gap status (new / changed / retired / unchanged / None)."""
    if m in GAPS:
        a, b = GAPS[m]
        ia, ib = a in n['pl'], b in n['pl']
        if not (ia or ib):
            return False, None
        if ia and ib:
            return True, 'changed' if m in n.get('chg', []) else 'unchanged'
        return True, 'new' if ib else 'retired'
    return m in n['pl'], None

def edge_state(pl, m):
    if m in GAPS:
        a, b = GAPS[m]
        ia, ib = a in pl, b in pl
        if not (ia or ib):
            return False, None
        return True, 'unchanged' if ia and ib else ('new' if ib else 'retired')
    return m in pl, None

def _seg_hits(x1, y1, x2, y2, r, pad=8):
    rx, ry, rw, rh = r[0] - pad, r[1] - pad, r[2] + 2 * pad, r[3] + 2 * pad
    if abs(x1 - x2) < .01:  # vertical
        return rx < x1 < rx + rw and max(min(y1, y2), ry) < min(max(y1, y2), ry + rh)
    if abs(y1 - y2) < .01:  # horizontal
        return ry < y1 < ry + rh and max(min(x1, x2), rx) < min(max(x1, x2), rx + rw)
    # diagonal: sample
    for i in range(1, 60):
        t = i / 60; x, y = x1 + (x2 - x1) * t, y1 + (y2 - y1) * t
        if rx < x < rx + rw and ry < y < ry + rh:
            return True
    return False

def _clip(ax, ay, bx, by):
    dx, dy = bx - ax, by - ay
    tx = (FW / 2 + 3) / abs(dx) if dx else 1e9
    ty = (FH / 2 + 3) / abs(dy) if dy else 1e9
    t = min(tx, ty)
    return ax + dx * t, ay + dy * t

def route(v, A, B, rects, used=None):
    """Straight line when it is clear, otherwise the shortest orthogonal route through the gaps between figures."""
    ax, ay = pos(v, A); bx, by = pos(v, B)
    sx, sy, tx, ty = ax + FW / 2, ay + FH / 2, bx + FW / 2, by + FH / 2
    others = [r for k, r in rects.items() if k not in (A['k'], B['k'])]
    def clear(pts):
        return all(not _seg_hits(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1], r) for i in range(len(pts) - 1) for r in others)
    def side(cx, cy, dx, dy):  # boundary point leaving the figure centre towards (dx, dy)
        if abs(dx) >= abs(dy):
            return (cx + (FW / 2 + 3) * (1 if dx > 0 else -1), cy)
        return (cx, cy + (FH / 2 + 3) * (1 if dy > 0 else -1))
    cands = []
    p1, p2 = _clip(sx, sy, tx, ty), _clip(tx, ty, sx, sy)
    cands.append((0, [p1, p2]))
    gx = sorted(set([x for x in [LEFT + c * v['cw'] - (v['cw'] - FW) / 2 for c in range(0, 9)] if x > 6] + [LEFT - 22]))
    gy = sorted(set([v['top'] + r * v['rh'] - (v['rh'] - FH) / 2 for r in range(0, 8)] + [v['top'] + 6 * v['rh']]))
    # one bend
    if abs(tx - sx) > 1 and abs(ty - sy) > 1:
        cands.append((1, [side(sx, sy, tx - sx, 0), (tx, sy), side(tx, ty, 0, sy - ty)]))
        cands.append((1, [side(sx, sy, 0, ty - sy), (sx, ty), side(tx, ty, sx - tx, 0)]))
    # two bends through a vertical gap or a horizontal gap
    for x in gx:
        a = side(sx, sy, x - sx, 0); b = side(tx, ty, x - tx, 0)
        if (x - sx) * (a[0] - sx) > 0 and (x - tx) * (b[0] - tx) > 0:
            cands.append((2, [a, (x, sy), (x, ty), b]))
    for y in gy:
        a = side(sx, sy, 0, y - sy); b = side(tx, ty, 0, y - ty)
        if (y - sy) * (a[1] - sy) > 0 and (y - ty) * (b[1] - ty) > 0:
            cands.append((2, [a, (sx, y), (tx, y), b]))
    best = None
    for bends, pts in cands:
        if not clear(pts):
            continue
        L = sum(abs(pts[i + 1][0] - pts[i][0]) + abs(pts[i + 1][1] - pts[i][1]) for i in range(len(pts) - 1))
        cost = L + 120 * bends + 400 * _overlaps(pts, used or [])
        if best is None or cost < best[0]:
            best = (cost, pts)
    return (best[1] if best else [p1, p2]), best is not None

def _segs(pts):
    out = []
    for i in range(len(pts) - 1):
        (x1, y1), (x2, y2) = pts[i], pts[i + 1]
        if abs(y1 - y2) < 1: out.append(('h', round(y1), min(x1, x2), max(x1, x2)))
        elif abs(x1 - x2) < 1: out.append(('v', round(x1), min(y1, y2), max(y1, y2)))
    return out

def _overlaps(pts, used):
    n = 0
    for o, c, a, b in _segs(pts):
        for o2, c2, a2, b2 in used:
            if o == o2 and abs(c - c2) < 6 and min(b, b2) - max(a, a2) > 12:
                n += 1
    return n

def _label_pos(pts, w):
    segs = [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    a, b = max(segs, key=lambda s: abs(s[1][0] - s[0][0]) + abs(s[1][1] - s[0][1]))
    return (a[0] + b[0]) / 2, (a[1] + b[1]) / 2

def _marker(kind, x, y, ang):
    m = AX.MARK[kind][0]
    return f'<g transform="translate({x:.1f} {y:.1f}) rotate({ang:.1f})">{m}</g>' if m else ''

import math

def render(k, m, interactive=True, uid=''):
    """One LikeC4 view as design-system markup: groupings, relationship lines with ArchiMate markers, figures, change chips."""
    v = VIEWS[k]; W, H = size(v)
    nodes = {n['k']: n for n in v['nodes']}
    vis = {n['k']: state_of(n, m) for n in v['nodes']}
    rects = {kk: (pos(v, n)[0], pos(v, n)[1], FW, FH) for kk, n in nodes.items() if vis[kk][0]}
    out = [f'<div class="lc-diagram" style="width: {W}px; height: {H}px">']
    for (label, c0, c1, r1) in v['groups']:
        x0 = LEFT + c0 * v['cw'] - 20; y0 = v['top'] - 48
        w = (c1 - c0) * v['cw'] + FW + 40; h = r1 * v['rh'] + FH + 68
        out.append(f'<div class="lc-group" style="left: {x0}px; top: {y0}px; width: {w}px; height: {h}px"><span>{AX.esc(label)}</span></div>')
    svg = [f'<svg class="lc-edges" width="{W}" height="{H}" viewBox="0 0 {W} {H}" aria-hidden="true">']
    labels, warn, used, placed = [], [], [], []
    for (s_, t_, rel, lab, pl) in v['edges']:
        ok, st = edge_state(pl, m)
        if not ok or not (vis[s_][0] and vis[t_][0]):
            continue
        pts, clean = route(v, nodes[s_], nodes[t_], rects, used)
        used += _segs(pts)
        if not clean:
            warn.append(f'{k}/{m}: {s_}->{t_} crosses a figure')
        R = AX.RELS[rel]
        hm, hl = AX.MARK[R['target']]; tm, tl = AX.MARK[R['source']]
        (x1, y1), (x2, y2) = pts[0], pts[1]
        a0 = math.degrees(math.atan2(y1 - y2, x1 - x2))           # tail points back to the source
        (u1, w1), (u2, w2) = pts[-2], pts[-1]
        a1 = math.degrees(math.atan2(w2 - w1, u2 - u1))
        # shorten the line under filled markers
        def back(p, q, d):
            L = math.hypot(q[0] - p[0], q[1] - p[1]) or 1
            return (q[0] - (q[0] - p[0]) * d / L, q[1] - (q[1] - p[1]) * d / L)
        lp = list(pts)
        if hl: lp[-1] = back(pts[-2], pts[-1], hl)
        if tl: lp[0] = back(pts[1], pts[0], tl)
        d = 'M' + ' L'.join(f'{x:.1f} {y:.1f}' for x, y in lp)
        cls = f'edge e-{s_} e-{t_}' + (f' g-{st}' if st else '') + (' assoc' if rel == 'association' else '')
        svg.append(f'<g class="{cls}"><path class="ln" d="{d}"{AX.DASH[R["line"]]}/>{_marker(R["target"], u2, w2, a1)}{_marker(R["source"], x1, y1, a0)}</g>')
        if lab:
            lw = len(lab) * 6.6 + 12
            def over(lx, ly):
                return [kk for kk, r in rects.items() if kk not in (s_, t_) and lx - lw / 2 < r[0] + r[2] + 2 and lx + lw / 2 > r[0] - 2 and ly - 11 < r[1] + r[3] and ly + 11 > r[1]] + \
                       ['label' for (px, py, pw) in placed if abs(px - lx) < (pw + lw) / 2 + 4 and abs(py - ly) < 20]
            segs = sorted([(pts[i], pts[i + 1]) for i in range(len(pts) - 1)], key=lambda q: -(abs(q[1][0] - q[0][0]) + abs(q[1][1] - q[0][1])))
            spots = [((a[0] + b[0]) / 2 + (b[0] - a[0]) * f, (a[1] + b[1]) / 2 + (b[1] - a[1]) * f) for a, b in segs for f in (0, -.25, .25, -.38, .38)]
            lx, ly = next((p for p in spots if not over(*p)), spots[0])
            if over(lx, ly):
                warn.append(f'{k}/{m}: label "{lab}" over {over(lx, ly)}')
            placed.append((lx, ly, lw))
            labels.append(f'<span class="lc-lbl e-{s_} e-{t_}{" g-" + st if st else ""}" style="left: {lx:.0f}px; top: {ly:.0f}px">{AX.esc(lab)}</span>')
    svg.append('</svg>')
    out += svg + labels
    for n in v['nodes']:
        ok, st = vis[n['k']]
        if not ok:
            continue
        t = AX.TYPES[n['kind']]; x, y = pos(v, n)
        cls = f'ax-box ax-shape-{t["shape"]} ax-l-{t["layer"]} lc-n n-{n["k"]}' + (' ax-retired' if st == 'retired' else '') + (' lc-faded' if st == 'unchanged' else '')
        aria = f'{n["name"]}, {n["kind"].lower()}' + (f', {st}' if st and st != 'unchanged' else '')
        inner = f'<span class="ax-in">{AX.svg_glyph(n["kind"])}<span class="ax-name">{AX.esc(n["name"])}</span></span>'
        if interactive:
            out.append(f'<button type="button" class="{cls}" style="left: {x}px; top: {y}px" aria-label="{AX.esc(aria)}" aria-pressed="{{{{lcOn_{n["k"]}}}}}" onClick="{{{{lcPick_{n["k"]}}}}}">{inner}</button>')
        else:
            out.append(f'<div class="{cls}" style="left: {x}px; top: {y}px" role="img" aria-label="{AX.esc(aria)}">{inner.replace("<span class=\"ax-in\">", "<span class=\"ax-in\">", 1)}</div>')
        if st and st != 'unchanged':
            c = AX.CHANGE[st]
            out.append(f'<span class="ax-change {st} lc-chip" style="left: {x + 8}px; top: {y + FH - 10}px"><b aria-hidden="true">{AX.esc(c["glyph"])}</b>{c["label"]}</span>')
    out.append('</div>')
    return ''.join(out), warn

def legend(k, m):
    """What this view uses: layers, relationships, change chips."""
    v = VIEWS[k]
    vis = [n for n in v['nodes'] if state_of(n, m)[0]]
    layers = []
    for n in vis:
        l = AX.TYPES[n['kind']]['layer']
        if l not in layers:
            layers.append(l)
    rels = []
    keys = {n['k'] for n in vis}
    for (s_, t_, rel, lab, pl) in v['edges']:
        if edge_state(pl, m)[0] and s_ in keys and t_ in keys and rel not in rels:
            rels.append(rel)
    out = ['<div class="lc-legend">']
    out += [f'<span class="lg-i"><span class="swatch ax-l-{l}"></span>{AX.LAYERS[l]["label"]}</span>' for l in layers]
    out += [f'<span class="lg-i">{AX.rel_sample(r)}{AX.RELS[r]["name"]}</span>' for r in rels]
    if m in GAPS:
        sts = {state_of(n, m)[1] for n in vis}
        out += [f'<span class="ax-change {c}"><b aria-hidden="true">{AX.esc(AX.CHANGE[c]["glyph"])}</b>{AX.CHANGE[c]["label"]}</span>' for c in ['new', 'changed', 'retired'] if c in sts]
        out.append('<span class="lg-i meta">Unchanged elements are faded</span>')
    out.append('</div>')
    return ''.join(out)

DIAGRAM_KEYS = [(k, m) for k in VIEW_ORDER for m in modes_of(VIEWS[k])]

# ------------------------------------------------------------------------------------------------------------------
# Catalogue: one entry per element (id), with its relationships, views and LikeC4 source
# ------------------------------------------------------------------------------------------------------------------
def catalogue():
    els, order = {}, []
    for k in VIEW_ORDER:
        v = VIEWS[k]
        for n in v['nodes']:
            e = els.get(n['id'])
            if not e:
                t = AX.TYPES[n['kind']]
                e = els[n['id']] = {'id': n['id'], 'name': n['name'], 'kind': n['kind'], 'type': t['id'], 'layer': t['layer'], 'shape': t['shape'],
                                    'pl': list(n['pl']), 'ext': bool(n.get('ext')), 'wp': n.get('wp', ''), 'views': [], 'rels': [], 'owner': n.get('owner', '')}
                order.append(n['id'])
            if n.get('wp'):
                e['wp'] = n['wp']
            if k in ('application', 'technology', 'landscape') and len(v['modes']) > 1:
                e['pl'] = list(n['pl']) if k == 'application' or not e.get('_plset') else e['pl']
                e['_plset'] = True
            ms = modes_of(v)
            best = next((mm for mm in ['target', 'tr1', 'base'] if mm in ms and mm in n['pl']), ms[0])
            e['views'].append([k, best, n['k']])
            nodes = {x['k']: x for x in v['nodes']}
            for (s_, t_, rel, lab, pl) in v['edges']:
                if n['k'] in (s_, t_):
                    other = nodes[t_ if s_ == n['k'] else s_]
                    r = {'dir': 'out' if s_ == n['k'] else 'in', 'rel': rel, 'other': other['id'], 'otherName': other['name'], 'otherKind': other['kind'], 'label': lab, 'pl': pl}
                    if r not in e['rels']:
                        e['rels'].append(r)
    for e in els.values():
        e.pop('_plset', None)
        d = DETAIL.get(e['id'])
        e['desc'] = d['desc'] if d else ''
        e['owner'] = (d['owner'] if d else '') or e['owner'] or ('Another application' if e['ext'] else 'Corporate credit architects')
        e['origin'] = d['origin'] if d else 'authored'
        e['dd'] = d['dd'] if d else []
        e['adrs'] = d['adrs'] if d else []
        e['arb'] = d['arb'] if d else ''
        e['realizes'] = d['realizes'] if d else ''
        e['contract'] = d['contract'] if d else ''
        e['src'] = likec4_source(e)
    return [els[i] for i in order]

def _key(eid):
    return eid.split('.')[-1]

def likec4_source(e):
    kind = AX.TYPES[e['kind']]['likec4Kind']
    tags = ' '.join(PL_TAG[p] for p in ALL if p in e['pl']) if len(e['pl']) < 3 else ''
    lines = [f"{_key(e['id'])} = {kind} '{e['name']}' {{"]
    if tags:
        lines.append(f'  {tags}')
    if e.get('origin') == 'inferred':
        lines.append('  #inferred')
    if e.get('desc'):
        lines.append(f"  description '{e['desc'][:96]}{'…' if len(e['desc']) > 96 else ''}'")
    lines.append('  metadata {')
    lines.append(f"    owner '{e['owner']}'")
    if e.get('dd'):
        lines.append(f"    dd '{DDS[e['dd'][0]]['path'].rsplit('/', 1)[0]}'")
    if e.get('origin') != 'authored':
        lines.append(f"    origin '{e['origin']}'")
    lines.append('  }')
    lines.append('}')
    for r in e['rels']:
        if r['dir'] == 'out':
            lab = f" '{r['label']}'" if r['label'] else ''
            lines.append(f"{_key(e['id'])} -[{r['rel']}]-> {_key(r['other'])}{lab}")
    return '\n'.join(lines)

def view_source(k, m):
    v = VIEWS[k]
    if m in GAPS:
        a, b = GAPS[m]
        inc = f"  include * where tag is {PL_TAG[a]} or tag is {PL_TAG[b]}\n  style * where tag is not {PL_TAG[b]} {{ opacity 40% }}"
    elif len(v['modes']) > 1:
        inc = f'  include * where tag is {PL_TAG[m]}'
    else:
        inc = '  include *'
    return f"view {view_id(k, m)} of corporate-credit {{\n  title '{v['title']} · {mode_name(m)}'\n{inc}\n  autoLayout TopBottom\n}}"

CATALOGUE = catalogue()

def js_data():
    views = {}
    for k in VIEW_ORDER:
        v = VIEWS[k]; W, H = size(v)
        views[k] = {'title': v['title'], 'phase': v['phase'], 'sub': v['sub'], 'modes': modes_of(v), 'base': v['modes'], 'w': W, 'h': H,
                    'ids': {m: view_id(k, m) for m in modes_of(v)}, 'src': {m: view_source(k, m) for m in modes_of(v)},
                    'nodes': {n['k']: {'name': n['name'], 'kind': n['kind'], 'type': AX.TYPES[n['kind']]['id'], 'layer': AX.TYPES[n['kind']]['layer'],
                                       'id': n['id'], 'pl': n['pl'], 'chg': n.get('chg', []), 'wp': n.get('wp', ''), 'ext': bool(n.get('ext'))} for n in v['nodes']},
                    'edges': [list(e) for e in v['edges']]}
    return json.dumps({'views': views, 'order': VIEW_ORDER, 'phases': PHASES, 'gaps': GAPS, 'plName': PL_NAME,
                       'layers': {l['id']: l['label'] for l in AX.N['layers']}, 'rels': {r['id']: r['name'] for r in AX.N['relationships']},
                       'cat': CATALOGUE, 'detail': DETAIL, 'dds': DDS, 'services': SERVICES, 'adrs': ADRS, 'plateaus': PLATEAUS, 'wps': WPS,
                       'arbs': ARBS, 'asd': ASD_SECTIONS, 'changes': CHANGES}, ensure_ascii=False)

if __name__ == '__main__':
    tot = 0
    for k, m in DIAGRAM_KEYS:
        h, w = render(k, m)
        tot += len(h)
        for x in w:
            print('WARN', x)
    print(len(DIAGRAM_KEYS), 'diagrams', tot, 'bytes', len(CATALOGUE), 'elements', len(js_data()), 'js bytes')

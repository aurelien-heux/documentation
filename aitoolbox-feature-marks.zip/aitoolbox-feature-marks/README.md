# AIToolbox feature marks · Sweep, Docs, Environments

Marks for three AIToolbox features, separate from the product logo. Free-standing shapes in the design-system colours only. Open `index.html` for a live preview (with a button to replay the single runs).

| Feature | Mark | Single run | Cycling |
|---|---|---|---|
| **Sweep** · agentic SDLC pipeline | Broom & sparkle: a broom mid-swing, two sparkles where it swept | 1.6 s · once: the broom winds up, sweeps across and settles; two sparkles pop where it passed | 2.8 s · infinite: the sparkles fade as the broom winds up, it sweeps, they pop back |
| **Docs** · documentation | Shelf: three books, the last one leaning | 1.5 s · once: the books slide up onto the shelf in turn; the last lands upright, then leans | 3.0 s · infinite: the first two books lift in turn; the leaning one straightens and falls back |
| **Environments** · environment management | Promotion: dev → staging → prod, prod filled with a check | 1.8 s · once: the path draws, each node pops as the path reaches it, the check draws on prod | 2.8 s · infinite: a release token travels dev → staging → prod; each node pulses; the check redraws on arrival |

## Contents

| Folder | Files |
|---|---|
| `svg/<feature>/` | `<feature>-light.svg`, `<feature>-dark.svg` (static) · `-run.svg` (plays once, ends on the static mark) · `-loop.svg` (cycles). 64 × 64 viewBox. |
| `lockups/` | `<feature>-lockup-light.svg` / `-dark.svg`: mark + "AIToolbox" label + feature name. Text outlined (Manrope 700 / 800), no font needed. |
| `png/<feature>/` | Static mark at 16, 24, 32, 48, 64, 128, 256 and 512 px (transparent), and the lockup at 2×. |
| `gif/` | `<feature>-<theme>-run.gif` (plays once) and `-loop.gif` (loops), 256 px on the surface colour: for slides, wikis and tools where SVG animation does not play. |
| `mockup/` | The validated board: `feature-marks-board.html` (live motion) and `feature-marks-board.png`. |
| `index.html` | Preview of everything, light and dark. |

## Colours

| Role | Light background | Dark background |
|---|---|---|
| Violet (primary) | `#35307E` primary | `#A6A2F8` primary 70 |
| Teal (ai) | `#278383` ai 50 | `#80D5D4` ai 80 |
| Green (tertiary) | `#00A56B` tertiary 60 | `#00F29E` tertiary (neon) |
| Cut-outs (spine labels, check, ring centres) | `#FDF8FD` surface | `#14121E` surface |

Never recolour a mark: pick the light or dark file to match the background. On a coloured or photo background, place the mark on a `surface` tile.

## Motion

- **Single run** (`-run.svg`, `-run.gif`): once, when the feature opens or an action completes (Sweep run finished, docs page loaded, promotion done). It always ends on the static mark.
- **Cycling** (`-loop.svg`, `-loop.gif`): while work is in progress (pipeline running, search indexing, deployment ongoing). Each cycle starts and ends on the static mark, so the animation can stop at the end of any cycle without a jump.
- Animated with CSS inside the SVG: transform, opacity and stroke-dashoffset only; easing `cubic-bezier(.2, 0, 0, 1)` (MD emphasized), the broom swing `cubic-bezier(.45, 0, .2, 1)`.
- Under `prefers-reduced-motion: reduce` the animation is off and the static mark shows.
- At most one cycling mark per screen; never run and loop on the same mark at once.

### Using the files

```html
<!-- static, in the navigation drawer -->
<img src="svg/sweep/sweep-light.svg" width="24" height="24" alt="">
<!-- cycling while a Sweep run is in progress -->
<img src="svg/sweep/sweep-light-loop.svg" width="40" height="40" alt="Sweep running">
<!-- light / dark switch -->
<picture>
  <source srcset="svg/docs/docs-dark.svg" media="(prefers-color-scheme: dark)">
  <img src="svg/docs/docs-light.svg" width="32" height="32" alt="Docs">
</picture>
```

```js
// replay a single run: reload the image
img.src = img.src.split('?')[0] + '?r=' + Date.now();
```

The SVGs also animate when inlined (Angular: `[innerHTML]` with a sanitizer bypass, or an `<svg>` component). Each file scopes its CSS under `.fm-<feature>.run` / `.fm-<feature>.loop`, so several marks can share a page.

## Rules

- These marks identify the features (navigation drawer and rail items, feature headers, empty states, the docs site, release notes). The AIToolbox logo remains the product brand; never combine the two marks side by side.
- Sizes: 16 px minimum; 24 px in navigation; 32–48 px in headers; 64 px and up for empty states and splash.
- Clear space: at least 1/8 of the mark size on every side (the drawing already sits 2 units inside the 64 grid).
- Lockup: mark + feature name in Manrope 800, "AIToolbox" small uppercase above it. Use the supplied files; don't retype.

# AIToolbox · export bundle

Snapshot of 28 October 2026. Everything in this folder was taken from the latest published versions.

| Folder | Content | Source |
|---|---|---|
| `design-system.html` | **Open this file to browse the design system.** One page with the principles, colour roles (light and dark, with contrast ratios), type scale, shape, elevation, spacing, layout and breakpoints, brand assets and state marks. Every component appears with its live preview, specification and rules. A Light / Dark / System switch and a component filter are at the top. It works offline; Open Sans loads from Google Fonts when online, and BNPP Type comes from `design-system/project/fonts/`. | Generated from `design-system/project/` (tokens.json, READMEs, previews, component rules) |
| `design-system/` | Design system: README, tokens (`tokens.json`, `tokens.css`), per-component rules, Angular Material themes (M2 / M3), breakpoints, component READMEs and HTML previews, BNPP Type font, brand assets (logos, favicon, app icon, state marks, chatbot mark) as SVG | Design System artifact "AIToolbox" (version 1793258860-80ce) |
| `canvas/html/` | **Open `index.html`.** The boards as standalone pages that run in any browser, interactive prototypes included (Community, Assistant, Feedback…) | Converted from `canvas/project/` |
| `canvas/project/` | Canvas source: the boards (`.dc.html`) and `canvas.json` (layout, titles, pages) | Design artifact (version 1793258835-1d74) |
| `project-docs/` | Project knowledge docs: domain reference, component rules, feature marks, architecture components, architecture notes, delivery and repositories | claude.ai Project "AIToolbox" |
| `tooling/` | Generators used to build the navigation and the Community prototype | Working scripts |

## Latest decisions included

- **Navigation.** The rail is the default from 600 px, and the drawer opens on demand from the rail menu. Destinations are Sweep, Environments, Docs and Community. At the bottom sit **Administration** (admins only) and then Cookie policy. Settings is in the account menu. There is no Dashboard, Secrets, Logs, Tools, Terms or version in the navigation.
- **Administration entry.** It is one entry, visible only to people with at least one admin right. Features have no admin entry of their own. Each feature ships its admin as a remote module, which the Administration shell loads according to the user's rights.
- **What's new and Ideas layouts.** What's new uses layout D · Changelog (`ReleaseItem`): one table row per change, then one action line that ends with Questions and Useful?. Ideas uses layout E · stack + detail: a 320 px list with the idea beside it; below 1200 px the idea takes the page.
- **Discussion.** Releases and ideas end with the same Discussion panel, collapsed by default. Its header is a summary bar that shows the number of threads and messages, who took part, whether the platform team replied, the last message, and Show or Hide. Open, it lists threads three at a time with a "Show 3 more threads" link. Each thread is an opening message followed by its replies, one level deep, with the last two replies shown and earlier ones on demand. Role chips mark the platform team, champions and authors. Anyone can reply to a thread or start a new one. A thread with no reply after 2 working days appears in the Administration inbox. See `design-system/project/components/Discussion/` and `ReleaseItem/`; the Q&A pattern lab keeps the open/close alternatives that were considered.
- **Administration.** The admin sidebar (B in the Administration layout lab) is adopted and applied to the live prototype: one page with a 240 px sidebar listing Core (General first, then Users and permissions, Groups, Audit log) and one group per feature module: Sweep (Connectors only, for now) and Community (Releases, Tours, Feedback, Ideas triage, Insights). Accounts come from the company directory (SSO), so Users and permissions has no invitation: it only gives admin rights and handles requests. Community · Insights brings together feedback forms, surveys and tours; usage metrics from OpenSearch have a placeholder and will be designed later. Rights remove groups and items; below 1200 px the sidebar becomes a Section select. Groups and Audit log are placeholders. The lab keeps the three other shells for the record.
- **Feedback.** All feedback administration is in Community › Feedback, for admins only: Profiles (every feature's feedback form, edited with the FeedbackProfile editor), Inbox, Surveys and the shared solicitation policy. A feature admin gets the scoped right Feedback · <feature>, separate from Community admin, and sees only their profile, their inbox and the cap (read-only). The Feedback administration lab keeps the two alternatives considered: 1, a Feedback section in each feature module, and B, a Feedback module of its own beside Core. See `design-system/project/components/FeedbackProfile/`.
- **Top app bar.** The search field is 440 px wide (it was 600) on every board and in the design system.
- **Window width.** Every Community prototype (live prototype, What's new lab, Ideas lab, Tour focus lab) has a window-width control: presets (Fit, 360, 600, 840, 1200, 1440, 1920) and a slider from 360 to 1920 px. Container queries make each proposal respond to the simulated width. Under 600 px the bottom NavigationBar appears (Sweep · Envs · Docs · Community · Assistant) and the top-bar menu opens the drawer. Below 840 px the drawer is modal. Widths larger than the screen are scaled down to fit.
- **Community.** It has three tabs, What's new, Guides and Ideas, used by everyone. Its admin module covers Releases, Tours, Feedback (profiles, inbox, surveys, solicitation policy), Ideas triage and Insights. One solicitation cap per user applies to every prompt (7 days by default).

## Notes

- **Which board files to open.** The `.dc.html` files in `canvas/project/` are the source and need the canvas viewer. Open the pages in `canvas/html/` instead: they bundle a small runtime (`tooling/dc-standalone.js`) and need nothing else.
- **Top app bar.** The page context (feature name over a summary) sits right of the logo; pages have no title block and no breadcrumb, and going back is a subheader chip. Applied to every board and to the TopAppBar component.
- **Guided tours.** The spotlight (D in the Tour focus lab) is adopted: see `design-system/project/components/GuidedTour/` and the GuidedTour section of the component rules. Tour targets are `data-anchor` ids measured at runtime.
- **`design-system/design-system.json` and `project/design-system.json`** are the design system's index files. The asset `blob` ids in them refer to the artifact's asset store; the files themselves are under `design-system/project/assets/<group>/`.

## Tooling

- `tokens_css.py`: regenerates `design-system/project/tokens.css` from `tokens.json`, which is the source of truth (`python3 tokens_css.py design-system/project`).
- `ds_showcase.py`: rebuilds `design-system.html` (`python3 ds_showcase.py design-system/project design-system.html`, run from the bundle root).
- `convert.py` + `dc-standalone.js`: turn `.dc.html` boards into standalone pages (`python3 convert.py canvas/project canvas/html`).

- `navgen.py`: canonical rail and drawer (light and dark), including the Administration entry.
- `shell.py`: shared header and base CSS for the prototype boards.
- `add_admin.py`: inserts the Administration entry into every navigation of a folder of boards (idempotent).
- `shell.py` also holds the shared window-width simulator (`SIM_CSS`, `sim_bar`, `sim_open`, `SIM_JS`), the bottom `navbar()` and the Q&A thread (`QA_CSS`, `qa_block`, `QA_JS`).
- `ideas_lab_build.py`, `whatsnew_lab_build.py`, `tour_lab_build.py` + the `*.src.html` files: build the three decision labs (`python3 <script> <src> <dst>`).
- `community_build.py` + `community-prototype-src/p1–p5.html`: build `CommunityLive.dc.html`. The script expects the sources in `../adoption/src/live/` relative to the script; adjust `SRC` if you move them.

# Devtoolbox architecture model — example package

Architecture as Markdown files with frontmatter references, validated in CI, projected into
`model.json` (agents), `model.c4` (LikeC4 site + MCP server) and a self-contained navigable
HTML view. Example chain: **Request a Deployment of a Module branch on an Environment**
(CTX-ENV), from the Requirement down to the hexagonal Java packages.

```
ea-schema.json          frontmatter contract (JSON Schema + kindsByLevel, kindMapping = §4.2 table as data)
model/
  requirement/          req.*   acceptance rows, decision table, operational figures
  abb/                  abb.*   capability, process, objects, event, services  (traces → req)
  sbb/                  sbb.*   interface, component, data object, event       (realizes → abb, contract, module)
  dd/                   dd.*    domain, domain-events, ports, application, infrastructure, api, data-model (realizes → sbb)
  adr/                  adr.*   decision, domainRef (DEC-*), affects
  work-package/         wp.*    Work item, affects, transition, dates
contracts/              OpenAPI / AsyncAPI referenced by `contract:`
tools/
  ea_model.py           loader (frontmatter + body per id)
  validate.py           schema + 14 cross-file rules; exit 1 blocks the PR
  generate.py           → dist/model.json, dist/likec4/ (LikeC4 project), dist/index.html
  site.template.html    the Architecture feature page in the AIToolbox shell (design system roles, components, window classes)
  build_likec4.py       → dist/likec4-site/index.html: LikeC4 static site (single file) with the AIToolbox skin
  likec4/
    aitoolbox-theme.c4  LikeC4 custom colours (ait-card, ait-filled, ait-nav, ait-primary, ait-outline) + status tags
    aitoolbox-likec4.css  exact AIToolbox tokens (light + dark), fonts, canvas, Mantine chrome, injected after the build
dist/                   generated — never edited by hand
  index.html            Architecture feature page (AIToolbox)
  likec4/               likec4.config.json + aitoolbox-theme.c4 + model.c4 (generated)
  likec4-site/          LikeC4 site styled like the page; element links open ../index.html#<id>
```

## Run

```bash
pip install pyyaml jsonschema markdown
npm i -g @mermaid-js/mermaid-cli   # renders Mermaid to inline SVG at build time (light + dark)
python3 tools/validate.py          # model OK: schema, traceability, contracts, modules, work items
python3 tools/generate.py          # dist/model.json, dist/model.c4, dist/index.html
# MMDC=/path/to/mmdc MMDC_PUPPETEER=pp.json  if mmdc is not on PATH or needs a browser path
# index.html has no runtime dependency: Markdown and diagrams are pre-rendered.
npx likec4@1.41.0 validate dist/likec4      # LikeC4 agrees with the model
python3 tools/build_likec4.py               # dist/likec4-site/index.html, AIToolbox look (LIKEC4=… to use a local binary)
npx likec4@1.41.0 start dist/likec4         # live dev server (unskinned: the CSS is injected by build_likec4.py only)
# @likec4/mcp on dist/likec4 serves the same model to agents
```

## Rules the validator enforces (from the Design-to-Code note §4.3)

1. Unique ids; file name = id; id prefix matches the level.
2. `kind` allowed for the level (`ea-schema.json` → `kindsByLevel`).
3. Every reference resolves (`realizes`, `traces`, `dependsOn`, `adr`, `affects`, `supersedes`).
4. `realizes` points exactly one level up; required on SBB and DD.
5. `traces` points to a requirement; required on ABB and Work items.
6. `dependsOn` stays on the same level.
7. `adr` → an ADR; `affects` → ABB / SBB / DD.
8. `contract` required on `application-interface` and `application-event`, and the file exists.
9. `module` required on SBB and DD, and belongs to `application`.
10. `ready` / `done` SBB, DD and Work items carry a `workItemId`.
11. Level-specific keys only on their level.
12. A requirement has acceptance rows; every KO row has a reason.
13. An ADR has a decision sentence; a `done` ADR names its `domainRef`.
14. No orphan: every requirement is traced, every ABB and SBB is realized.

## Discipline

- Frontmatter = facts (ids, kinds, references, status). Body = reasoning and diagrams. Every fact once.
- Agents write files and open a PR; `status` changes only through a Checkpoint decision (INV-12).
- Vocabulary follows `devtoolbox-domain-reference.md` §5: `application` is the `applicationSlug`,
  `module` is `applicationSlug/moduleName`, `workItemId` is the CTX-ORC Work item. ArchiMate names
  stay in `kind`; prose uses Module and Work item (DEC-07).

## LikeC4 in the AIToolbox style

The LikeC4 site is generated from the same files and styled to match `dist/index.html`:

| Page | LikeC4 |
|---|---|
| Chain tab (4 columns) | view `index`, `autoLayout RightLeft`: Requirement left, DD right |
| Work items and decisions cards | view `delivery` |
| Element page | view `v_<id>` per element (`view … of …`, opens from the element): chain up + neighbours |
| Box: title + kind on surface-container-lowest, outline-variant border, 8 px | `summary` = kind · colour `ait-card` · rectangle, size sm |
| Work items, ADR: filled card | colour `ait-filled` |
| `realizes` solid primary · `traces` dashed outline | relationship kinds `realizes`, `traces` (+ dotted `dependsOn`, `constrainedBy`, dashed `affects`) |
| Status chip (glyph + word) | status tag `#ready` `#done` `#draft` `#deprecated` (coloured stripe + tag name) |
| Open the element page | element link `../index.html#<id>` and the "Open in AIToolbox" button |

How the exact colours are reached: LikeC4 derives a palette from each custom hex (it turns `#35307E` into a
`#574eb4` fill), and writes it as `:where([data-likec4-color=…])` rules with zero specificity.
`aitoolbox-likec4.css` overrides every palette variable per colour with the AIToolbox token, switching on
`html[data-mantine-color-scheme="dark"]`, and maps Mantine's indigo/blue accent, fonts, radius and canvas.

Limits: the status is a tag stripe, not the page's tile glyph; LikeC4 controls (Share, Export, search) keep
their layout; `likec4 start` (dev server) shows the theme colours without the CSS. Checked with likec4 1.41.0;
the CSS relies on `data-likec4-color` and Mantine variables, so re-check it when upgrading LikeC4.

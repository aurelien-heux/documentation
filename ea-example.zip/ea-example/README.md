# Devtoolbox architecture model — example package

Architecture as Markdown files with frontmatter references, validated in CI, projected into
`model.json` (agents), `model.c4` (LikeC4 site + MCP server) and a self-contained navigable
HTML view. Example chain: **Request a Deployment of a Module branch on an Environment**
(CTX-ENV), from the Requirement down to the hexagonal Java packages.

```
ea-schema.json          frontmatter contract (JSON Schema + kindsByLevel, kindMapping = §4.2 table as data)
model/
  requirement/          req.*   acceptance rows, decision table, operational figures
  abb/                  abb.*   capability, process, objects, event, services  (traces → req)
  sbb/                  sbb.*   interface, component, data object, event       (realizes → abb, contract, module)
  dd/                   dd.*    domain, domain-events, ports, application, infrastructure, api, data-model (realizes → sbb)
  adr/                  adr.*   decision, domainRef (DEC-*), affects
  work-package/         wp.*    Work item, affects, transition, dates
contracts/              OpenAPI / AsyncAPI referenced by `contract:`
tools/
  ea_model.py           loader (frontmatter + body per id)
  validate.py           schema + 14 cross-file rules; exit 1 blocks the PR
  generate.py           → dist/model.json, dist/model.c4, dist/index.html
  site.template.html    the Architecture feature page in the AIToolbox shell (design system roles, components, window classes)
dist/                   generated — never edited by hand
```

## Run

```bash
pip install pyyaml jsonschema markdown
npm i -g @mermaid-js/mermaid-cli   # renders Mermaid to inline SVG at build time (light + dark)
python3 tools/validate.py          # model OK: schema, traceability, contracts, modules, work items
python3 tools/generate.py          # dist/model.json, dist/model.c4, dist/index.html
# MMDC=/path/to/mmdc MMDC_PUPPETEER=pp.json  if mmdc is not on PATH or needs a browser path
# index.html has no runtime dependency: Markdown and diagrams are pre-rendered.
npx likec4 validate dist           # optional: LikeC4 CLI agrees (checked with likec4 1.41.0)
npx likec4 start dist              # optional: the LikeC4 site; @likec4/mcp serves the same model to agents
```

## Rules the validator enforces (from the Design-to-Code note §4.3)

1. Unique ids; file name = id; id prefix matches the level.
2. `kind` allowed for the level (`ea-schema.json` → `kindsByLevel`).
3. Every reference resolves (`realizes`, `traces`, `dependsOn`, `adr`, `affects`, `supersedes`).
4. `realizes` points exactly one level up; required on SBB and DD.
5. `traces` points to a requirement; required on ABB and Work items.
6. `dependsOn` stays on the same level.
7. `adr` → an ADR; `affects` → ABB / SBB / DD.
8. `contract` required on `application-interface` and `application-event`, and the file exists.
9. `module` required on SBB and DD, and belongs to `application`.
10. `ready` / `done` SBB, DD and Work items carry a `workItemId`.
11. Level-specific keys only on their level.
12. A requirement has acceptance rows; every KO row has a reason.
13. An ADR has a decision sentence; a `done` ADR names its `domainRef`.
14. No orphan: every requirement is traced, every ABB and SBB is realized.

## Discipline

- Frontmatter = facts (ids, kinds, references, status). Body = reasoning and diagrams. Every fact once.
- Agents write files and open a PR; `status` changes only through a Checkpoint decision (INV-12).
- Vocabulary follows `devtoolbox-domain-reference.md` §5: `application` is the `applicationSlug`,
  `module` is `applicationSlug/moduleName`, `workItemId` is the CTX-ORC Work item. ArchiMate names
  stay in `kind`; prose uses Module and Work item (DEC-07).

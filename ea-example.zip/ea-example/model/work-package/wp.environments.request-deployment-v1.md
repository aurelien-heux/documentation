---
id: wp.environments.request-deployment-v1
level: work-package
kind: feature
title: Request Deployment v1
application: environments
owner: team-platform
status: ready
updatedAt: 2026-10-22
workItemId: WI-318
jira: DTB-412
transition: target
start: 2026-10-27
end: 2026-11-07
traces: [req.environments.request-deployment]
affects:
  - sbb.environments.deployment-api
  - sbb.environments.environments-module
  - sbb.environments.deployment-record
  - sbb.environments.deployment-requested-event
  - dd.environments.domain
  - dd.environments.domain-events
  - dd.environments.ports
  - dd.environments.application
  - dd.environments.infrastructure
  - dd.environments.api
  - dd.environments.data-model
adr: [adr.environments.auto-merge-pr]
---

# Request Deployment v1 (Work item WI-318)

Implements the full chain for `req.environments.request-deployment` in the `environments`
Module, through the implement Phase (developer agent, `autonomous` up to PR) and the review
Phase (human Checkpoint).

## Definition of Ready (checked by the validator, decided by the architect)

- [x] All DD elements present and `ready`
- [x] Contracts on disk: `contracts/deployments.openapi.yaml`, `contracts/environment-events.asyncapi.yaml`
- [x] Acceptance rows and decision table on the Requirement
- [x] Operational figures present
- [x] No open question blocking (OPP-ENV-08 does not apply: single Module)

## Order of generation

domain → domain-events → ports → application → infrastructure → api → data-model, then tests:
one unit test per decision-table row, one use-case test per acceptance row, contract tests
from both contracts, integration tests on Testcontainers.

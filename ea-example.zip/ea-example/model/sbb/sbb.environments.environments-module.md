---
id: sbb.environments.environments-module
level: sbb
kind: application-component
title: environments Module
application: environments
module: environments/service
owner: team-platform
status: ready
updatedAt: 2026-10-22
realizes:
  - abb.environments.environment-management
  - abb.environments.request-deployment-process
  - abb.environments.deployment-service
adr: [adr.environments.auto-merge-pr]
workItemId: WI-318
links: [https://git.internal/devtoolbox/environments]
---

# environments Module (application component)

The deployable unit for CTX-ENV: one Spring Modulith module in the `devtoolbox-backend`
repository, packaged as one container image, deployed by `argocd` (Module field `deployer`).

```mermaid
flowchart TB
  subgraph environments ["environments (Spring Modulith module)"]
    api --> application
    application --> domain
    application --> ports["application.port.out"]
    infrastructure -.implements.-> ports
    infrastructure --> git["CTX-INT Git connector"]
    infrastructure --> bus["CTX-INT event bus"]
    infrastructure --> db[("PostgreSQL · environments schema")]
  end
```

Owns the aggregates Deployment and Reservation; reads Environment descriptors through
CTX-INT; never holds credentials (INV-07).

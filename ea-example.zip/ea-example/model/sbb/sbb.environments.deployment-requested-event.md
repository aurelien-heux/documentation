---
id: sbb.environments.deployment-requested-event
level: sbb
kind: application-event
title: DeploymentRequested message
application: environments
module: environments/service
owner: team-platform
status: ready
updatedAt: 2026-10-22
realizes: [abb.environments.deployment-requested]
contract: contracts/environment-events.asyncapi.yaml
workItemId: WI-318
---

# DeploymentRequested message (application event)

The integration message for EVT-DEPLOYMENT-REQUESTED on the platform event bus, topic
`devtoolbox.environments.deployment`. Schema in the AsyncAPI contract; consumers are
CTX-INT (opens the PR) and CTX-AST (answers status questions).

Idempotency key: `deploymentId`. Ordering guaranteed per Environment (partition key).

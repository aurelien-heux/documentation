---
id: abb.environments.deploy-module-branch
level: abb
kind: business-service
title: Deploy a Module branch
application: environments
owner: team-platform
status: ready
updatedAt: 2026-10-22
traces: [req.environments.request-deployment]
dependsOn: [abb.environments.request-deployment-process]
---

# Deploy a Module branch (business service)

The exposed use case: given an Environment, an `applicationSlug/moduleName` and a branch,
start a Deployment or refuse it with the reason. Domain-reference command:
CMD-REQUEST-DEPLOYMENT.

Becomes the inbound port `RequestDeploymentUseCase` (`application.port.in`).

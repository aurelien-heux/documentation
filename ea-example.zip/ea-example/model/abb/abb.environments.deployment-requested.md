---
id: abb.environments.deployment-requested
level: abb
kind: business-event
title: Deployment requested
application: environments
owner: team-platform
status: ready
updatedAt: 2026-10-22
traces: [req.environments.request-deployment]
---

# Deployment requested (business event)

Raised when a Deployment passes the Reservation check and the descriptor PR is about to be
opened. Domain-reference name: EVT-DEPLOYMENT-REQUESTED. Subscribers: CTX-INT (opens the PR),
CTX-AST (status answers).

Payload: `deploymentId`, `environment`, `applicationSlug/moduleName`, `branch`, `requestedBy`,
`workItemId?`, `requestedAt`.

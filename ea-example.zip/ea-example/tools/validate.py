#!/usr/bin/env python3
"""Validate the architecture model: JSON Schema per file, then the cross-file rules the
schema cannot express (the §4.3 rules of the Design-to-Code note). Exit 1 on any error.

Usage: python3 tools/validate.py [root]
"""
from __future__ import annotations
import sys
from pathlib import Path
from jsonschema import Draft202012Validator
from ea_model import load_model, load_schema

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]


def main() -> int:
    schema = load_schema(ROOT)
    defs = schema["$defs"]
    kinds_by_level = defs["kindsByLevel"]
    parent_level = defs["parentLevel"]
    id_prefix = defs["idPrefix"]
    requires_contract = set(defs["requiresContract"])
    requires_module = set(defs["requiresModule"])

    elements, errors = load_model(ROOT)
    validator = Draft202012Validator(schema)

    # 1. Per-file schema
    for eid, el in elements.items():
        for err in sorted(validator.iter_errors(el["fm"]), key=str):
            errors.append(f"{eid}: schema: {err.message}")

    def level_of(ref: str) -> str | None:
        return elements[ref]["fm"]["level"] if ref in elements else None

    # 2. Cross-file rules
    for eid, el in elements.items():
        fm = el["fm"]
        level, kind = fm.get("level"), fm.get("kind")
        if level not in kinds_by_level:
            continue
        # R1 kind allowed for the level
        if kind not in kinds_by_level[level]:
            errors.append(f"{eid}: kind '{kind}' is not allowed on level '{level}' (allowed: {', '.join(kinds_by_level[level])})")
        # R2 id prefix matches the level
        if not eid.startswith(id_prefix[level] + "."):
            errors.append(f"{eid}: id prefix must be '{id_prefix[level]}.' for level '{level}'")
        # R3 every reference resolves
        for key in ("realizes", "traces", "dependsOn", "adr", "affects", "supersedes"):
            for ref in fm.get(key, []) or []:
                if ref not in elements:
                    errors.append(f"{eid}: {key} -> '{ref}' does not exist")
        # R4 realizes points exactly one level up; required on sbb and dd
        if level in parent_level:
            refs = fm.get("realizes") or []
            if level in ("sbb", "dd") and not refs:
                errors.append(f"{eid}: {level} must realize at least one {parent_level[level]} (full traceability)")
            for ref in refs:
                if ref in elements and level_of(ref) != parent_level[level]:
                    errors.append(f"{eid}: realizes '{ref}' is level '{level_of(ref)}', expected '{parent_level[level]}'")
        # R5 traces: required on abb and work-package, must point to a requirement
        if level in ("abb", "work-package") and not fm.get("traces"):
            errors.append(f"{eid}: {level} must trace to a requirement")
        for ref in fm.get("traces") or []:
            if ref in elements and level_of(ref) != "requirement":
                errors.append(f"{eid}: traces '{ref}' is not a requirement")
        # R6 dependsOn stays on the same level
        for ref in fm.get("dependsOn") or []:
            if ref in elements and level_of(ref) != level:
                errors.append(f"{eid}: dependsOn '{ref}' is level '{level_of(ref)}', must be '{level}'")
        # R7 adr references point to adr; affects point to sbb/dd/abb
        for ref in fm.get("adr") or []:
            if ref in elements and level_of(ref) != "adr":
                errors.append(f"{eid}: adr '{ref}' is not an ADR")
        for ref in fm.get("affects") or []:
            if ref in elements and level_of(ref) not in ("abb", "sbb", "dd"):
                errors.append(f"{eid}: affects '{ref}' must be an ABB, SBB or DD")
        # R8 contract required on interfaces and events, and must exist on disk
        if kind in requires_contract:
            c = fm.get("contract")
            if not c:
                errors.append(f"{eid}: kind '{kind}' requires a contract path")
            elif not (ROOT / c).is_file():
                errors.append(f"{eid}: contract '{c}' not found on disk")
        # R9 module required on sbb and dd and must match the application slug
        if level in requires_module:
            mod = fm.get("module")
            if not mod:
                errors.append(f"{eid}: level '{level}' requires module (applicationSlug/moduleName)")
            elif not mod.startswith(fm["application"] + "/"):
                errors.append(f"{eid}: module '{mod}' must belong to application '{fm['application']}'")
        # R10 ready/done elements carry a Work item (except requirement and ADR, which may precede one)
        if fm.get("status") in ("ready", "done") and level in ("sbb", "dd", "work-package") and not fm.get("workItemId"):
            errors.append(f"{eid}: status '{fm['status']}' requires workItemId")
        # R11 level-specific keys only where they belong
        for key, levels in (("acceptance", {"requirement"}), ("decisionTable", {"requirement"}), ("operational", {"requirement"}),
                            ("transition", {"work-package"}), ("decision", {"adr"}), ("domainRef", {"adr"}), ("supersedes", {"adr"})):
            if key in fm and level not in levels:
                errors.append(f"{eid}: '{key}' is only allowed on {', '.join(levels)}")
        # R12 a requirement needs acceptance rows; every KO row needs a reason
        if level == "requirement":
            if not fm.get("acceptance"):
                errors.append(f"{eid}: requirement needs at least one acceptance row")
            for i, row in enumerate(fm.get("decisionTable") or [], 1):
                if row.get("outcome") == "KO" and not row.get("reason"):
                    errors.append(f"{eid}: decisionTable row {i} is KO without a reason")
        # R13 an ADR needs the decision sentence; a done ADR needs a domainRef
        if level == "adr":
            if not fm.get("decision"):
                errors.append(f"{eid}: ADR needs a decision sentence")
            if fm.get("status") == "done" and not fm.get("domainRef"):
                errors.append(f"{eid}: a done ADR must name its domain-reference entry (DEC-*/INV-*/OPP-*)")

    # R14 every requirement is traced by at least one ABB; every ABB realized by at least one SBB
    traced = {r for el in elements.values() for r in (el["fm"].get("traces") or [])}
    realized = {r for el in elements.values() for r in (el["fm"].get("realizes") or [])}
    for eid, el in elements.items():
        lvl = el["fm"].get("level")
        if lvl == "requirement" and eid not in traced:
            errors.append(f"{eid}: requirement is not traced by any ABB")
        if lvl == "abb" and eid not in realized:
            errors.append(f"{eid}: ABB is not realized by any SBB")
        if lvl == "sbb" and eid not in realized:
            errors.append(f"{eid}: SBB is not realized by any DD")

    # Report
    counts = {}
    for el in elements.values():
        counts[el["fm"].get("level")] = counts.get(el["fm"].get("level"), 0) + 1
    print("elements:", ", ".join(f"{k}={v}" for k, v in sorted(counts.items(), key=lambda kv: str(kv[0]))))
    if errors:
        print(f"\n{len(errors)} error(s):")
        for e in errors:
            print("  -", e)
        return 1
    print("model OK: schema, traceability, contracts, modules, work items")
    return 0


if __name__ == "__main__":
    sys.exit(main())

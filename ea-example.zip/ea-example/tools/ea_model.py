"""Shared loader: reads every model file, returns frontmatter + body keyed by id."""
from __future__ import annotations
import json, re, sys
from pathlib import Path
import yaml

FM_RE = re.compile(r"^---\n(.*?)\n---\n?(.*)$", re.S)


def load_schema(root: Path) -> dict:
    return json.loads((root / "ea-schema.json").read_text(encoding="utf-8"))


def load_model(root: Path) -> tuple[dict[str, dict], list[str]]:
    """Returns ({id: {"fm": frontmatter, "body": str, "path": Path}}, errors)."""
    elements: dict[str, dict] = {}
    errors: list[str] = []
    for path in sorted((root / "model").rglob("*.md")):
        text = path.read_text(encoding="utf-8")
        m = FM_RE.match(text)
        if not m:
            errors.append(f"{path.relative_to(root)}: no frontmatter block")
            continue
        try:
            fm = yaml.safe_load(m.group(1)) or {}
        except yaml.YAMLError as e:
            errors.append(f"{path.relative_to(root)}: YAML error: {e}")
            continue
        for k in ("updatedAt", "start", "end"):      # YAML parses bare dates; the schema wants ISO strings
            if k in fm and not isinstance(fm[k], str):
                fm[k] = fm[k].isoformat()
        eid = fm.get("id")
        if not eid:
            errors.append(f"{path.relative_to(root)}: missing id")
            continue
        if eid in elements:
            errors.append(f"{path.relative_to(root)}: duplicate id {eid} (also in {elements[eid]['path'].relative_to(root)})")
            continue
        if path.stem != eid:
            errors.append(f"{path.relative_to(root)}: file name must equal id ({eid})")
        elements[eid] = {"fm": fm, "body": m.group(2), "path": path}
    return elements, errors


def to_json(elements: dict[str, dict], root: Path) -> list[dict]:
    out = []
    for eid, el in elements.items():
        fm = dict(el["fm"])
        for k in ("updatedAt", "start", "end"):
            if k in fm:
                fm[k] = str(fm[k])
        fm["_path"] = str(el["path"].relative_to(root))
        fm["_body"] = el["body"].strip()
        out.append(fm)
    return out

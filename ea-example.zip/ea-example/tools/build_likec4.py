#!/usr/bin/env python3
"""Build the LikeC4 site from dist/likec4/ and give it the AIToolbox look.

  1. `likec4 build --output-single-file --use-hash-history` → one self-contained HTML file
  2. inject the page fonts (Google Fonts: Manrope, Open Sans; BNPP Type when installed)
  3. inject tools/likec4/aitoolbox-likec4.css (exact tokens, light + dark, Mantine chrome)
  4. add an "Open in AIToolbox" link back to the Architecture page (dist/index.html)

Output: dist/likec4-site/index.html — next to dist/index.html, so the element links
`../index.html#<id>` open the matching element page.

Usage:  python3 tools/build_likec4.py [root]
Env:    LIKEC4=/path/to/likec4   (default: `npx -y likec4@1.41.0`)
"""
from __future__ import annotations
import os, shlex, subprocess, sys
from pathlib import Path

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
PROJECT = ROOT / "dist" / "likec4"
OUT = ROOT / "dist" / "likec4-site"
CSS = ROOT / "tools" / "likec4" / "aitoolbox-likec4.css"
LIKEC4 = shlex.split(os.environ.get("LIKEC4", "npx -y likec4@1.41.0"))

FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com">'
         '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700;800&family=Open+Sans:wght@400;600&display=swap">')
BACKLINK = '<a class="ait-backlink" href="../index.html">← Open in AIToolbox</a>'


def main() -> int:
    if not (PROJECT / "model.c4").exists():
        print("dist/likec4/model.c4 missing: run tools/generate.py first")
        return 1
    OUT.mkdir(parents=True, exist_ok=True)
    cmd = LIKEC4 + ["build", "--output-single-file", "--use-hash-history",
                    "--title", "AIToolbox Architecture", "-o", str(OUT), str(PROJECT)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-2000:], r.stderr[-2000:])
        return r.returncode
    page = OUT / "index.html"
    html = page.read_text(encoding="utf-8")
    css = CSS.read_text(encoding="utf-8")
    skin = f'{FONTS}\n<style id="aitoolbox-skin">\n{css}\n</style>\n'
    if 'id="aitoolbox-skin"' not in html:
        # The inlined bundle itself contains "</head>" and "</body>" strings: insert at the LAST occurrence.
        i = html.rfind("</head>"); html = html[:i] + skin + html[i:]      # last in <head>: wins over LikeC4's styles
        j = html.rfind("</body>"); html = html[:j] + BACKLINK + "\n" + html[j:]
    page.write_text(html, encoding="utf-8")
    print(f"built {page.relative_to(ROOT)} ({page.stat().st_size // 1024} KB) with the AIToolbox skin")
    return 0


if __name__ == "__main__":
    sys.exit(main())

const { chromium } = require('playwright'); const fs = require('fs');
(async () => {
  const b = await chromium.launch(); const errs = [];
  // ---- board
  let p = await b.newPage({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: 1 }); p.on('pageerror', e => errs.push('board: ' + e.message.slice(0, 300)));
  await p.goto('file://' + process.cwd() + '/out/Architecture.html'); await p.waitForTimeout(1500);
  await p.addScriptTag({ content: fs.readFileSync('../audit/node_modules/axe-core/axe.min.js', 'utf8') });
  const S = (o) => p.evaluate(o => __dcInstance.setState(o), o);
  const axe = async (n) => { const r = await p.evaluate(() => axe.run(document.querySelector('.simframe'), { runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa'] })); console.log(n, 'axe', r.violations.map(v => v.id + ':' + v.nodes.length + ' ' + v.nodes[0].html.slice(0, 120)).join(' ;; ') || '0'); };
  await S({ area: 'process', proc: 'changes', page: null }); await p.waitForTimeout(400); await p.screenshot({ path: 'intest/b_changes.png', fullPage: true }); await axe('changes');
  await S({ proc: 'intake' }); await p.waitForTimeout(400); await p.screenshot({ path: 'intest/b_intake.png', fullPage: true }); await axe('intake');
  await p.locator('button', { hasText: 'Open as suggested' }).first().click(); await p.waitForTimeout(300);
  await p.locator('button', { hasText: 'Attach to' }).first().click(); await p.waitForTimeout(300);
  await p.locator('button', { hasText: 'Dismiss' }).last().click(); await p.waitForTimeout(300); await p.screenshot({ path: 'intest/b_intake2.png', fullPage: true });
  await S({ proc: 'changes' }); await p.waitForTimeout(400); await p.screenshot({ path: 'intest/b_changes2.png', fullPage: true });
  await p.locator('.trow', { hasText: 'Instant card freeze' }).click(); await p.waitForTimeout(500); await p.screenshot({ path: 'intest/b_newchange.png', fullPage: true }); await axe('new change page');
  await S({ area: 'views', page: null, level: 'enterprise', view: { enterprise: 'roadmap', portfolio: 'landscape', application: 'factsheet' } }); await p.waitForTimeout(500);
  await S({ level: 'portfolio', pf: 'retail', view: { enterprise: 'capmap', portfolio: 'gap', application: 'factsheet' } }); await p.waitForTimeout(500);
  await S({ area: 'elements' }); await p.waitForTimeout(400);
  await S({ simW: 360, area: 'process', proc: 'changes', page: null }); await p.waitForTimeout(500); await p.screenshot({ path: 'intest/b_changes360.png', fullPage: true });
  await p.close();
  // ---- vision: chat iteration
  p = await b.newPage({ viewport: { width: 1600, height: 1000 }, deviceScaleFactor: 1 }); p.on('pageerror', e => errs.push('vision: ' + e.message.slice(0, 300)));
  await p.goto('file://' + process.cwd() + '/out/ProductionVision.html'); await p.waitForTimeout(1500);
  await p.addScriptTag({ content: fs.readFileSync('../audit/node_modules/axe-core/axe.min.js', 'utf8') });
  await p.evaluate(() => __dcInstance.setState({ screen: 'docs', dl: Object.assign({}, __dcInstance.state.dl || {}, { view: 'arch' }), arTarget: { area: 'process', proc: 'intake', page: null } })); await p.waitForTimeout(700);
  await p.locator('button', { hasText: 'New request · ask the assistant' }).click(); await p.waitForTimeout(500);
  await p.fill('#as-in', 'Treasurers want intraday balances across entities'); await p.keyboard.press('Enter'); await p.waitForTimeout(400);
  await p.locator('.as-pane .srcs button', { hasText: 'Committed' }).click(); await p.waitForTimeout(400);
  await p.locator('.as-pane .srcs button', { hasText: 'Make it re-architecting' }).click(); await p.waitForTimeout(400);
  await p.fill('#as-in', 'add treasury-portal to the scope'); await p.keyboard.press('Enter'); await p.waitForTimeout(400);
  await p.screenshot({ path: 'intest/v_chat1.png' }); await axe('vision chat');
  await p.locator('.as-pane .srcs button', { hasText: 'Create the change' }).click(); await p.waitForTimeout(400);
  await p.locator('.as-pane button', { hasText: 'Open the change' }).click(); await p.waitForTimeout(600); await p.screenshot({ path: 'intest/v_chat2.png' });
  // a signal with dismissal
  await p.evaluate(() => __dcInstance.setState({ arTarget: { area: 'process', proc: 'intake', page: null } })); await p.waitForTimeout(600);
  await p.locator('.sigrow', { hasText: '/v2/refunds' }).locator('button', { hasText: 'Qualify in the assistant' }).click(); await p.waitForTimeout(400);
  await p.locator('.as-pane .srcs button', { hasText: 'No, it should be removed' }).click(); await p.waitForTimeout(300);
  await p.locator('.as-pane .srcs button', { hasText: 'Record it' }).click(); await p.waitForTimeout(400);
  await p.evaluate(() => __dcInstance.setState({ theme: 'dark' })); await p.waitForTimeout(400); await p.screenshot({ path: 'intest/v_chat3_dark.png' }); await axe('vision intake dark');
  console.log('errs', errs); await b.close();
})();

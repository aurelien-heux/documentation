# AIToolbox · architecture intake, change tracks, Change start lab (2026-11-10, canvas version 236)

Drop-in for the export bundle (`AIToolbox-export/`). Supersedes `aitoolbox-delivery-line-2026-11-09` (everything it
carried is here, rebuilt; its ProductionVision was above the canvas size limit). Decisions and design:
`claude/architecture-intake-and-change-tracks.md` (DEC-KB-45) and `claude/architecture-metamodel-v4.md` in the
claude.ai Project (the second is copied in `project-docs/`).

| From this package | Into the bundle | What changed |
|---|---|---|
| `canvas/project/Architecture.dc.html` | replace | Process › **Intake** (To qualify: signals with their origin and a suggested entry · Qualify in the assistant · Open as suggested · Attach · Dismiss; Qualified history); Process › **Changes** as tracks (one row per change: origin, phases skipped / done / current, gates, TOGAF phase, documents to finish, delivery); "Comes from" on the change page; the delivery line of 2026-11-09. |
| `canvas/project/ProductionVision.dc.html` | replace | Same, plus the **intake mode of the global assistant pane** (one question, proposal card, suggested replies and free text to iterate, create / attach / record). Under the 2 MiB board limit again (2 052 399 bytes). |
| `canvas/project/StartLab.dc.html` (new) | add | Change start lab: start A form · B assistant · C signals; follow A board · B tracks · C by gate · D ADM phases; 19 example changes on every phase and gate. Kept as the record of the alternatives. |
| `canvas/project/CatalogueLab`, `ViewsLab`, `ProcessLab` | replace | Rebuilt on the new logic. |
| `canvas/project/canvas.json` | replace | StartLab on the labs page (x 0, y 12416); titles. |
| `canvas/html/*.html` | replace / add | Standalone pages. |
| `tooling/architecture-board/intake_data.py`, `intake_logic.js` (new) | add | Intake data and logic (already spliced into the `arch_logic.js` shipped here). |
| `tooling/architecture-board/startlab_data.py`, `build_startlab.py` (new) | add | The lab. `ARCH_DATA=arch_data.json python3 build_startlab.py StartLab.dc.html` |
| `tooling/architecture-board/arch_logic.js`, `build_arch.py`, `delivery_*` | replace | `INTAKE` constant, `flowOf` honours `entryId` / `cur` of a change opened from intake, process tab `intake`, `changeGroups`, templates `INTAKE`, `CHANGES`, `MINITRACK`, CSS. |
| `tooling/vision_arch.py`, `vision_parts.py`, `vision-prototype-src/vision.js` | replace | Pane hook (`A.intakeCtx` → `intakeTurns`), proposal card `t.qual`, replies `t.replies`, turn defaults. |
| `tooling/vision_shrink.py` (new), `vision_build2.py` | add / replace | Size guard and lossless minification at the end of the vision build. |
| — | — | **Version 236**: Process side list in the order of the work (Intake, Changes, Reviews, Decisions, Model checks, How it works); the Agent proposals section is removed; How it works tabs reordered (The flow, Documents and gates, Who does what, Three classes, Parallel changes, Git conventions, Coding assistants). |
| `preview/` | — | Screens and the two Playwright tours. |

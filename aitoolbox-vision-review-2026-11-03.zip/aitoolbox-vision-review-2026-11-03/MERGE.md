# AIToolbox · production vision consistency review applied (2026-11-03, evening) — canvas version 225

Drop-in for the export bundle (`AIToolbox-export/`): copy each folder over the bundle's folder of the same name.
Supersedes the two earlier packages of the day (`aitoolbox-design-system-update-2026-11-03b`, `-switch-`): everything
they carried is here, rebuilt. The review itself is `project-docs/vision-consistency-review.md` (also in the claude.ai
Project); its section 3 lists what changed, screen by screen.

| From this package | Into the bundle | What changed |
|---|---|---|
| `canvas/project/ProductionVision.dc.html` | `canvas/project/` (replace) | The reviewed production vision: text cuts on every screen, Environments rebuilt on the domain (non-production, branches, observed state with source and time, reservations), Meridian Bank everywhere in Docs, one reference date (Tue 3 Nov 2026 11:12), varied Sweep figures, English labels (Environments, New run / Start, My skills, Elements, Acknowledged…), American spelling, real Groups and Audit log tables, generic New joiner, one assistant entry point, no Cookies item; accessibility (h1 per screen, h2/h3, skip link, Escape + focus return, arrow keys in tablists, 11 px / 24 px floors, 0 axe violations); **light and dark themes** (THEME · System · Light · Dark in the prototype bar, Appearance in the account menu). |
| `canvas/project/Architecture.dc.html`, `CatalogueLab`, `ViewsLab`, `ProcessLab` | `canvas/project/` (replace) | Rebuilt with the "Elements" tab (was Catalogue) and American spelling; otherwise as before. |
| `canvas/project/canvas.json` | `canvas/project/canvas.json` (replace) | Index as published (version 225): the production vision's new title. |
| `canvas/html/*.html` | `canvas/html/` (replace) | Standalone pages of the five boards. |
| `tooling/vision_theme.py` (new), `tooling/vision_polish.py` (new) | `tooling/` | The two build-time passes added at the end of `vision_build2.py`: `vision_polish.py` (h1, skip link, named action columns, focusable diagrams, radios, real h2/h3, 11 px / 24 px floors, reduced motion, the keyboard layer helper `layerState / layerBind / layerSync`, removal of the duplicate assistant icon and the cookie item) and `vision_theme.py` (the token pass: every colour literal → `--c-<hex>`, light and dark values by design-system role, attribute selectors for SVG, dark surfaces kept, `color-scheme`). Light renders pixel-identical to before the pass. |
| `tooling/vision_parts.py`, `vision_sweep.py`, `vision_docs.py`, `vision_arch.py`, `vision_build2.py`, `docs_lab_build.py`, `docs_lab_data.py`, `admin_lab_build.py`, `catalog_lab_build.py`, `shell.py`, `navgen.py`, `tooling/vision-prototype-src/*` | `tooling/` (replace) | The content changes of the review (section 3 of the doc). `shell.py` / `navgen.py`: the bottom bar and rail say "Environments"; the Users and Connectors explanations are gone; the admin placeholder is no longer used by the vision. `vision_docs.py` / `vision_arch.py`: `arTarget`, a navigation target the Docs home and the assistant's sources hand to the Architecture board. |
| `tooling/architecture-board/*` | `tooling/architecture-board/` (replace) | `arch_logic.js` / `build_arch.py`: area key and tab "Elements", compact tree rows and scrolling tab strip under 600 px; `how_data.py`: spelling. |
| `project-docs/vision-consistency-review.md` | `project-docs/` (new) | The review: findings by criterion, decisions, what was done, what is left. |
| `review/` | — | The audit scripts (`crawl.js`: every screen with axe, light or `THEME=dark`; `resp.js`: 360 · 600 · 840 · 1200 with and without the assistant pane), their last results (`crawl.json`, `crawl_dark.json`, `resp.json`) and three contact sheets (dark theme, 360 px, Environments). |

## Rebuild

```
cd tooling
python3 vision_build2.py ../canvas/project/ProductionVision.dc.html        # merged, polished, themed
python3 architecture-board/build_arch.py architecture-board/arch_data.json ../canvas/project/Architecture.dc.html
ARCH_DATA=architecture-board/arch_data.json python3 architecture-board/build_catlab.py ../canvas/project/CatalogueLab.dc.html
ARCH_DATA=architecture-board/arch_data.json python3 architecture-board/build_labs.py ../canvas/project/ViewsLab.dc.html ../canvas/project/ProcessLab.dc.html
python3 convert.py ../canvas/project ../canvas/html
cd ../review && npm i axe-core@4.10.2 && node crawl.js && THEME=dark node crawl.js && node resp.js   # the audit (needs playwright)
```

`vision_build2.py` expects the bundle's `vision_parts.py`, `vision_sweep.py`, `vision_docs.py`, `docs_lab_build.py`,
`admin_lab_build.py`, `catalog_lab_build.py`, `docs_lab_data.py`, `docs_arch.py/.js`, `archimate_ds.py/.css`,
`archimate_notation.json`, `_lc_css.txt`, `shell.py`, `navgen.py` beside it (the ones this package carries replace the
bundle's).

## Not changed

Community's scope (kept as is by decision); the design-system boards (tokens, components, Switch) ; the standalone
Architecture board and the labs stay light-only (the theme pass belongs to the vision build).

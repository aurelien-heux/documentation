const { chromium } = require('playwright'); const fs = require('fs');
const AXE = fs.readFileSync('node_modules/axe-core/axe.min.js', 'utf8');
const URL = 'file:///tmp/claude-0/-home-claude/9b4714a9-24af-5c91-898a-a1837084ed77/scratchpad/build/out/ProductionVision.html';
const out = [];
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1600, height: 1000 } });
  const errs = []; p.on('pageerror', e => errs.push(e.message.slice(0, 200)));
  await p.goto(URL); await p.waitForTimeout(2000);
  if (process.env.THEME) { await p.evaluate(t => __dcInstance.setState({ theme: t }), process.env.THEME); await p.waitForTimeout(300); }
  await p.addScriptTag({ content: AXE });
  const rail = name => p.locator('nav.nav-side button, nav.nav-side a').filter({ hasText: new RegExp('^\\s*' + name + '\\s*$') }).first();
  const escNotes = [];
  async function dismiss(ctx) {
    await p.keyboard.press('Escape'); await p.waitForTimeout(250);
    if (await p.locator('.scrim').isVisible().catch(() => false)) {
      escNotes.push(ctx + ': Escape does not close the layer');
      const c = p.locator('[role=dialog] button, .dlg button, .sheet button').filter({ hasText: /^(Cancel|Close|Done|Not now|Dismiss)$/ }).first();
      if (await c.count()) await c.click({ timeout: 1000 }).catch(() => {}); else await p.locator('.scrim').click({ position: { x: 5, y: 5 }, timeout: 1000 }).catch(() => {});
      await p.waitForTimeout(250);
      if (await p.locator('.scrim').isVisible().catch(() => false)) { escNotes.push(ctx + ': scrim click does not close either'); await p.evaluate(() => { const i = window.__dcInstance; i.setState({ panel: false, menu: false, help: false, video: null, newIdea: false, micro: false, sw: Object.assign({}, i.state.sw || {}, { dlg: false, confirm: false }) }); }); await p.waitForTimeout(200); }
    }
  }
  async function rec(name, shot) {
    await p.waitForTimeout(350);
    const d = await p.evaluate(async () => {
      const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const main = document.querySelector('main'); const hdr = document.querySelector('header');
      const dlg = document.querySelector('[role=dialog]');
      const res = await axe.run(document.body, { exclude: [['.simbar']], runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa', 'wcag22aa', 'best-practice'] });
      const v = res.violations.map(x => ({ id: x.id, impact: x.impact, n: x.nodes.length, ex: x.nodes.slice(0, 2).map(nn => nn.html.slice(0, 140)) }));
      const ctrls = [...document.querySelectorAll('main button, main a, main input, main select, main textarea, header button, header input')].filter(vis);
      const noname = ctrls.filter(e => !(e.innerText || '').trim() && !e.getAttribute('aria-label') && !e.getAttribute('title') && !e.getAttribute('placeholder') && !(e.id && document.querySelector('label[for="' + e.id + '"]'))).map(e => e.outerHTML.slice(0, 120));
      const scrollX = document.documentElement.scrollWidth > document.documentElement.clientWidth + 2;
      return { hdr: hdr ? hdr.innerText.replace(/\s+/g, ' ').slice(0, 200) : '', text: (dlg && vis(dlg) ? '[DIALOG] ' + dlg.innerText : main.innerText).replace(/[ \t]+/g, ' ').replace(/\n{2,}/g, '\n'), viol: v, noname, scrollX, headings: [...document.querySelectorAll('main h1,main h2,main h3,main h4')].filter(vis).length };
    });
    d.name = name; d.shot = shot;
    if (shot) await p.screenshot({ path: 'shots/' + (process.env.THEME ? process.env.THEME + '_' : '') + shot + '.png' });
    out.push(d); console.log(name, '| viol', d.viol.filter(x => x.impact === 'serious' || x.impact === 'critical').length, '/', d.viol.length, '| noname', d.noname.length, '| scrollX', d.scrollX);
  }
  async function clickAll(selector, label, max, reset) {
    const n = Math.min(max, await p.locator(selector).count());
    for (let i = 0; i < n; i++) {
      if (reset) await reset();
      const el = p.locator(selector).nth(i); if (!(await el.isVisible().catch(() => false))) continue;
      const t = ((await el.innerText().catch(() => '')) || (await el.getAttribute('aria-label')) || '').trim().replace(/\s+/g, ' ').slice(0, 30);
      await el.click({ timeout: 2000 }).catch(() => {}); await rec(label + ' › ' + t, (label + '_' + i).replace(/[^a-z0-9_]/gi, ''));
    }
  }
  // Sweep
  await rail('Sweep').click(); await rec('Sweep · runs', 'sweep');
  await clickAll('main button.sw-key', 'Sweep run', 5, async () => { await rail('Sweep').click(); await p.waitForTimeout(200); });
  await rail('Sweep').click(); await p.waitForTimeout(200);
  await p.locator('main button.btn.f').filter({ hasText: 'New run' }).click().catch(() => {}); await rec('Sweep · New run dialog', 'sweep_new');
  await dismiss('Sweep New run'); 
  // Envs
  await rail('Environments').click(); await rec('Environments', 'env');
  await p.locator('main button.chip').filter({ hasText: 'Deploy' }).first().click().catch(() => {}); await rec('Environments › Deploy', 'env_deploy'); await dismiss('Env Deploy');
  await rail('Environments').click(); await p.locator('main button.chip').filter({ hasText: 'Reserve' }).first().click().catch(() => {}); await rec('Environments › Reserve', 'env_reserve'); await dismiss('Env Reserve');
  // Docs
  await rail('Docs').click(); await rec('Docs home', 'docs');
  await clickAll('main button.space', 'Docs space', 4, async () => { await rail('Docs').click(); await p.waitForTimeout(200); });
  await rail('Docs').click(); await p.waitForTimeout(200);
  await clickAll('main button.lnk', 'Docs link', 6, async () => { await rail('Docs').click(); await p.waitForTimeout(200); });
  // Catalog
  await rail('Catalog').click(); await rec('Catalog · Browse', 'catalog');
  await p.locator('main button.tab').filter({ hasText: 'My skills' }).click(); await rec('Catalog · Mine', 'catalog_mine');
  await rail('Catalog').click(); await p.locator('main button.tab').filter({ hasText: 'Browse' }).click(); await p.locator('main button.ccard').first().click(); await rec('Catalog · item', 'catalog_item');
  await rail('Catalog').click(); await p.locator('main button.btn.f').filter({ hasText: 'New skill' }).click(); await rec('Catalog · New skill · step 1', 'catalog_new');
  for (let st = 2; st <= 4; st++) { const nx = p.locator('main button').filter({ hasText: /^(Next|Continue|Test|Publish|Submit)/ }).first(); if (!(await nx.count())) break; await nx.click({ timeout: 1500 }).catch(() => {}); await rec('Catalog · New skill · step ' + st, 'catalog_new' + st); }
  // Community
  await rail('Community').click(); await rec('Community · What\'s new', 'community');
  await clickAll('main button.tab', 'Community tab', 3, async () => { await rail('Community').click(); await p.waitForTimeout(200); });
  // Admin
  await rail('Admin').click(); await rec('Admin · General', 'admin');
  await clickAll('main a.ad-ni', 'Admin', 13, null);
  // header: assistant, notifications, help, avatar
  await rail('Sweep').click();
  for (const lab of ['Notifications', 'Help', 'Account', 'Ask']) {
    const el = p.locator('header button').filter({ hasText: new RegExp(lab, 'i') }).first();
    const el2 = p.locator('header button[aria-label*="' + lab + '" i]').first();
    const t = (await el.count()) ? el : el2; if (!(await t.count())) { console.log('no header control', lab); continue; }
    await t.click(); await rec('Header › ' + lab, 'hdr_' + lab.toLowerCase()); await dismiss('Header ' + lab);
  }
  fs.writeFileSync((process.env.THEME ? 'crawl_' + process.env.THEME : 'crawl') + '.json', JSON.stringify(out, null, 1));
  console.log('pageerrors', errs); console.log('ESC', escNotes); fs.writeFileSync('esc.json', JSON.stringify(escNotes));
  await b.close();
})();

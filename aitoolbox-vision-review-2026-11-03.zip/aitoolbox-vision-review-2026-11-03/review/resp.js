const { chromium } = require('playwright'); const fs = require('fs');
const URL = 'file:///tmp/claude-0/-home-claude/9b4714a9-24af-5c91-898a-a1837084ed77/scratchpad/build/out/ProductionVision.html';
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 2000, height: 1300 } });
  await p.goto(URL); await p.waitForTimeout(2000);
  const rail = name => p.locator('nav.nav-side button, nav.nav-side a, nav.nav-bar button, nav.nav-bar a').filter({ hasText: new RegExp('^\\s*' + name + '\\s*$') }).first();
  const notes = [];
  const SCREENS = [
    ['sweep', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'sweep', sw: Object.assign({}, __dcInstance.state.sw || {}, { view: 'list' }) })); }],
    ['sweep_run', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'sweep' })); await p.evaluate(() => __dcInstance.setState({ sw: Object.assign({}, __dcInstance.state.sw || {}, { view: 'run', run: (__dcInstance.swModel().runs[1] || {}).id, tab: 'logs' }) })); }],
    ['env', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'env' })); }],
    ['docs', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'docs', dl: Object.assign({}, __dcInstance.state.dl || {}, { view: 'home' }) })); }],
    ['docs_arch', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'docs', dl: Object.assign({}, __dcInstance.state.dl || {}, { view: 'arch' }) })); }],
    ['catalog', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'catalog', cat: Object.assign({}, __dcInstance.state.cat || {}, { view: 'list', tab: 'browse' }) })); }],
    ['community', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'community', tab: 'new' })); }],
    ['admin', async () => { await p.evaluate(() => __dcInstance.setState({ screen: 'admin', adminView: 'general', mtab: 'releases' })); }],
  ];
  for (const W of [360, 600, 840, 1200]) {
    for (const pane of [false, true]) {
      for (const [name, go] of SCREENS) {
        await go();
        await p.evaluate(({ W, pane }) => { const i = __dcInstance; i.setState({ simW: W, as: Object.assign({}, i.state.as || {}, { open: pane, menu: false }), panel: false, menu: false, help: false, navOpen: false }); }, { W, pane });
        await p.waitForTimeout(500);
        const d = await p.evaluate(() => {
          const f = document.querySelector('.simframe'); const fr = f.getBoundingClientRect();
          const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
          // elements overflowing the frame horizontally
          const over = [...f.querySelectorAll('*')].filter(vis).filter(el => { const r = el.getBoundingClientRect(); return r.right > fr.right + 2 || r.left < fr.left - 2; }).slice(0, 6).map(el => el.tagName + '.' + String(el.className).split(' ').slice(0, 2).join('.') + ' ' + Math.round(el.getBoundingClientRect().right - fr.right));
          const main = f.querySelector('main'); const pane = f.querySelector('.as-pane, .aside, .as, [class*="as-pane"]');
          const mainVis = main && vis(main) && main.getBoundingClientRect().width > 40;
          const paneEl = [...f.querySelectorAll('[class]')].find(e => /as-pane|assistant/i.test(e.className) && vis(e) && e.getBoundingClientRect().width > 100);
          const sw = f.scrollWidth, cw = f.clientWidth;
          const small = [...f.querySelectorAll('button, a, input, select')].filter(vis).filter(e => { const r = e.getBoundingClientRect(); return (r.width < 24 || r.height < 24); }).length;
          const tiny = [...f.querySelectorAll('*')].filter(vis).filter(e => { const fs = parseFloat(getComputedStyle(e).fontSize); return fs && fs < 11 && e.children.length === 0 && (e.textContent || '').trim(); }).length;
          return { over, mainVis, mainW: main ? Math.round(main.getBoundingClientRect().width) : 0, paneW: paneEl ? Math.round(paneEl.getBoundingClientRect().width) : 0, scrollX: sw > cw + 2, small, tiny, nav: ['nav.nav-side', 'nav.nav-bar'].map(s => { const n = f.querySelector(s); return n && vis(n) ? s : null; }).filter(Boolean).join(',') };
        });
        const tag = name + '_' + W + (pane ? '_pane' : '');
        await p.locator('.simframe').screenshot({ path: 'resp/' + tag + '.png' }).catch(() => {});
        notes.push(Object.assign({ tag }, d));
        console.log(tag, JSON.stringify(d));
      }
    }
  }
  fs.writeFileSync('resp.json', JSON.stringify(notes, null, 1));
  await b.close();
})();

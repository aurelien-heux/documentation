// Generated from tokens.json by tools/build-tokens.mjs. Do not edit by hand.
/** AIToolbox colour roles, light and dark. In templates and styles use the CSS custom properties (`var(--md-sys-color-<role>)`) instead. */
export const AIT_COLORS = {
  "primary": {
    "light": "#35307e",
    "dark": "#c4c0ff"
  },
  "on-primary": {
    "light": "#ffffff",
    "dark": "#2a2473"
  },
  "primary-container": {
    "light": "#e3dfff",
    "dark": "#413c8a"
  },
  "on-primary-container": {
    "light": "#14085e",
    "dark": "#e3dfff"
  },
  "secondary": {
    "light": "#514f71",
    "dark": "#c6c2ea"
  },
  "on-secondary": {
    "light": "#ffffff",
    "dark": "#2e2d4d"
  },
  "secondary-container": {
    "light": "#e3dfff",
    "dark": "#454364"
  },
  "on-secondary-container": {
    "light": "#191836",
    "dark": "#e3dfff"
  },
  "tertiary": {
    "light": "#005232",
    "dark": "#00f29e"
  },
  "run": {
    "light": "#0d0b14",
    "dark": "#ece5f8"
  },
  "on-run": {
    "light": "#ffffff",
    "dark": "#14121e"
  },
  "run-icon": {
    "light": "#00f29e",
    "dark": "#006c44"
  },
  "on-tertiary": {
    "light": "#ffffff",
    "dark": "#002111"
  },
  "tertiary-container": {
    "light": "#50ffaf",
    "dark": "#005232"
  },
  "on-tertiary-container": {
    "light": "#002111",
    "dark": "#50ffaf"
  },
  "error": {
    "light": "#93000a",
    "dark": "#ffb4ab"
  },
  "on-error": {
    "light": "#ffffff",
    "dark": "#690005"
  },
  "error-container": {
    "light": "#ffdad6",
    "dark": "#93000a"
  },
  "on-error-container": {
    "light": "#410002",
    "dark": "#ffdad6"
  },
  "surface": {
    "light": "#fdf8fd",
    "dark": "#14121e"
  },
  "on-surface": {
    "light": "#1c1b1e",
    "dark": "#ece5f8"
  },
  "surface-variant": {
    "light": "#e6e0ec",
    "dark": "#494458"
  },
  "on-surface-variant": {
    "light": "#48454e",
    "dark": "#cac3dc"
  },
  "surface-dim": {
    "light": "#ddd9dd",
    "dark": "#14121e"
  },
  "surface-bright": {
    "light": "#fdf8fd",
    "dark": "#484553"
  },
  "nav-container": {
    "light": "#ede4ff",
    "dark": "#1d1a27"
  },
  "nav-active": {
    "light": "#d4d0f9",
    "dark": "#454364"
  },
  "surface-container-lowest": {
    "light": "#ffffff",
    "dark": "#0f0c19"
  },
  "surface-container-low": {
    "light": "#faf4ff",
    "dark": "#1d1a27"
  },
  "surface-container": {
    "light": "#f8f1ff",
    "dark": "#23202d"
  },
  "surface-container-high": {
    "light": "#f2ebfa",
    "dark": "#2b2836"
  },
  "surface-container-highest": {
    "light": "#ece5f4",
    "dark": "#363341"
  },
  "outline": {
    "light": "#79757f",
    "dark": "#948da5"
  },
  "outline-variant": {
    "light": "#cac4cf",
    "dark": "#494458"
  },
  "inverse-surface": {
    "light": "#313033",
    "dark": "#e6dff2"
  },
  "inverse-on-surface": {
    "light": "#f4eff4",
    "dark": "#322e3c"
  },
  "inverse-primary": {
    "light": "#c4c0ff",
    "dark": "#413c8a"
  },
  "scrim": {
    "light": "#000000",
    "dark": "#000000"
  },
  "shadow": {
    "light": "#000000",
    "dark": "#000000"
  },
  "ai": {
    "light": "#80d5d4",
    "dark": "#80d5d4"
  },
  "on-ai": {
    "light": "#003737",
    "dark": "#003737"
  },
  "ai-container": {
    "light": "#9cf1f0",
    "dark": "#004f50"
  },
  "on-ai-container": {
    "light": "#002020",
    "dark": "#9cf1f0"
  },
  "focus-ring": {
    "light": "#35307e",
    "dark": "#c4c0ff"
  },
  "ai-strong": {
    "light": "#006a6a",
    "dark": "#80d5d4"
  },
  "logo-box": {
    "light": "#0d0b14",
    "dark": "#c4c0ff"
  },
  "on-logo-box": {
    "light": "#ffffff",
    "dark": "#0d0b14"
  },
  "logo-cursor": {
    "light": "#00f29e",
    "dark": "#006c44"
  },
  "success": {
    "light": "#1b5f1f",
    "dark": "#91d888"
  },
  "on-success": {
    "light": "#ffffff",
    "dark": "#003908"
  },
  "success-container": {
    "light": "#acf4a2",
    "dark": "#0b5314"
  },
  "on-success-container": {
    "light": "#002203",
    "dark": "#acf4a2"
  },
  "warning": {
    "light": "#6a4e00",
    "dark": "#fcbc00"
  },
  "on-warning": {
    "light": "#ffffff",
    "dark": "#402d00"
  },
  "warning-container": {
    "light": "#ffdea0",
    "dark": "#5c4300"
  },
  "on-warning-container": {
    "light": "#261900",
    "dark": "#ffdea0"
  }
} as const;
export type AitColorRole = keyof typeof AIT_COLORS;
/** Version of the design-system token set this library was built from. */
export const AIT_TOKENS_VERSION = '4.5.0';

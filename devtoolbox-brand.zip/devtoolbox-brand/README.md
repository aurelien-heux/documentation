# DevToolbox brand package

Every SVG exists in two versions:

- `light/` — colours for **light backgrounds** (navy #254487 mark, ink wordmark).
- `dark/` — colours for **dark backgrounds** (tone-80 navy #B1C5FF mark, light wordmark).

Colours are fixed in each file (no automatic switching), so you choose the file that matches the surface. All backgrounds are transparent except the favicon tile and the app icon.

## logos/
- `devtoolbox-logo-horizontal.svg` — mark + wordmark, clear space baked in.
- `devtoolbox-logo-stacked.svg` — centered lockup for square slots and splash screens.
- `devtoolbox-mark.svg` — the toolbox prompt alone.
- `devtoolbox-wordmark.svg` — "DevToolbox" alone (Manrope 800, outlined — no font needed).

## favicon/
- `favicon.svg` — the `>_` glyph on a rounded navy tile (the tile is the box). Use `light/` as the default favicon; browsers in dark mode can be served `dark/` via `<link rel="icon" media="(prefers-color-scheme: dark)">`.
- `favicon-glyph.svg` — the `>_` glyph alone, no tile, for your own backgrounds.
- `app-icon.svg` — full mark reversed on the tile, 512 px, for home-screen / PWA icons (maskable-safe).

## loading-states/
- `brand-loader.svg` — Blueprint: outline drawn, navy pours in, prompt lights up; holds on the logo, loops with a clean cut (3.4 s).
- `brand-loader-once.svg` — same, plays once and stays on the logo (splash intro).
- `circular-indeterminate.svg` (48 px) and `circular-indeterminate-small.svg` (24 px) — Material 3 circular indicator in the primary colour.
- `linear-indeterminate.svg` — Material 3 linear indicator, 4 px.
- `working-dots.svg` — three copper dots for a pending log line.

All animated files respect `prefers-reduced-motion`.

## css/
- `tokens.css` — the whole design system as CSS custom properties (`--md-sys-color-*`, type scale, shape, elevation, motion). Light by default, dark via `prefers-color-scheme` or `<html data-theme="dark">`.
- `loading-states.css` — the keyframes and classes for the loaders when you inline the SVG markup, wired to the tokens so one markup serves both themes.
- `design-tokens.json` — the same values for build tools.

Palette: V · Navy + Violet (primary navy hue 270, secondary violet hue 300, copper tertiary, teal `ai`), v3.0.0.

## states/
- `state-{success,info,warning,error}-filled.svg` — the toolbox with the prompt answering (`>✓` `>i` `>!` `>✕`) in the state colour: snackbars (24 px), popin headers (32 px), table/panel/popin-level error (48 px), page empty states (72–96 px).
- `state-*-tinted.svg` — the same on the state container tint: status chips and table cells (20 px), dropdown options and list-level states (20 px), inline alerts in popins (24 px), page banners (28 px).
- Remote loading shows no mark: use the circular indicator from `loading-states/` in the same slot, then swap it in place for the state mark (warning after a timeout, error + Retry on failure). Info uses the primary colour. Never below 20 px.

## chatbot/
- `chatbot-icon-light.svg` / `chatbot-icon-dark.svg` — the original teal glyph (the `ai` colour), for the assistant avatar.
- `chatbot-brace-box-light.svg` / `chatbot-brace-box-dark.svg` — the brace-box alternate in navy, for the assistant avatar (never as the brand mark).

## fonts/
- `BNPPType-Regular.woff2` — the UI face declared by `tokens.css` (weight 500). Open Sans (body, code) loads from Google Fonts.


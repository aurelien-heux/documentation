# AIToolbox · design system update (2026-11-03, afternoon)

Drop-in for the export bundle (`AIToolbox-export/`). Same layout: copy each folder over the bundle's folder of the same name.
Builds on the morning package `aitoolbox-architecture-update` (Architecture feature mark, Meridian Bank page, change process).

| From this package | Into the bundle | What changed |
|---|---|---|
| `canvas/project/Architecture.dc.html` | `canvas/project/` (new) | **Architecture · Meridian Bank, live prototype** (Prototypes page). No LikeC4: every view is a grid, matrix or timeline of design-system ArchiMate components. Tabs Catalogue · Views · Process. Catalogue = one tree, searched from the header field. Views by level: Enterprise 8, Portfolio 9, Application 3, including the new matrices (capabilities × value streams, roles × processes, application interaction, processes × applications, applications × technologies). Process: changes on the adjusted TOGAF flow (6 phases, gates G1–G4, entry points), ARB page with the full ASD (13 items), checks, reviewers, conditions, decision by role; How it works. |
| `canvas/project/CatalogueLab.dc.html` | `canvas/project/` (new) | Catalogue lab (Decision labs page): A One tree (adopted) · B Explorer · C Facets · D Search first. |
| `canvas/project/ViewsLab.dc.html` | `canvas/project/` (new) | Views lab: A By level (adopted) · B By ADM phase · C Gallery · D By role. |
| `canvas/project/ProcessLab.dc.html` | `canvas/project/` (new) | Process lab: A By object (adopted) · B Board by phase · C Agenda & roadmap · D Inbox. |
| `canvas/project/canvas.json` | `canvas/project/canvas.json` (replace) | Index of the canvas as published (version 221): the four boards above, the "Architecture" title on the Prototypes page, the "Architecture labs" title on the Decision labs page. Every other board unchanged. |
| `canvas/html/*.html` | `canvas/html/` (new) | The four boards as standalone pages (open in any browser, no canvas needed). Add them to `canvas/html/index.html`. |
| `tooling/architecture-board/` | `tooling/architecture-board/` (new) | Generator of the four boards: `data_prep.py`, `build_arch.py`, `build_catlab.py`, `build_labs.py`, `arch_logic.js`, `how_data.py` (adjusted flow, gates, entry points, side cases as data), `arch_data.json`. Uses `tooling/shell.py` and `tooling/navgen.py`. |
| `tooling/convert.py`, `dc-standalone.js`, `markup_check.py` | `tooling/` (replace) | Unchanged in behaviour; included so the package builds on its own. |
| `project-docs/architecture-prototype-board.md` | `project-docs/` (new) | Decisions DEC-KB-24 to 33 and open points OPP-ARC-10 to 15 (also in the claude.ai Project, `claude/architecture-prototype-board.md`). |

## Rebuild

```
cd tooling/architecture-board
python3 data_prep.py <mb_model.json> arch_data.json        # only if the Meridian Bank model changed
python3 build_arch.py arch_data.json Architecture.dc.html
ARCH_DATA=arch_data.json python3 build_catlab.py CatalogueLab.dc.html
ARCH_DATA=arch_data.json python3 build_labs.py ViewsLab.dc.html ProcessLab.dc.html
python3 ../convert.py <folder with the .dc.html> ../../canvas/html
```

## Not changed

Design system tokens, components, assets and README (the Architecture feature mark is in the morning package). The
adjusted TOGAF flow is summarized from its first section only (OPP-ARC-14): gate criteria and who decides at each gate
are to be aligned on the source page.

# AIToolbox brand package

Every SVG exists in two versions:

- `light/` — colours for **light backgrounds** (navy #254487 mark, ink wordmark).
- `dark/` — colours for **dark backgrounds** (tone-80 navy #B1C5FF mark, light wordmark).

Colours are fixed in each file (no automatic switching), so you choose the file that matches the surface. All backgrounds are transparent except the favicon tile and the app icon.

## logos/
- `aitoolbox-logo-horizontal.svg` — mark + wordmark, clear space baked in.
- `aitoolbox-logo-stacked.svg` — centered lockup for square slots and splash screens.
- `aitoolbox-mark.svg` — the toolbox prompt with the AI badge (light teal `ai` #80D5D4 with "AI" in #003737 — the same in both themes, only `ai-container` changes) on its top-right corner, cut out of the mark; use from 24 px up.
- `aitoolbox-mark-plain.svg` — the mark without the badge, for the favicon, app icon, loader and anything under 24 px.
- `aitoolbox-wordmark.svg` — "AIToolbox" alone, "AI" in ink and "Toolbox" in navy (Manrope 800, outlined — no font needed).

## favicon/
- `favicon.svg` — the `>_` glyph on a rounded navy tile (the tile is the box). Use `light/` as the default favicon; browsers in dark mode can be served `dark/` via `<link rel="icon" media="(prefers-color-scheme: dark)">`.
- `favicon-glyph.svg` — the `>_` glyph alone, no tile, for your own backgrounds.
- `app-icon.svg` — full mark reversed on the tile, 512 px, for home-screen / PWA icons (maskable-safe).

## loading-states/
- `brand-loader.svg` — Constructor: the AI badge arrives alone, dashed construction guides appear, a teal pen leaves the badge and draws the toolbox in one trip, goes home, and the navy toolbox becomes solid; holds on the logo, loops with a clean cut (4.4 s). Its viewBox is `-4 2 76 64` (badge, guides and pen all inside, nothing clipped), so size it by height: 96 px tall = 114 px wide.
- `brand-loader-once.svg` — same, plays once and stays on the logo (splash intro).
- `circular-indeterminate.svg` (48 px) and `circular-indeterminate-small.svg` (24 px, also 18 px inside a button) — pen orbit: a navy arc with the teal pen at its head runs around a faint track. Same sizes and roles as Material's circular indicator (`mat-progress-spinner` keeps its slot; this is its skin).
- `linear-indeterminate.svg` / `linear-determinate.svg` — guide line: a dashed teal construction guide as the track, the navy bar runs along it with the pen at its leading edge; determinate = navy to the value, pen on the edge, dashes for the rest. 4 px, top of the app bar, cards, table loading rows (`mat-progress-bar`).
- `brand-progress.svg` — Constructor determinate for long operations with a known value (install, deploy, migration): the pen draws the box in proportion to `--p` (0–100); at 100 add `ait-cd-done` and the toolbox fills. 64–96 px, dialogs and empty states. `brand-progress-demo.svg` loops the cycle.
- `working-dots.svg` (copper, a command is executing) and `working-dots-ai.svg` (teal, a model is thinking) — inline after a log line or a chat message.

All animated files respect `prefers-reduced-motion`.

## css/
- `tokens.css` — the whole design system as CSS custom properties (`--md-sys-color-*`, type scale, shape, elevation, motion). Light by default, dark via `prefers-color-scheme` or `<html data-theme="dark">`.
- `loading-states.css` — the keyframes and classes for the loaders when you inline the SVG markup, wired to the tokens so one markup serves both themes.
- `design-tokens.json` — the same values for build tools.

Palette: V · Navy + Violet (primary navy hue 270, secondary violet hue 300, copper tertiary, light-teal `ai` fixed across themes), v3.1.0.

## states/
The state mark is the logo's construction with the state in the badge instead of "AI": the toolbox never changes, the corner badge carries the state role and a symbol (✓ success, i info, ! warning, ✕ error). Pick the file by size:
- `state-<state>-badge.svg` — alone on a surface, 24–40 px: snackbars (24, dark file on the inverse surface), inline alerts and banners (24–28), popin headers (32–40).
- `state-<state>-circle.svg` — in a circle, 56–96 px: table-, panel- or popin-level empty/error states (56–64), page empty states (72–96). Disc in the state role, toolbox reversed, badge in the state container.
- `state-<state>-tile.svg` / `state-<state>-tile-tinted.svg` — tile glyph, 18–20 px: table cells and rows (filled), status chips and dropdown options (tinted).
- `state-pending.svg` — the same circle slot while a request is pending (pen-orbit ring around the plain mark); swap it in place for the state when the request resolves: warning after a timeout, error with Retry on failure. Small slots use the 24 / 18 px pen orbit from `loading-states/`.
Info uses the primary colour. Never below 18 px, never recoloured, no entrance animation.

## angular/
- `theme.m2.scss` — Angular Material 17–18 theme (Material 2 API, `mat.m2-*`): AIToolbox palettes in the 50–900 hue shape, light and dark themes, typography on the M2 levels, surfaces injected, scoped `.dt-run` / `.dt-ai` / `.dt-chip-*` themes.
- `_theme-colors.scss` + `theme.m3.scss` — Angular Material 19+ (`mat.theme`): the palettes in the `theme-color` schematic shape, system variables pinned to the token values with `mat.theme-overrides`, component overrides for Run, AI, health chips and shape.
- `mat-sys-bridge.css` — maps `--md-sys-color-*` from `css/tokens.css` to `--mat-sys-*` at runtime.
- `README.md` — version timeline, role and typography mapping, every Angular Material component mapped to its AIToolbox component with M2 / M3 notes, migration checklist.

## chatbot/
- `chatbot-icon-light.svg` / `chatbot-icon-dark.svg` — the original teal glyph (the `ai` colour), for the assistant avatar.
- `chatbot-brace-box-light.svg` / `chatbot-brace-box-dark.svg` — the brace box `{ >_ }` drawn as one outline (left, top and right braces merged, hooks at the bottom) in navy, for the assistant avatar: 32 px in the panel header, 24 px in bubbles. Never as the brand mark.

## fonts/
- `BNPPType-Regular.woff2` — the UI face declared by `tokens.css` (weight 500). Open Sans (body, code) loads from Google Fonts.


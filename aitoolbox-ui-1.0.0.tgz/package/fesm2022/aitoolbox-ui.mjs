import * as i0 from '@angular/core';
import { inject, Injectable, makeEnvironmentProviders, provideEnvironmentInitializer, computed, input, numberAttribute, isDevMode, ChangeDetectionStrategy, Component, booleanAttribute, ElementRef, DestroyRef, afterNextRender, Directive, output, InjectionToken, model, viewChild, linkedSignal, signal, effect, forwardRef } from '@angular/core';
import { MatIconRegistry, MatIcon } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { BreakpointObserver } from '@angular/cdk/layout';
import { toSignal } from '@angular/core/rxjs-interop';
import { map } from 'rxjs';
import { NgTemplateOutlet } from '@angular/common';
import { MatChip, MatChipAvatar } from '@angular/material/chips';
import { MatIconButton, MatButton } from '@angular/material/button';
import { MAT_SNACK_BAR_DATA, MatSnackBarRef, MatSnackBar } from '@angular/material/snack-bar';
import { MAT_DIALOG_DATA, MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, MatDialog } from '@angular/material/dialog';
import * as i1 from '@angular/material/tooltip';
import { MatTooltip } from '@angular/material/tooltip';
import { MatMenu, MatMenuItem, MatMenuTrigger } from '@angular/material/menu';
import { MatDivider } from '@angular/material/divider';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MatNavList, MatListItem, MatListItemIcon, MatListItemTitle, MatListItemMeta } from '@angular/material/list';
import { MatSidenavContainer, MatSidenav, MatSidenavContent } from '@angular/material/sidenav';

/** Default words for each state, used as accessible names when no label is given. */
const AIT_STATE_LABELS = {
    success: 'Success',
    info: 'Info',
    warning: 'Warning',
    error: 'Error',
    pending: 'Loading',
    unknown: 'Unknown',
};
let nextUid = 0;
/** Unique id prefix for SVG masks and ARIA relations, stable for the life of one component. */
function aitUid(prefix = 'ait') {
    nextUid += 1;
    return `${prefix}-${nextUid}`;
}

// Generated from tokens.json by tools/build-tokens.mjs. Do not edit by hand.
/** AIToolbox colour roles, light and dark. In templates and styles use the CSS custom properties (`var(--md-sys-color-<role>)`) instead. */
const AIT_COLORS = {
    "primary": {
        "light": "#35307e",
        "dark": "#c4c0ff"
    },
    "on-primary": {
        "light": "#ffffff",
        "dark": "#2a2473"
    },
    "primary-container": {
        "light": "#e3dfff",
        "dark": "#413c8a"
    },
    "on-primary-container": {
        "light": "#14085e",
        "dark": "#e3dfff"
    },
    "secondary": {
        "light": "#514f71",
        "dark": "#c6c2ea"
    },
    "on-secondary": {
        "light": "#ffffff",
        "dark": "#2e2d4d"
    },
    "secondary-container": {
        "light": "#e3dfff",
        "dark": "#454364"
    },
    "on-secondary-container": {
        "light": "#191836",
        "dark": "#e3dfff"
    },
    "tertiary": {
        "light": "#005232",
        "dark": "#00f29e"
    },
    "run": {
        "light": "#0d0b14",
        "dark": "#ece5f8"
    },
    "on-run": {
        "light": "#ffffff",
        "dark": "#14121e"
    },
    "run-icon": {
        "light": "#00f29e",
        "dark": "#006c44"
    },
    "on-tertiary": {
        "light": "#ffffff",
        "dark": "#002111"
    },
    "tertiary-container": {
        "light": "#50ffaf",
        "dark": "#005232"
    },
    "on-tertiary-container": {
        "light": "#002111",
        "dark": "#50ffaf"
    },
    "error": {
        "light": "#93000a",
        "dark": "#ffb4ab"
    },
    "on-error": {
        "light": "#ffffff",
        "dark": "#690005"
    },
    "error-container": {
        "light": "#ffdad6",
        "dark": "#93000a"
    },
    "on-error-container": {
        "light": "#410002",
        "dark": "#ffdad6"
    },
    "surface": {
        "light": "#fdf8fd",
        "dark": "#14121e"
    },
    "on-surface": {
        "light": "#1c1b1e",
        "dark": "#ece5f8"
    },
    "surface-variant": {
        "light": "#e6e0ec",
        "dark": "#494458"
    },
    "on-surface-variant": {
        "light": "#48454e",
        "dark": "#cac3dc"
    },
    "surface-dim": {
        "light": "#ddd9dd",
        "dark": "#14121e"
    },
    "surface-bright": {
        "light": "#fdf8fd",
        "dark": "#484553"
    },
    "nav-container": {
        "light": "#ede4ff",
        "dark": "#1d1a27"
    },
    "nav-active": {
        "light": "#d4d0f9",
        "dark": "#454364"
    },
    "surface-container-lowest": {
        "light": "#ffffff",
        "dark": "#0f0c19"
    },
    "surface-container-low": {
        "light": "#faf4ff",
        "dark": "#1d1a27"
    },
    "surface-container": {
        "light": "#f8f1ff",
        "dark": "#23202d"
    },
    "surface-container-high": {
        "light": "#f2ebfa",
        "dark": "#2b2836"
    },
    "surface-container-highest": {
        "light": "#ece5f4",
        "dark": "#363341"
    },
    "outline": {
        "light": "#79757f",
        "dark": "#948da5"
    },
    "outline-variant": {
        "light": "#cac4cf",
        "dark": "#494458"
    },
    "inverse-surface": {
        "light": "#313033",
        "dark": "#e6dff2"
    },
    "inverse-on-surface": {
        "light": "#f4eff4",
        "dark": "#322e3c"
    },
    "inverse-primary": {
        "light": "#c4c0ff",
        "dark": "#413c8a"
    },
    "scrim": {
        "light": "#000000",
        "dark": "#000000"
    },
    "shadow": {
        "light": "#000000",
        "dark": "#000000"
    },
    "ai": {
        "light": "#80d5d4",
        "dark": "#80d5d4"
    },
    "on-ai": {
        "light": "#003737",
        "dark": "#003737"
    },
    "ai-container": {
        "light": "#9cf1f0",
        "dark": "#004f50"
    },
    "on-ai-container": {
        "light": "#002020",
        "dark": "#9cf1f0"
    },
    "focus-ring": {
        "light": "#35307e",
        "dark": "#c4c0ff"
    },
    "ai-strong": {
        "light": "#006a6a",
        "dark": "#80d5d4"
    },
    "logo-box": {
        "light": "#0d0b14",
        "dark": "#c4c0ff"
    },
    "on-logo-box": {
        "light": "#ffffff",
        "dark": "#0d0b14"
    },
    "logo-cursor": {
        "light": "#00f29e",
        "dark": "#006c44"
    },
    "success": {
        "light": "#1b5f1f",
        "dark": "#91d888"
    },
    "on-success": {
        "light": "#ffffff",
        "dark": "#003908"
    },
    "success-container": {
        "light": "#acf4a2",
        "dark": "#0b5314"
    },
    "on-success-container": {
        "light": "#002203",
        "dark": "#acf4a2"
    },
    "warning": {
        "light": "#6a4e00",
        "dark": "#fcbc00"
    },
    "on-warning": {
        "light": "#ffffff",
        "dark": "#402d00"
    },
    "warning-container": {
        "light": "#ffdea0",
        "dark": "#5c4300"
    },
    "on-warning-container": {
        "light": "#261900",
        "dark": "#ffdea0"
    }
};
/** Version of the design-system token set this library was built from. */
const AIT_TOKENS_VERSION = '4.5.0';

const svg = (body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
/**
 * The outlined icons the UI Components use internally (24 px grid, 2 px stroke, currentColor), registered in the
 * `ait` namespace of MatIconRegistry: `<mat-icon svgIcon="ait:search">`. Static literals only; nothing user-provided.
 */
const AIT_ICONS = {
    search: svg('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
    menu: svg('<path d="M4 7h16M4 12h16M4 17h16"/>'),
    close: svg('<path d="M18 6L6 18M6 6l12 12"/>'),
    check: svg('<path d="M20 6L9 17l-5-5"/>'),
    play: svg('<path d="M7 4l12 8-12 8z"/>'),
    stop: svg('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
    'chevron-down': svg('<path d="M7 10l5 5 5-5"/>'),
    'chevron-left': svg('<path d="M15 18l-6-6 6-6"/>'),
    'chevron-right': svg('<path d="M9 18l6-6-6-6"/>'),
    help: svg('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7"/><path d="M12 17h.01"/>'),
    sparkle: svg('<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7z"/>'),
    settings: svg('<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14 3h-4l-.4 2.6a7 7 0 0 0-2 1.2l-2.4-.9-2 3.4 2 1.5a7 7 0 0 0 0 2.4l-2 1.5 2 3.4 2.4-.9a7 7 0 0 0 2 1.2L10 21h4l.4-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.1-.4.1-.8.1-1.2z"/>'),
    shield: svg('<path d="M12 3l8 3v6c0 4.5-3.4 8.3-8 9-4.6-.7-8-4.5-8-9V6z"/>'),
    person: svg('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
    key: svg('<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l3 3M15 8l2 2"/>'),
    palette: svg('<path d="M12 3a9 9 0 1 0 0 18c1.1 0 1.5-.8 1.5-1.5 0-.9-.6-1.2-.6-2 0-.8.6-1.5 1.6-1.5H17a4 4 0 0 0 4-4c0-5-4-9-9-9z"/><circle cx="7.5" cy="11" r="1"/><circle cx="10" cy="7.5" r="1"/><circle cx="14.5" cy="7.5" r="1"/>'),
    logout: svg('<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5M15 12H4"/>'),
    bell: svg('<path d="M6 16V11a6 6 0 0 1 12 0v5l1.5 2h-15z"/><path d="M10 20a2 2 0 0 0 4 0"/>'),
    copy: svg('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>'),
    refresh: svg('<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>'),
    info: svg('<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>'),
    grid: svg('<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>'),
    book: svg('<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 21V5M8 7h7"/>'),
    tasks: svg('<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6l1 1 2-2M4 12l1 1 2-2M4 18l1 1 2-2"/>'),
    environments: svg('<circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/><path d="M7 12h3M14 12h3"/>'),
    swatch: svg('<circle cx="12" cy="12" r="8"/><circle cx="9" cy="10" r="1.2"/><circle cx="14" cy="8.5" r="1.2"/><circle cx="16" cy="13" r="1.2"/>'),
};
/** Registers the `ait:` icons once per injector tree. The UI Components inject it themselves. */
class AitIconRegistry {
    constructor() {
        const registry = inject(MatIconRegistry);
        const sanitizer = inject(DomSanitizer);
        for (const [name, literal] of Object.entries(AIT_ICONS)) {
            // Constant, library-owned SVG strings: the standard MatIconRegistry pattern for static icon literals.
            registry.addSvgIconLiteralInNamespace('ait', name, sanitizer.bypassSecurityTrustHtml(literal));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitIconRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitIconRegistry, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitIconRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });
/** Registers the `ait:` icon set at startup, for apps that use `<mat-icon svgIcon="ait:…">` in their own templates. */
function provideAitIcons() {
    return makeEnvironmentProviders([provideEnvironmentInitializer(() => inject(AitIconRegistry))]);
}

// AIToolbox — Material 3 window size classes for Angular (CDK BreakpointObserver).
// The CDK Breakpoints constants (600 / 960 / 1280 / 1920) do not match Material 3: use these queries instead.
const AIT_BREAKPOINTS = { medium: 600, expanded: 840, large: 1200, extraLarge: 1600 };
const AitWindow = {
    Compact: '(max-width: 599.98px)',
    Medium: '(min-width: 600px) and (max-width: 839.98px)',
    Expanded: '(min-width: 840px) and (max-width: 1199.98px)',
    Large: '(min-width: 1200px) and (max-width: 1599.98px)',
    ExtraLarge: '(min-width: 1600px)',
    ShortHeight: '(max-height: 479.98px)',
};
/** Current window class and the shell decisions that follow from it (signals). */
class AitWindowClass {
    observer = inject(BreakpointObserver);
    state = toSignal(this.observer.observe(Object.values(AitWindow)).pipe(map(() => ({
        cls: this.observer.isMatched(AitWindow.ExtraLarge) ? 'extra-large'
            : this.observer.isMatched(AitWindow.Large) ? 'large'
                : this.observer.isMatched(AitWindow.Expanded) ? 'expanded'
                    : this.observer.isMatched(AitWindow.Medium) ? 'medium' : 'compact',
        short: this.observer.isMatched(AitWindow.ShortHeight),
    }))), { requireSync: true });
    windowClass = computed(() => this.state().cls, ...(ngDevMode ? [{ debugName: "windowClass" }] : /* istanbul ignore next */ []));
    isCompact = computed(() => this.state().cls === 'compact', ...(ngDevMode ? [{ debugName: "isCompact" }] : /* istanbul ignore next */ []));
    /** bottom NavigationBar under 600 px (rail on a phone in landscape), rail 600–1199 px, drawer from 1200 px. */
    navigation = computed(() => {
        const c = this.state().cls;
        if (c === 'compact')
            return this.state().short ? 'rail' : 'bar';
        return c === 'medium' || c === 'expanded' ? 'rail' : 'drawer';
    }, ...(ngDevMode ? [{ debugName: "navigation" }] : /* istanbul ignore next */ []));
    /** mat-sidenav mode for the drawer: side from 1200 px, over below. */
    drawerMode = computed(() => (this.navigation() === 'drawer' ? 'side' : 'over'), ...(ngDevMode ? [{ debugName: "drawerMode" }] : /* istanbul ignore next */ []));
    assistantMode = computed(() => {
        const c = this.state().cls;
        return c === 'compact' ? 'full-screen' : c === 'medium' || c === 'expanded' ? 'in-place' : 'docked';
    }, ...(ngDevMode ? [{ debugName: "assistantMode" }] : /* istanbul ignore next */ []));
    /** forms in dialogs open full screen under 600 px or on a short screen. */
    fullScreenDialogs = computed(() => this.state().cls === 'compact' || this.state().short, ...(ngDevMode ? [{ debugName: "fullScreenDialogs" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitWindowClass, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitWindowClass, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitWindowClass, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const DEFAULT_SIZE = { badge: 24, circle: 64, tile: 20, tinted: 18 };
/**
 * StateMark — the feedback icon of the system: the logo's construction with the state in the corner badge.
 * Decorative by default (`aria-hidden`), because the word next to it carries the state; give it a `label` when it stands alone.
 *
 * ```html
 * <ait-state-mark state="error" variant="tile" /> Failed
 * <ait-state-mark state="warning" variant="badge" [size]="32" label="Warning" />
 * ```
 */
class AitStateMark {
    /** success · info · warning · error, or pending while a request runs. */
    state = input.required(...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    /** Dressing, chosen by size (see AitStateMarkVariant). Ignored while pending. */
    variant = input('badge', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Height in px. Defaults: badge 24, circle 64, tile 20, tinted 18, pending 64. Never below 18. */
    size = input(undefined, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: (v) => (v == null || v === '' ? undefined : numberAttribute(v)) });
    /** Accessible name. Leave empty when a visible word next to the mark already says the state. */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    uid = aitUid('ait-sm');
    shape = computed(() => (this.state() === 'pending' ? 'pending' : this.variant()), ...(ngDevMode ? [{ debugName: "shape" }] : /* istanbul ignore next */ []));
    resolvedSize = computed(() => {
        const shape = this.shape();
        const size = this.size() ?? (shape === 'pending' ? 64 : DEFAULT_SIZE[shape]);
        if (isDevMode() && size < 18) {
            console.warn(`[ait-state-mark] ${size} px is below the 18 px minimum; use an 8 px dot instead.`);
        }
        return Math.max(size, 18);
    }, ...(ngDevMode ? [{ debugName: "resolvedSize" }] : /* istanbul ignore next */ []));
    /** Default word for the state, for callers that need it. */
    static labelFor(state) {
        return AIT_STATE_LABELS[state];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitStateMark, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitStateMark, isStandalone: true, selector: "ait-state-mark", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: true, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "\"ait-sm-\" + state()", "attr.role": "label() ? \"img\" : null", "attr.aria-label": "label() || null", "attr.aria-hidden": "label() ? null : \"true\"", "style.height.px": "resolvedSize()" }, classAttribute: "ait-state-mark" }, ngImport: i0, template: `
    @switch (shape()) {
      @case ('badge') {
        <svg viewBox="0 0 74 64" [attr.height]="resolvedSize()" [attr.width]="resolvedSize() * 74 / 64" focusable="false">
          <mask [attr.id]="uid + '-m'" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64">
            <rect width="74" height="64" fill="#fff" /><rect x="44.5" y="0.5" width="29" height="29" rx="8.5" fill="#000" />
          </mask>
          <g [attr.mask]="'url(#' + uid + '-m)'">
            <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
            <rect x="4" y="22" width="56" height="36" rx="10" class="box-fill" />
            <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
          </g>
          <rect x="47" y="3" width="24" height="24" rx="6" class="badge-fill" />
          <ng-container *ngTemplateOutlet="badgeSymbol" />
        </svg>
      }
      @case ('circle') {
        <svg viewBox="0 0 100 100" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false">
          <circle cx="50" cy="50" r="48" class="disc" />
          <g transform="translate(17.62 22) scale(0.875)">
            <mask [attr.id]="uid + '-m'" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64">
              <rect width="74" height="64" fill="#fff" /><rect x="44.5" y="0.5" width="29" height="29" rx="8.5" fill="#000" />
            </mask>
            <g [attr.mask]="'url(#' + uid + '-m)'">
              <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="rev-stroke" stroke-width="6" stroke-linecap="round" />
              <rect x="4" y="22" width="56" height="36" rx="10" class="rev-fill" />
              <path d="M17.5 33l8 7-8 7" fill="none" class="role-stroke" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M33.5 47h13" fill="none" class="role-stroke" stroke-width="5.5" stroke-linecap="round" />
            </g>
            <rect x="47" y="3" width="24" height="24" rx="6" class="ctr-fill" />
            <ng-container *ngTemplateOutlet="badgeSymbol; context: { $implicit: 'on-ctr' }" />
          </g>
        </svg>
      }
      @case ('pending') {
        <svg viewBox="0 0 100 100" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false" class="ait-motion">
          <circle cx="50" cy="50" r="48" fill="none" class="track" stroke-width="4" />
          <g class="orbit">
            <circle cx="50" cy="50" r="48" fill="none" class="arc" stroke-width="4" stroke-linecap="round" stroke-dasharray="156.8 144.8" transform="rotate(-90 50 50)" />
            <circle cx="43.98" cy="97.62" r="4" class="pen" />
          </g>
          <g transform="translate(22 22) scale(0.875)">
            <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
            <rect x="4" y="22" width="56" height="36" rx="10" class="box-fill" />
            <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
          </g>
        </svg>
      }
      @default {
        <svg viewBox="0 0 64 64" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false" [class.tinted]="shape() === 'tinted'">
          <rect width="64" height="64" rx="14" class="tile" />
          <path d="M17 23l10 9-10 9" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" />
          @switch (state()) {
            @case ('success') { <path d="M35 33l5 5 10-10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" /> }
            @case ('info') { <path d="M42 31v10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /><circle cx="42" cy="21" r="4" class="tile-dot" /> }
            @case ('warning') { <path d="M42 23v10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /><circle cx="42" cy="43" r="4" class="tile-dot" /> }
            @case ('error') { <path d="M35 25l14 14M49 25L35 39" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /> }
          }
        </svg>
      }
    }

    <ng-template #badgeSymbol let-ink>
      <svg:g [attr.class]="ink === 'on-ctr' ? 'sym on-ctr' : 'sym'">
        @switch (state()) {
          @case ('success') { <svg:path d="M52 15.5l4.5 4.5 9.5-9.5" fill="none" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" /> }
          @case ('info') { <svg:path d="M59 13.5v7.5" fill="none" stroke-width="3.5" stroke-linecap="round" /><svg:circle cx="59" cy="8.5" r="2.2" /> }
          @case ('warning') { <svg:path d="M59 8v7.5" fill="none" stroke-width="3.5" stroke-linecap="round" /><svg:circle cx="59" cy="21" r="2.2" /> }
          @case ('error') { <svg:path d="M54 10l10 10M64 10L54 20" fill="none" stroke-width="3.5" stroke-linecap="round" /> }
        }
      </svg:g>
    </ng-template>
  `, isInline: true, styles: [":host{display:inline-flex;flex:none;line-height:0;vertical-align:middle}:host(.ait-sm-success){--_role: var(--md-sys-color-success);--_on: var(--md-sys-color-on-success);--_ctr: var(--md-sys-color-success-container);--_on-ctr: var(--md-sys-color-on-success-container)}:host(.ait-sm-info){--_role: var(--md-sys-color-primary);--_on: var(--md-sys-color-on-primary);--_ctr: var(--md-sys-color-primary-container);--_on-ctr: var(--md-sys-color-on-primary-container)}:host(.ait-sm-warning){--_role: var(--md-sys-color-warning);--_on: var(--md-sys-color-on-warning);--_ctr: var(--md-sys-color-warning-container);--_on-ctr: var(--md-sys-color-on-warning-container)}:host(.ait-sm-error){--_role: var(--md-sys-color-error);--_on: var(--md-sys-color-on-error);--_ctr: var(--md-sys-color-error-container);--_on-ctr: var(--md-sys-color-on-error-container)}.box-fill{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.badge-fill{fill:var(--_role)}.sym{stroke:var(--_on);fill:var(--_on)}.sym.on-ctr{stroke:var(--_on-ctr);fill:var(--_on-ctr)}.sym path{fill:none}.disc{fill:var(--_role)}.rev-fill{fill:var(--_on)}.rev-stroke{stroke:var(--_on)}.role-stroke{stroke:var(--_role)}.ctr-fill{fill:var(--_ctr)}.tile{fill:var(--_role)}.tile-ink{stroke:var(--_on)}.tile-dot{fill:var(--_on)}.tinted .tile{fill:var(--_ctr)}.tinted .tile-ink{stroke:var(--_on-ctr)}.tinted .tile-dot{fill:var(--_on-ctr)}.track{stroke:var(--md-sys-color-primary-container)}.arc{stroke:var(--md-sys-color-logo-box)}.pen{fill:var(--md-sys-color-ai)}.orbit{transform-origin:50px 50px;animation:ait-orbit 1.4s linear infinite}@keyframes ait-orbit{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orbit{animation:none}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitStateMark, decorators: [{
            type: Component,
            args: [{ selector: 'ait-state-mark', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ait-state-mark',
                        '[class]': '"ait-sm-" + state()',
                        '[attr.role]': 'label() ? "img" : null',
                        '[attr.aria-label]': 'label() || null',
                        '[attr.aria-hidden]': 'label() ? null : "true"',
                        '[style.height.px]': 'resolvedSize()',
                    }, template: `
    @switch (shape()) {
      @case ('badge') {
        <svg viewBox="0 0 74 64" [attr.height]="resolvedSize()" [attr.width]="resolvedSize() * 74 / 64" focusable="false">
          <mask [attr.id]="uid + '-m'" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64">
            <rect width="74" height="64" fill="#fff" /><rect x="44.5" y="0.5" width="29" height="29" rx="8.5" fill="#000" />
          </mask>
          <g [attr.mask]="'url(#' + uid + '-m)'">
            <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
            <rect x="4" y="22" width="56" height="36" rx="10" class="box-fill" />
            <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
          </g>
          <rect x="47" y="3" width="24" height="24" rx="6" class="badge-fill" />
          <ng-container *ngTemplateOutlet="badgeSymbol" />
        </svg>
      }
      @case ('circle') {
        <svg viewBox="0 0 100 100" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false">
          <circle cx="50" cy="50" r="48" class="disc" />
          <g transform="translate(17.62 22) scale(0.875)">
            <mask [attr.id]="uid + '-m'" maskUnits="userSpaceOnUse" x="0" y="0" width="74" height="64">
              <rect width="74" height="64" fill="#fff" /><rect x="44.5" y="0.5" width="29" height="29" rx="8.5" fill="#000" />
            </mask>
            <g [attr.mask]="'url(#' + uid + '-m)'">
              <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="rev-stroke" stroke-width="6" stroke-linecap="round" />
              <rect x="4" y="22" width="56" height="36" rx="10" class="rev-fill" />
              <path d="M17.5 33l8 7-8 7" fill="none" class="role-stroke" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M33.5 47h13" fill="none" class="role-stroke" stroke-width="5.5" stroke-linecap="round" />
            </g>
            <rect x="47" y="3" width="24" height="24" rx="6" class="ctr-fill" />
            <ng-container *ngTemplateOutlet="badgeSymbol; context: { $implicit: 'on-ctr' }" />
          </g>
        </svg>
      }
      @case ('pending') {
        <svg viewBox="0 0 100 100" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false" class="ait-motion">
          <circle cx="50" cy="50" r="48" fill="none" class="track" stroke-width="4" />
          <g class="orbit">
            <circle cx="50" cy="50" r="48" fill="none" class="arc" stroke-width="4" stroke-linecap="round" stroke-dasharray="156.8 144.8" transform="rotate(-90 50 50)" />
            <circle cx="43.98" cy="97.62" r="4" class="pen" />
          </g>
          <g transform="translate(22 22) scale(0.875)">
            <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
            <rect x="4" y="22" width="56" height="36" rx="10" class="box-fill" />
            <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
            <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
          </g>
        </svg>
      }
      @default {
        <svg viewBox="0 0 64 64" [attr.height]="resolvedSize()" [attr.width]="resolvedSize()" focusable="false" [class.tinted]="shape() === 'tinted'">
          <rect width="64" height="64" rx="14" class="tile" />
          <path d="M17 23l10 9-10 9" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" />
          @switch (state()) {
            @case ('success') { <path d="M35 33l5 5 10-10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" /> }
            @case ('info') { <path d="M42 31v10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /><circle cx="42" cy="21" r="4" class="tile-dot" /> }
            @case ('warning') { <path d="M42 23v10" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /><circle cx="42" cy="43" r="4" class="tile-dot" /> }
            @case ('error') { <path d="M35 25l14 14M49 25L35 39" fill="none" class="tile-ink" stroke-width="7" stroke-linecap="round" /> }
          }
        </svg>
      }
    }

    <ng-template #badgeSymbol let-ink>
      <svg:g [attr.class]="ink === 'on-ctr' ? 'sym on-ctr' : 'sym'">
        @switch (state()) {
          @case ('success') { <svg:path d="M52 15.5l4.5 4.5 9.5-9.5" fill="none" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round" /> }
          @case ('info') { <svg:path d="M59 13.5v7.5" fill="none" stroke-width="3.5" stroke-linecap="round" /><svg:circle cx="59" cy="8.5" r="2.2" /> }
          @case ('warning') { <svg:path d="M59 8v7.5" fill="none" stroke-width="3.5" stroke-linecap="round" /><svg:circle cx="59" cy="21" r="2.2" /> }
          @case ('error') { <svg:path d="M54 10l10 10M64 10L54 20" fill="none" stroke-width="3.5" stroke-linecap="round" /> }
        }
      </svg:g>
    </ng-template>
  `, imports: [NgTemplateOutlet], styles: [":host{display:inline-flex;flex:none;line-height:0;vertical-align:middle}:host(.ait-sm-success){--_role: var(--md-sys-color-success);--_on: var(--md-sys-color-on-success);--_ctr: var(--md-sys-color-success-container);--_on-ctr: var(--md-sys-color-on-success-container)}:host(.ait-sm-info){--_role: var(--md-sys-color-primary);--_on: var(--md-sys-color-on-primary);--_ctr: var(--md-sys-color-primary-container);--_on-ctr: var(--md-sys-color-on-primary-container)}:host(.ait-sm-warning){--_role: var(--md-sys-color-warning);--_on: var(--md-sys-color-on-warning);--_ctr: var(--md-sys-color-warning-container);--_on-ctr: var(--md-sys-color-on-warning-container)}:host(.ait-sm-error){--_role: var(--md-sys-color-error);--_on: var(--md-sys-color-on-error);--_ctr: var(--md-sys-color-error-container);--_on-ctr: var(--md-sys-color-on-error-container)}.box-fill{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.badge-fill{fill:var(--_role)}.sym{stroke:var(--_on);fill:var(--_on)}.sym.on-ctr{stroke:var(--_on-ctr);fill:var(--_on-ctr)}.sym path{fill:none}.disc{fill:var(--_role)}.rev-fill{fill:var(--_on)}.rev-stroke{stroke:var(--_on)}.role-stroke{stroke:var(--_role)}.ctr-fill{fill:var(--_ctr)}.tile{fill:var(--_role)}.tile-ink{stroke:var(--_on)}.tile-dot{fill:var(--_on)}.tinted .tile{fill:var(--_ctr)}.tinted .tile-ink{stroke:var(--_on-ctr)}.tinted .tile-dot{fill:var(--_on-ctr)}.track{stroke:var(--md-sys-color-primary-container)}.arc{stroke:var(--md-sys-color-logo-box)}.pen{fill:var(--md-sys-color-ai)}.orbit{transform-origin:50px 50px;animation:ait-orbit 1.4s linear infinite}@keyframes ait-orbit{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.orbit{animation:none}}\n"] }]
        }], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: true }] }], variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * StatusChip — health on a `*-container` fill, led by the 18 px tinted tile glyph, never colour alone.
 * Built on `mat-chip` with the `dt-chip-*` classes of the theme files; not interactive.
 *
 * ```html
 * <ait-status-chip state="success">Healthy</ait-status-chip>
 * <ait-status-chip state="unknown">No data</ait-status-chip>
 * ```
 */
class AitStatusChip {
    /** success · warning · error · info, or unknown (outline dot on surface-container-highest). */
    state = input.required(...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    chipClass = computed(() => `ait-sc dt-chip-${this.state()}`, ...(ngDevMode ? [{ debugName: "chipClass" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitStatusChip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitStatusChip, isStandalone: true, selector: "ait-status-chip", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "ait-status-chip" }, ngImport: i0, template: `
    <mat-chip [class]="chipClass()" [disableRipple]="true" [highlighted]="false">
      @if (state() === 'unknown') {
        <span matChipAvatar class="ait-status-chip__dot" aria-hidden="true"></span>
      } @else {
        <ait-state-mark matChipAvatar [state]="$any(state())" variant="tinted" [size]="18" />
      }
      <ng-content />
    </mat-chip>
  `, isInline: true, styles: [":host{display:inline-flex;vertical-align:middle}:host .mat-mdc-standard-chip.ait-sc{--mat-chip-container-height: 24px;--mat-chip-container-shape-radius: 4px;--mat-chip-with-avatar-avatar-size: 18px;--mat-chip-with-avatar-avatar-shape-radius: 4px;--mat-chip-label-text-font: var(--ait-font-ui);--mat-chip-label-text-size: 12px;--mat-chip-label-text-weight: 500;--mat-chip-label-text-tracking: .5px;--mat-chip-outline-width: 0;--mat-chip-elevated-container-color: var(--_ctr);--mat-chip-label-text-color: var(--_on-ctr);--mat-chip-elevated-disabled-container-color: var(--_ctr);cursor:default}:host .ait-sc.dt-chip-success{--_ctr: var(--md-sys-color-success-container);--_on-ctr: var(--md-sys-color-on-success-container)}:host .ait-sc.dt-chip-warning{--_ctr: var(--md-sys-color-warning-container);--_on-ctr: var(--md-sys-color-on-warning-container)}:host .ait-sc.dt-chip-error{--_ctr: var(--md-sys-color-error-container);--_on-ctr: var(--md-sys-color-on-error-container)}:host .ait-sc.dt-chip-info{--_ctr: var(--md-sys-color-primary-container);--_on-ctr: var(--md-sys-color-on-primary-container)}:host .ait-sc.dt-chip-unknown{--_ctr: var(--md-sys-color-surface-container-highest);--_on-ctr: var(--md-sys-color-on-surface-variant)}.ait-status-chip__dot{width:6px!important;height:6px!important;border-radius:9999px;background:var(--md-sys-color-outline);margin:0 4px 0 6px}\n"], dependencies: [{ kind: "component", type: MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: MatChipAvatar, selector: "mat-chip-avatar, [matChipAvatar]" }, { kind: "component", type: AitStateMark, selector: "ait-state-mark", inputs: ["state", "variant", "size", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitStatusChip, decorators: [{
            type: Component,
            args: [{ selector: 'ait-status-chip', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatChip, MatChipAvatar, AitStateMark], host: { class: 'ait-status-chip' }, template: `
    <mat-chip [class]="chipClass()" [disableRipple]="true" [highlighted]="false">
      @if (state() === 'unknown') {
        <span matChipAvatar class="ait-status-chip__dot" aria-hidden="true"></span>
      } @else {
        <ait-state-mark matChipAvatar [state]="$any(state())" variant="tinted" [size]="18" />
      }
      <ng-content />
    </mat-chip>
  `, styles: [":host{display:inline-flex;vertical-align:middle}:host .mat-mdc-standard-chip.ait-sc{--mat-chip-container-height: 24px;--mat-chip-container-shape-radius: 4px;--mat-chip-with-avatar-avatar-size: 18px;--mat-chip-with-avatar-avatar-shape-radius: 4px;--mat-chip-label-text-font: var(--ait-font-ui);--mat-chip-label-text-size: 12px;--mat-chip-label-text-weight: 500;--mat-chip-label-text-tracking: .5px;--mat-chip-outline-width: 0;--mat-chip-elevated-container-color: var(--_ctr);--mat-chip-label-text-color: var(--_on-ctr);--mat-chip-elevated-disabled-container-color: var(--_ctr);cursor:default}:host .ait-sc.dt-chip-success{--_ctr: var(--md-sys-color-success-container);--_on-ctr: var(--md-sys-color-on-success-container)}:host .ait-sc.dt-chip-warning{--_ctr: var(--md-sys-color-warning-container);--_on-ctr: var(--md-sys-color-on-warning-container)}:host .ait-sc.dt-chip-error{--_ctr: var(--md-sys-color-error-container);--_on-ctr: var(--md-sys-color-on-error-container)}:host .ait-sc.dt-chip-info{--_ctr: var(--md-sys-color-primary-container);--_on-ctr: var(--md-sys-color-on-primary-container)}:host .ait-sc.dt-chip-unknown{--_ctr: var(--md-sys-color-surface-container-highest);--_on-ctr: var(--md-sys-color-on-surface-variant)}.ait-status-chip__dot{width:6px!important;height:6px!important;border-radius:9999px;background:var(--md-sys-color-outline);margin:0 4px 0 6px}\n"] }]
        }], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: true }] }] } });
/** Log level word in a Trace or log view: only the word is coloured (Open Sans 600). */
class AitLogLevel {
    level = input.required(...(ngDevMode ? [{ debugName: "level" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitLogLevel, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: AitLogLevel, isStandalone: true, selector: "ait-log-level", inputs: { level: { classPropertyName: "level", publicName: "level", isSignal: true, isRequired: true, transformFunction: null } }, host: { properties: { "class": "\"ait-log-level ait-log-level--\" + level()" } }, ngImport: i0, template: `{{ level() }}`, isInline: true, styles: [":host{font-family:var(--ait-font-body);font-weight:600;font-size:12px;line-height:16px;letter-spacing:.4px}:host(.ait-log-level--INFO){color:var(--md-sys-color-success)}:host(.ait-log-level--WARN){color:var(--md-sys-color-warning)}:host(.ait-log-level--ERR){color:var(--md-sys-color-error)}:host(.ait-log-level--DEBUG){color:var(--md-sys-color-on-surface-variant)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitLogLevel, decorators: [{
            type: Component,
            args: [{ selector: 'ait-log-level', changeDetection: ChangeDetectionStrategy.OnPush, host: { '[class]': '"ait-log-level ait-log-level--" + level()' }, template: `{{ level() }}`, styles: [":host{font-family:var(--ait-font-body);font-weight:600;font-size:12px;line-height:16px;letter-spacing:.4px}:host(.ait-log-level--INFO){color:var(--md-sys-color-success)}:host(.ait-log-level--WARN){color:var(--md-sys-color-warning)}:host(.ait-log-level--ERR){color:var(--md-sys-color-error)}:host(.ait-log-level--DEBUG){color:var(--md-sys-color-on-surface-variant)}\n"] }]
        }], propDecorators: { level: [{ type: i0.Input, args: [{ isSignal: true, alias: "level", required: true }] }] } });

const clamp = (v) => Math.min(100, Math.max(0, v));
const optionalNumber = (v) => (v == null || v === '' ? undefined : numberAttribute(v));
/**
 * Pen orbit — the circular indicator of the Constructor family (skin of `mat-progress-spinner`): a violet arc with
 * the teal pen at its head on a faint primary-container track. 48 px in content, 24 px inline, 18 px inside a button.
 * Indeterminate by default; give `value` (0–100) for a determinate arc.
 */
class AitPenOrbit {
    /** 48 (content) · 24 (inline) · 18 (inside a button). */
    size = input(48, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** 0–100 for a determinate arc; leave unset for indeterminate. */
    value = input(undefined, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: optionalNumber });
    label = input('Loading', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    stroke = computed(() => (this.size() <= 24 ? 5 : 4), ...(ngDevMode ? [{ debugName: "stroke" }] : /* istanbul ignore next */ []));
    pen = computed(() => (this.size() <= 24 ? 4.5 : 3.6), ...(ngDevMode ? [{ debugName: "pen" }] : /* istanbul ignore next */ []));
    /** Arc length in degrees: 190° while indeterminate, the value otherwise. */
    sweep = computed(() => (this.value() == null ? 190 : (clamp(this.value()) / 100) * 360), ...(ngDevMode ? [{ debugName: "sweep" }] : /* istanbul ignore next */ []));
    headAngle = computed(() => this.sweep(), ...(ngDevMode ? [{ debugName: "headAngle" }] : /* istanbul ignore next */ []));
    dash = computed(() => {
        const c = 2 * Math.PI * 20;
        const len = (this.sweep() / 360) * c;
        return `${len} ${c}`;
    }, ...(ngDevMode ? [{ debugName: "dash" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitPenOrbit, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: AitPenOrbit, isStandalone: true, selector: "ait-pen-orbit", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "progressbar" }, properties: { "attr.aria-label": "label()", "attr.aria-valuenow": "value() ?? null", "attr.aria-valuemin": "value() == null ? null : 0", "attr.aria-valuemax": "value() == null ? null : 100", "style.width.px": "size()", "style.height.px": "size()" }, classAttribute: "ait-pen-orbit" }, ngImport: i0, template: `
    <svg viewBox="0 0 48 48" [attr.width]="size()" [attr.height]="size()" focusable="false" aria-hidden="true">
      <circle cx="24" cy="24" r="20" fill="none" class="track" [attr.stroke-width]="stroke()" />
      <g [class.spin]="value() == null" [attr.transform]="value() == null ? null : 'rotate(' + (headAngle() - 90) + ' 24 24)'">
        <circle cx="24" cy="24" r="20" fill="none" class="arc" [attr.stroke-width]="stroke()" stroke-linecap="round"
          [attr.stroke-dasharray]="dash()" [attr.transform]="'rotate(' + (-headAngle()) + ' 24 24)'" />
        <circle cx="44" cy="24" [attr.r]="pen()" class="pen" />
      </g>
    </svg>
  `, isInline: true, styles: [":host{display:inline-flex;flex:none;vertical-align:middle}.track{stroke:var(--md-sys-color-primary-container)}.arc{stroke:var(--md-sys-color-primary)}.pen{fill:var(--md-sys-color-ai-strong)}.spin{transform-origin:24px 24px;animation:ait-po 1.4s linear infinite}@keyframes ait-po{0%{transform:rotate(-90deg)}to{transform:rotate(270deg)}}@media(prefers-reduced-motion:reduce){.spin{animation:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitPenOrbit, decorators: [{
            type: Component,
            args: [{ selector: 'ait-pen-orbit', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ait-pen-orbit',
                        role: 'progressbar',
                        '[attr.aria-label]': 'label()',
                        '[attr.aria-valuenow]': 'value() ?? null',
                        '[attr.aria-valuemin]': 'value() == null ? null : 0',
                        '[attr.aria-valuemax]': 'value() == null ? null : 100',
                        '[style.width.px]': 'size()',
                        '[style.height.px]': 'size()',
                    }, template: `
    <svg viewBox="0 0 48 48" [attr.width]="size()" [attr.height]="size()" focusable="false" aria-hidden="true">
      <circle cx="24" cy="24" r="20" fill="none" class="track" [attr.stroke-width]="stroke()" />
      <g [class.spin]="value() == null" [attr.transform]="value() == null ? null : 'rotate(' + (headAngle() - 90) + ' 24 24)'">
        <circle cx="24" cy="24" r="20" fill="none" class="arc" [attr.stroke-width]="stroke()" stroke-linecap="round"
          [attr.stroke-dasharray]="dash()" [attr.transform]="'rotate(' + (-headAngle()) + ' 24 24)'" />
        <circle cx="44" cy="24" [attr.r]="pen()" class="pen" />
      </g>
    </svg>
  `, styles: [":host{display:inline-flex;flex:none;vertical-align:middle}.track{stroke:var(--md-sys-color-primary-container)}.arc{stroke:var(--md-sys-color-primary)}.pen{fill:var(--md-sys-color-ai-strong)}.spin{transform-origin:24px 24px;animation:ait-po 1.4s linear infinite}@keyframes ait-po{0%{transform:rotate(-90deg)}to{transform:rotate(270deg)}}@media(prefers-reduced-motion:reduce){.spin{animation:none}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
/**
 * Guide line — the linear indicator (skin of `mat-progress-bar`): a dashed teal construction guide, the violet bar
 * runs along it with the pen on its leading edge. Indeterminate by default; `value` (0–100) for determinate.
 */
class AitGuideLine {
    value = input(undefined, { ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: optionalNumber });
    label = input('Loading', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    clamped = computed(() => clamp(this.value() ?? 0), ...(ngDevMode ? [{ debugName: "clamped" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitGuideLine, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: AitGuideLine, isStandalone: true, selector: "ait-guide-line", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "progressbar" }, properties: { "attr.aria-label": "label()", "attr.aria-valuenow": "value() ?? null", "attr.aria-valuemin": "value() == null ? null : 0", "attr.aria-valuemax": "value() == null ? null : 100", "class.ait-guide-line--indeterminate": "value() == null" }, classAttribute: "ait-guide-line" }, ngImport: i0, template: `
    <span class="guide"></span>
    <span class="bar" [style.width.%]="value() == null ? 30 : clamped()"><span class="pen"></span></span>
  `, isInline: true, styles: [":host{position:relative;display:block;height:8px;overflow:hidden}.guide{position:absolute;left:0;right:0;top:3.25px;height:1.5px;opacity:.7;background:repeating-linear-gradient(90deg,var(--md-sys-color-ai-strong) 0 2px,transparent 2px 5px)}.bar{position:absolute;left:0;top:2px;height:4px;border-radius:2px;background:var(--md-sys-color-primary);transition:width .3s cubic-bezier(.2,0,0,1)}.pen{position:absolute;right:-3.5px;top:-1.5px;width:7px;height:7px;border-radius:9999px;background:var(--md-sys-color-ai-strong)}:host(.ait-guide-line--indeterminate) .bar{animation:ait-gl 1.8s cubic-bezier(.2,0,0,1) infinite}@keyframes ait-gl{0%{transform:translate(-100%)}to{transform:translate(350%)}}@media(prefers-reduced-motion:reduce){:host(.ait-guide-line--indeterminate) .bar{animation:none}.bar{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitGuideLine, decorators: [{
            type: Component,
            args: [{ selector: 'ait-guide-line', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ait-guide-line',
                        role: 'progressbar',
                        '[attr.aria-label]': 'label()',
                        '[attr.aria-valuenow]': 'value() ?? null',
                        '[attr.aria-valuemin]': 'value() == null ? null : 0',
                        '[attr.aria-valuemax]': 'value() == null ? null : 100',
                        '[class.ait-guide-line--indeterminate]': 'value() == null',
                    }, template: `
    <span class="guide"></span>
    <span class="bar" [style.width.%]="value() == null ? 30 : clamped()"><span class="pen"></span></span>
  `, styles: [":host{position:relative;display:block;height:8px;overflow:hidden}.guide{position:absolute;left:0;right:0;top:3.25px;height:1.5px;opacity:.7;background:repeating-linear-gradient(90deg,var(--md-sys-color-ai-strong) 0 2px,transparent 2px 5px)}.bar{position:absolute;left:0;top:2px;height:4px;border-radius:2px;background:var(--md-sys-color-primary);transition:width .3s cubic-bezier(.2,0,0,1)}.pen{position:absolute;right:-3.5px;top:-1.5px;width:7px;height:7px;border-radius:9999px;background:var(--md-sys-color-ai-strong)}:host(.ait-guide-line--indeterminate) .bar{animation:ait-gl 1.8s cubic-bezier(.2,0,0,1) infinite}@keyframes ait-gl{0%{transform:translate(-100%)}to{transform:translate(350%)}}@media(prefers-reduced-motion:reduce){:host(.ait-guide-line--indeterminate) .bar{animation:none}.bar{transition:none}}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
/**
 * Working dots — three dots on a 1.4 s rhythm. The colour says who works: `run` (green, a command executes) or
 * `ai` (teal, a model is thinking). Inline after a log line or a chat message.
 */
class AitWorkingDots {
    kind = input('run', ...(ngDevMode ? [{ debugName: "kind" }] : /* istanbul ignore next */ []));
    label = input('Working', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitWorkingDots, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: AitWorkingDots, isStandalone: true, selector: "ait-working-dots", inputs: { kind: { classPropertyName: "kind", publicName: "kind", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img" }, properties: { "attr.aria-label": "label()", "class.ait-working-dots--ai": "kind() === \"ai\"" }, classAttribute: "ait-working-dots" }, ngImport: i0, template: `<span></span><span></span><span></span>`, isInline: true, styles: [":host{display:inline-flex;align-items:center;gap:3px;height:8px;vertical-align:middle;--_dot: var(--md-sys-color-tertiary)}:host(.ait-working-dots--ai){--_dot: var(--md-sys-color-ai-strong)}span{width:6px;height:6px;border-radius:9999px;background:var(--_dot);animation:ait-dot 1.4s ease-in-out infinite}span:nth-child(2){animation-delay:.16s}span:nth-child(3){animation-delay:.32s}@keyframes ait-dot{0%,80%,to{transform:scale(.6);opacity:.4}40%{transform:scale(1);opacity:1}}@media(prefers-reduced-motion:reduce){span{animation:none;opacity:1;transform:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitWorkingDots, decorators: [{
            type: Component,
            args: [{ selector: 'ait-working-dots', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ait-working-dots', role: 'img', '[attr.aria-label]': 'label()', '[class.ait-working-dots--ai]': 'kind() === "ai"' }, template: `<span></span><span></span><span></span>`, styles: [":host{display:inline-flex;align-items:center;gap:3px;height:8px;vertical-align:middle;--_dot: var(--md-sys-color-tertiary)}:host(.ait-working-dots--ai){--_dot: var(--md-sys-color-ai-strong)}span{width:6px;height:6px;border-radius:9999px;background:var(--_dot);animation:ait-dot 1.4s ease-in-out infinite}span:nth-child(2){animation-delay:.16s}span:nth-child(3){animation-delay:.32s}@keyframes ait-dot{0%,80%,to{transform:scale(.6);opacity:.4}40%{transform:scale(1);opacity:1}}@media(prefers-reduced-motion:reduce){span{animation:none;opacity:1;transform:none}}\n"] }]
        }], propDecorators: { kind: [{ type: i0.Input, args: [{ isSignal: true, alias: "kind", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
/**
 * Constructor determinate — long operations with a known value (install, deploy, migration): the pen draws the box in
 * proportion to progress and at 100 % the toolbox fills. 64–96 px in dialogs and empty states.
 */
class AitConstructorProgress {
    value = input.required({ ...(ngDevMode ? { debugName: "value" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** Height in px, 64–96. */
    size = input(72, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    label = input('Progress', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    clamped = computed(() => Math.round(clamp(this.value())), ...(ngDevMode ? [{ debugName: "clamped" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConstructorProgress, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitConstructorProgress, isStandalone: true, selector: "ait-constructor-progress", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "progressbar", "aria-valuemin": "0", "aria-valuemax": "100" }, properties: { "attr.aria-valuenow": "clamped()", "attr.aria-label": "label()" }, classAttribute: "ait-constructor-progress" }, ngImport: i0, template: `
    <svg viewBox="-4 2 76 64" [attr.height]="size()" [attr.width]="size() * 76 / 64" focusable="false" aria-hidden="true" [class.done]="clamped() >= 100">
      <rect x="4" y="22" width="56" height="36" rx="10" fill="none" class="guide" stroke-width="1" stroke-dasharray="2 2" opacity=".45" />
      <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="guide" stroke-width="1" stroke-dasharray="2 2" opacity=".6" />
      <g class="solid">
        <rect x="4" y="22" width="56" height="36" rx="10" class="box" />
        <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
        <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
      </g>
      <path class="line" pathLength="100" stroke-dasharray="100" [attr.stroke-dashoffset]="100 - clamped()"
        d="M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44"
        fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      <circle class="pen" r="2.6" [style.offset-distance.%]="clamped()" />
      @if (clamped() < 100) {
        <text x="32" y="43" text-anchor="middle" class="pct">{{ clamped() }}%</text>
      }
    </svg>
  `, isInline: true, styles: [":host{display:inline-flex;flex:none}svg{overflow:visible}.guide,.line{stroke:var(--md-sys-color-ai-strong)}.pen{fill:var(--md-sys-color-ai-strong);offset-path:path(\"M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44\");offset-rotate:0deg}.solid{opacity:0;transition:opacity .3s}.box{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.done .solid{opacity:1}.done .pen,.done .line{opacity:0}.pct{font-family:var(--ait-font-body);font-weight:600;font-size:11px;fill:var(--md-sys-color-ai-strong)}@media(prefers-reduced-motion:reduce){.solid{transition:none}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConstructorProgress, decorators: [{
            type: Component,
            args: [{ selector: 'ait-constructor-progress', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ait-constructor-progress',
                        role: 'progressbar',
                        'aria-valuemin': '0',
                        'aria-valuemax': '100',
                        '[attr.aria-valuenow]': 'clamped()',
                        '[attr.aria-label]': 'label()',
                    }, template: `
    <svg viewBox="-4 2 76 64" [attr.height]="size()" [attr.width]="size() * 76 / 64" focusable="false" aria-hidden="true" [class.done]="clamped() >= 100">
      <rect x="4" y="22" width="56" height="36" rx="10" fill="none" class="guide" stroke-width="1" stroke-dasharray="2 2" opacity=".45" />
      <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="guide" stroke-width="1" stroke-dasharray="2 2" opacity=".6" />
      <g class="solid">
        <rect x="4" y="22" width="56" height="36" rx="10" class="box" />
        <path d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" class="box-stroke" stroke-width="6" stroke-linecap="round" />
        <path d="M17.5 33l8 7-8 7" fill="none" class="chev" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M33.5 47h13" fill="none" class="cursor" stroke-width="5.5" stroke-linecap="round" />
      </g>
      <path class="line" pathLength="100" stroke-dasharray="100" [attr.stroke-dashoffset]="100 - clamped()"
        d="M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44"
        fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
      <circle class="pen" r="2.6" [style.offset-distance.%]="clamped()" />
      @if (clamped() < 100) {
        <text x="32" y="43" text-anchor="middle" class="pct">{{ clamped() }}%</text>
      }
    </svg>
  `, styles: [":host{display:inline-flex;flex:none}svg{overflow:visible}.guide,.line{stroke:var(--md-sys-color-ai-strong)}.pen{fill:var(--md-sys-color-ai-strong);offset-path:path(\"M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44\");offset-rotate:0deg}.solid{opacity:0;transition:opacity .3s}.box{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.done .solid{opacity:1}.done .pen,.done .line{opacity:0}.pct{font-family:var(--ait-font-body);font-weight:600;font-size:11px;fill:var(--md-sys-color-ai-strong)}@media(prefers-reduced-motion:reduce){.solid{transition:none}}\n"] }]
        }], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: true }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Brand loader "Constructor" — app-level waits only (boot, workspace switch), never inside a screen. The AI tag comes
 * in, construction guides appear, a teal pen draws the toolbox in one trip and the night box becomes solid; 4.8 s loop.
 * `once` plays one time and stays on the logo (splash). 96 px for splash and workspace boot, 40 px minimum.
 * Under reduced motion it shows the finished logo; the label carries the state.
 */
class AitBrandLoader {
    /** Height in px: 96 for splash and workspace boot, 40 minimum. */
    size = input(96, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** Play one time and stay on the logo. */
    once = input(false, { ...(ngDevMode ? { debugName: "once" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    /** Visible label under the loader, e.g. "Preparing your toolbox…". */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    uid = aitUid('ait-ldr');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitBrandLoader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitBrandLoader, isStandalone: true, selector: "ait-brand-loader", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, once: { classPropertyName: "once", publicName: "once", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status" }, classAttribute: "ait-brand-loader" }, ngImport: i0, template: `
    <svg class="ait-loader" [class.ait-once]="once()" viewBox="-4 2 76 64" [attr.height]="size()" [attr.width]="size() * 76 / 64" focusable="false" aria-hidden="true">
      <defs>
        <mask [attr.id]="uid + '-hole'" maskUnits="userSpaceOnUse" x="-4" y="2" width="76" height="64">
          <rect x="-4" y="2" width="76" height="64" fill="#fff" /><rect x="37" y="3" width="36" height="24" rx="7" fill="#000" />
        </mask>
        <clipPath [attr.id]="uid + '-tag'"><rect x="39.5" y="5.5" width="31" height="19" rx="5" /></clipPath>
      </defs>
      <g class="o guide ai-stroke" opacity="0" fill="none">
        <rect x="4" y="22" width="56" height="36" stroke-width=".8" stroke-dasharray="2 2" />
        <path d="M-2 22h62M-2 58h62M4 16v48M60 16v48M21 11h22M21 11v12M43 11v12" stroke-width=".8" stroke-dasharray="2 2" />
        <path d="M4 20v4M60 20v4M2 22h4M2 58h4" stroke-width="1.2" />
      </g>
      <g [attr.mask]="'url(#' + uid + '-hole)'">
        <rect class="fill box" x="4" y="22" width="56" height="36" rx="10" />
        <path class="fill box-stroke" d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" stroke-width="6" stroke-linecap="round" />
        <path class="fill chev" d="M17.5 33l8 7-8 7" fill="none" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
        <path class="blink cursor" d="M33.5 47h13" fill="none" stroke-width="5.5" stroke-linecap="round" />
      </g>
      <path class="o ln-box ai-stroke" pathLength="100" stroke-dasharray="100" d="M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-handle ai-stroke" pathLength="100" stroke-dasharray="100" d="M43 23v-6a6 6 0 0 0-6-6H27a6 6 0 0 0-6 6v6" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-chev ai-stroke" pathLength="100" stroke-dasharray="100" d="M17.5 33l8 7-8 7" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-cur ai-stroke" pathLength="100" stroke-dasharray="100" d="M33.5 47h13" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <circle class="pen ai-fill" r="2.6" />
      <g class="badge-in"><g class="badge-pulse">
        <rect class="ai-fill" x="39.5" y="5.5" width="31" height="19" rx="5" />
        <g [attr.clip-path]="'url(#' + uid + '-tag)'">
          <g class="la"><path class="on-ai" d="M48.567 20.04 51.647 9.96H54.489L57.569 20.04H55.609L54.958 17.94H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.703 16.162Z" /></g>
          <g class="li"><path class="on-ai" d="M58.689 20.04V9.96H60.593V20.04Z" /></g>
          <g class="sheen" opacity="0"><rect x="34" y="2" width="6" height="28" fill="#FFFFFF" transform="skewX(-20)" /></g>
        </g>
      </g></g>
    </svg>
    @if (label()) {
      <span class="label">{{ label() }}</span>
    } @else {
      <span class="ait-visually-hidden">Loading</span>
    }
  `, isInline: true, styles: [":host{display:inline-flex;flex-direction:column;align-items:center;gap:12px}.label{font:var(--ait-type-title-small);letter-spacing:.1px;color:var(--md-sys-color-on-surface-variant)}.box{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.ai-stroke{stroke:var(--md-sys-color-ai)}.ai-fill{fill:var(--md-sys-color-ai)}.on-ai{fill:var(--md-sys-color-on-ai)}@keyframes badge-in{0%{transform:scale(0);opacity:0}4%{transform:scale(1.12);opacity:1}6.5%{transform:scale(.96);opacity:1}8%,to{transform:scale(1);opacity:1}}@keyframes la{0%,6%{transform:translateY(8px);opacity:0}10%{transform:translateY(-1px);opacity:1}11.5%,to{transform:translateY(0);opacity:1}}@keyframes li{0%,8.5%{transform:translateY(8px);opacity:0}12.5%{transform:translateY(-1px);opacity:1}14%,to{transform:translateY(0);opacity:1}}@keyframes sheen{0%,14%{transform:translate(0);opacity:0}14.5%{opacity:.6}18.5%{transform:translate(40px);opacity:.6}19%,to{transform:translate(40px);opacity:0}}@keyframes badge-pulse{0%,68%{transform:scale(1)}71%{transform:scale(1.08)}75%,to{transform:scale(1)}}@keyframes pen{0%,18%{offset-distance:0%;opacity:0}18.5%{opacity:1}65.5%{opacity:1}66%,to{offset-distance:100%;opacity:0}}@keyframes ln-box{0%,19.77%{stroke-dashoffset:100;opacity:0}19.87%{opacity:1}46%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-handle{0%,46.23%{stroke-dashoffset:100;opacity:0}46.33%{opacity:1}52.65%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-chev{0%,54.32%{stroke-dashoffset:100;opacity:0}54.42%{opacity:1}57.66%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-cur{0%,60.17%{stroke-dashoffset:100;opacity:0}60.27%{opacity:1}62.22%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes fill{0%,68%{opacity:0}73%,to{opacity:1}}@keyframes blink{0%,73%{opacity:0}75%{opacity:1}81%{opacity:0}85%{opacity:1}91%{opacity:0}93%,to{opacity:1}}@keyframes guide{0%,14%{opacity:0}18%,64%{opacity:.55}69%,to{opacity:0}}.badge-in{transform-origin:55px 15px;animation:badge-in 4.8s cubic-bezier(.34,1.4,.64,1) infinite}.badge-pulse{transform-origin:55px 15px;animation:badge-pulse 4.8s cubic-bezier(.2,0,0,1) infinite}.la{animation:la 4.8s cubic-bezier(.2,0,0,1) infinite}.li{animation:li 4.8s cubic-bezier(.2,0,0,1) infinite}.sheen{animation:sheen 4.8s cubic-bezier(.2,0,0,1) infinite}.pen{offset-path:path(\"M55 24.5L44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44L43 23v-6a6 6 0 0 0-6-6H27a6 6 0 0 0-6 6v6L17.5 33l8 7-8 7L33.5 47h13L55 24.5\");offset-rotate:0deg;animation:pen 4.8s linear infinite}.ln-box{animation:ln-box 4.8s linear infinite}.ln-handle{animation:ln-handle 4.8s linear infinite}.ln-chev{animation:ln-chev 4.8s linear infinite}.ln-cur{animation:ln-cur 4.8s linear infinite}.fill{animation:fill 4.8s linear infinite}.blink{animation:blink 4.8s linear infinite}.guide{animation:guide 4.8s linear infinite}.ait-once *{animation-iteration-count:1!important;animation-fill-mode:forwards!important}@media(prefers-reduced-motion:reduce){.ait-loader *{animation:none!important}.o,.pen{opacity:0}.fill,.blink{opacity:1}.badge-in{transform:none;opacity:1}.sheen{opacity:0}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitBrandLoader, decorators: [{
            type: Component,
            args: [{ selector: 'ait-brand-loader', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ait-brand-loader', role: 'status' }, template: `
    <svg class="ait-loader" [class.ait-once]="once()" viewBox="-4 2 76 64" [attr.height]="size()" [attr.width]="size() * 76 / 64" focusable="false" aria-hidden="true">
      <defs>
        <mask [attr.id]="uid + '-hole'" maskUnits="userSpaceOnUse" x="-4" y="2" width="76" height="64">
          <rect x="-4" y="2" width="76" height="64" fill="#fff" /><rect x="37" y="3" width="36" height="24" rx="7" fill="#000" />
        </mask>
        <clipPath [attr.id]="uid + '-tag'"><rect x="39.5" y="5.5" width="31" height="19" rx="5" /></clipPath>
      </defs>
      <g class="o guide ai-stroke" opacity="0" fill="none">
        <rect x="4" y="22" width="56" height="36" stroke-width=".8" stroke-dasharray="2 2" />
        <path d="M-2 22h62M-2 58h62M4 16v48M60 16v48M21 11h22M21 11v12M43 11v12" stroke-width=".8" stroke-dasharray="2 2" />
        <path d="M4 20v4M60 20v4M2 22h4M2 58h4" stroke-width="1.2" />
      </g>
      <g [attr.mask]="'url(#' + uid + '-hole)'">
        <rect class="fill box" x="4" y="22" width="56" height="36" rx="10" />
        <path class="fill box-stroke" d="M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6" fill="none" stroke-width="6" stroke-linecap="round" />
        <path class="fill chev" d="M17.5 33l8 7-8 7" fill="none" stroke-width="5.5" stroke-linecap="round" stroke-linejoin="round" />
        <path class="blink cursor" d="M33.5 47h13" fill="none" stroke-width="5.5" stroke-linecap="round" />
      </g>
      <path class="o ln-box ai-stroke" pathLength="100" stroke-dasharray="100" d="M44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-handle ai-stroke" pathLength="100" stroke-dasharray="100" d="M43 23v-6a6 6 0 0 0-6-6H27a6 6 0 0 0-6 6v6" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-chev ai-stroke" pathLength="100" stroke-dasharray="100" d="M17.5 33l8 7-8 7" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <path class="o ln-cur ai-stroke" pathLength="100" stroke-dasharray="100" d="M33.5 47h13" fill="none" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
      <circle class="pen ai-fill" r="2.6" />
      <g class="badge-in"><g class="badge-pulse">
        <rect class="ai-fill" x="39.5" y="5.5" width="31" height="19" rx="5" />
        <g [attr.clip-path]="'url(#' + uid + '-tag)'">
          <g class="la"><path class="on-ai" d="M48.567 20.04 51.647 9.96H54.489L57.569 20.04H55.609L54.958 17.94H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.703 16.162Z" /></g>
          <g class="li"><path class="on-ai" d="M58.689 20.04V9.96H60.593V20.04Z" /></g>
          <g class="sheen" opacity="0"><rect x="34" y="2" width="6" height="28" fill="#FFFFFF" transform="skewX(-20)" /></g>
        </g>
      </g></g>
    </svg>
    @if (label()) {
      <span class="label">{{ label() }}</span>
    } @else {
      <span class="ait-visually-hidden">Loading</span>
    }
  `, styles: [":host{display:inline-flex;flex-direction:column;align-items:center;gap:12px}.label{font:var(--ait-type-title-small);letter-spacing:.1px;color:var(--md-sys-color-on-surface-variant)}.box{fill:var(--md-sys-color-logo-box)}.box-stroke{stroke:var(--md-sys-color-logo-box)}.chev{stroke:var(--md-sys-color-on-logo-box)}.cursor{stroke:var(--md-sys-color-logo-cursor)}.ai-stroke{stroke:var(--md-sys-color-ai)}.ai-fill{fill:var(--md-sys-color-ai)}.on-ai{fill:var(--md-sys-color-on-ai)}@keyframes badge-in{0%{transform:scale(0);opacity:0}4%{transform:scale(1.12);opacity:1}6.5%{transform:scale(.96);opacity:1}8%,to{transform:scale(1);opacity:1}}@keyframes la{0%,6%{transform:translateY(8px);opacity:0}10%{transform:translateY(-1px);opacity:1}11.5%,to{transform:translateY(0);opacity:1}}@keyframes li{0%,8.5%{transform:translateY(8px);opacity:0}12.5%{transform:translateY(-1px);opacity:1}14%,to{transform:translateY(0);opacity:1}}@keyframes sheen{0%,14%{transform:translate(0);opacity:0}14.5%{opacity:.6}18.5%{transform:translate(40px);opacity:.6}19%,to{transform:translate(40px);opacity:0}}@keyframes badge-pulse{0%,68%{transform:scale(1)}71%{transform:scale(1.08)}75%,to{transform:scale(1)}}@keyframes pen{0%,18%{offset-distance:0%;opacity:0}18.5%{opacity:1}65.5%{opacity:1}66%,to{offset-distance:100%;opacity:0}}@keyframes ln-box{0%,19.77%{stroke-dashoffset:100;opacity:0}19.87%{opacity:1}46%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-handle{0%,46.23%{stroke-dashoffset:100;opacity:0}46.33%{opacity:1}52.65%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-chev{0%,54.32%{stroke-dashoffset:100;opacity:0}54.42%{opacity:1}57.66%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes ln-cur{0%,60.17%{stroke-dashoffset:100;opacity:0}60.27%{opacity:1}62.22%,68%{stroke-dashoffset:0;opacity:1}74%,to{stroke-dashoffset:0;opacity:0}}@keyframes fill{0%,68%{opacity:0}73%,to{opacity:1}}@keyframes blink{0%,73%{opacity:0}75%{opacity:1}81%{opacity:0}85%{opacity:1}91%{opacity:0}93%,to{opacity:1}}@keyframes guide{0%,14%{opacity:0}18%,64%{opacity:.55}69%,to{opacity:0}}.badge-in{transform-origin:55px 15px;animation:badge-in 4.8s cubic-bezier(.34,1.4,.64,1) infinite}.badge-pulse{transform-origin:55px 15px;animation:badge-pulse 4.8s cubic-bezier(.2,0,0,1) infinite}.la{animation:la 4.8s cubic-bezier(.2,0,0,1) infinite}.li{animation:li 4.8s cubic-bezier(.2,0,0,1) infinite}.sheen{animation:sheen 4.8s cubic-bezier(.2,0,0,1) infinite}.pen{offset-path:path(\"M55 24.5L44 22H14a10 10 0 0 0-10 10v16a10 10 0 0 0 10 10h36a10 10 0 0 0 10-10V32a10 10 0 0 0-10-10H44L43 23v-6a6 6 0 0 0-6-6H27a6 6 0 0 0-6 6v6L17.5 33l8 7-8 7L33.5 47h13L55 24.5\");offset-rotate:0deg;animation:pen 4.8s linear infinite}.ln-box{animation:ln-box 4.8s linear infinite}.ln-handle{animation:ln-handle 4.8s linear infinite}.ln-chev{animation:ln-chev 4.8s linear infinite}.ln-cur{animation:ln-cur 4.8s linear infinite}.fill{animation:fill 4.8s linear infinite}.blink{animation:blink 4.8s linear infinite}.guide{animation:guide 4.8s linear infinite}.ait-once *{animation-iteration-count:1!important;animation-fill-mode:forwards!important}@media(prefers-reduced-motion:reduce){.ait-loader *{animation:none!important}.o,.pen{opacity:0}.fill,.blink{opacity:1}.badge-in{transform:none;opacity:1}.sheen{opacity:0}}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], once: [{ type: i0.Input, args: [{ isSignal: true, alias: "once", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Logo — the toolbox-prompt mark and its lockups, drawn from the design-system files with the logo tokens, so it is the
 * night box on light grounds and the lavender box on dark grounds without picking a file.
 * Under 32 px use the favicon (assets/logos/favicon-*.svg) instead of the mark.
 */
class AitLogo {
    variant = input('horizontal', ...(ngDevMode ? [{ debugName: "variant" }] : /* istanbul ignore next */ []));
    /** Rendered height in px. Defaults: horizontal 44, stacked 96, mark 32, mark-plain 24, wordmark 24. */
    size = input(undefined, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: (v) => (v == null || v === '' ? undefined : numberAttribute(v)) });
    label = input('AIToolbox', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    uid = aitUid('ait-logo');
    height = computed(() => {
        const d = { horizontal: 44, stacked: 96, mark: 32, 'mark-plain': 24, wordmark: 24 };
        return this.size() ?? d[this.variant()];
    }, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitLogo, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitLogo, isStandalone: true, selector: "ait-logo", inputs: { variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img" }, properties: { "attr.aria-label": "label()" }, classAttribute: "ait-logo" }, ngImport: i0, template: "<!-- Generated from assets/logos by tools/build-brand.mjs. Do not edit by hand. -->\n@switch (variant()) {\n  @case ('horizontal') {\n    <svg viewBox=\"0 0 464.6 104.2\" [attr.height]=\"height()\" [attr.width]=\"height() * 4.45873\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(10.5 8.44) scale(1.375)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M129.4375 76.84375 144.5625 27.343749999999993H158.51875L173.64375 76.84375H164.01875L160.821875 66.53125H142.190625L139.0625 76.84375ZM158.140625 57.8 151.4375 36.109375 144.8375 57.8Z\"></path><path d=\"M178.1125 76.84375V27.343749999999993H187.4625V76.84375Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M206.85000000000002 76.84375V36.074999999999996H191.24375V27.343749999999993H231.80625V36.074999999999996H216.20000000000002V76.84375Z\"></path><path d=\"M251.60625000000002 77.875Q246.003125 77.875 241.775 75.365625Q237.546875 72.85625 235.1921875 68.4390625Q232.8375 64.021875 232.8375 58.28125Q232.8375 52.471875 235.24375 48.0546875Q237.65 43.637499999999996 241.878125 41.162499999999994Q246.10625000000002 38.6875 251.60625000000002 38.6875Q257.209375 38.6875 261.4546875 41.196875Q265.7 43.70625 268.071875 48.123437499999994Q270.44375 52.540625 270.44375 58.28125Q270.44375 64.05625 268.0546875 68.4734375Q265.665625 72.890625 261.4203125 75.3828125Q257.175 77.875 251.60625000000002 77.875ZM251.60625000000002 69.14375Q256.109375 69.14375 258.3265625 66.1015625Q260.54375 63.059375 260.54375 58.28125Q260.54375 53.33125 258.2921875 50.375Q256.04062500000003 47.41875 251.60625000000002 47.41875Q248.546875 47.41875 246.5875 48.79375Q244.628125 50.16875 243.6828125 52.609375Q242.7375 55.05 242.7375 58.28125Q242.7375 63.265625 244.98906250000002 66.2046875Q247.24062500000002 69.14375 251.60625000000002 69.14375Z\"></path><path d=\"M292.30625000000003 77.875Q286.703125 77.875 282.475 75.365625Q278.24687500000005 72.85625 275.89218750000003 68.4390625Q273.5375 64.021875 273.5375 58.28125Q273.5375 52.471875 275.94375 48.0546875Q278.35 43.637499999999996 282.578125 41.162499999999994Q286.80625000000003 38.6875 292.30625000000003 38.6875Q297.909375 38.6875 302.1546875 41.196875Q306.40000000000003 43.70625 308.771875 48.123437499999994Q311.14375 52.540625 311.14375 58.28125Q311.14375 64.05625 308.75468750000005 68.4734375Q306.365625 72.890625 302.1203125 75.3828125Q297.875 77.875 292.30625000000003 77.875ZM292.30625000000003 69.14375Q296.80937500000005 69.14375 299.02656250000007 66.1015625Q301.24375000000003 63.059375 301.24375000000003 58.28125Q301.24375000000003 53.33125 298.9921875 50.375Q296.740625 47.41875 292.30625000000003 47.41875Q289.24687500000005 47.41875 287.2875 48.79375Q285.328125 50.16875 284.3828125 52.609375Q283.4375 55.05 283.4375 58.28125Q283.4375 63.265625 285.6890625 66.2046875Q287.940625 69.14375 292.30625000000003 69.14375Z\"></path><path d=\"M316.9875 76.84375V26.312499999999993H326.33750000000003V76.84375Z\"></path><path d=\"M352.46250000000003 77.875Q346.928125 77.875 343.21562500000005 75.296875Q342.803125 75.021875 342.425 74.7125V76.84375H334.175V27.343749999999993H343.59375000000006V40.921875Q347.065625 38.6875 351.98125000000005 38.6875Q357.30937500000005 38.6875 361.26250000000005 41.23125Q365.21562500000005 43.775 367.39843750000006 48.1921875Q369.58125000000007 52.609375 369.58125000000007 58.28125Q369.58125000000007 63.85 367.43281250000007 68.284375Q365.28437500000007 72.71875 361.43437500000005 75.296875Q357.584375 77.875 352.46250000000003 77.875ZM350.95000000000005 69.55625Q353.975 69.55625 355.90000000000003 68.04375Q357.82500000000005 66.53125 358.75312500000007 63.9703125Q359.68125000000003 61.409375 359.68125000000003 58.28125Q359.68125000000003 55.1875 358.71875 52.6265625Q357.75625 50.065625 355.74531250000007 48.535937499999996Q353.73437500000006 47.006249999999994 350.60625000000005 47.006249999999994Q347.68437500000005 47.006249999999994 345.87968750000005 48.415625Q344.07500000000005 49.825 343.25 52.36875Q342.425 54.912499999999994 342.425 58.28125Q342.425 61.65 343.25 64.19375Q344.07500000000005 66.7375 345.94843750000007 68.146875Q347.82187500000003 69.55625 350.95000000000005 69.55625Z\"></path><path d=\"M391.4437500000001 77.875Q385.84062500000005 77.875 381.61250000000007 75.365625Q377.3843750000001 72.85625 375.0296875000001 68.4390625Q372.67500000000007 64.021875 372.67500000000007 58.28125Q372.67500000000007 52.471875 375.08125000000007 48.0546875Q377.48750000000007 43.637499999999996 381.71562500000005 41.162499999999994Q385.9437500000001 38.6875 391.4437500000001 38.6875Q397.04687500000006 38.6875 401.29218750000007 41.196875Q405.5375000000001 43.70625 407.90937500000007 48.123437499999994Q410.28125000000006 52.540625 410.28125000000006 58.28125Q410.28125000000006 64.05625 407.8921875000001 68.4734375Q405.50312500000007 72.890625 401.25781250000006 75.3828125Q397.01250000000005 77.875 391.4437500000001 77.875ZM391.4437500000001 69.14375Q395.9468750000001 69.14375 398.1640625000001 66.1015625Q400.3812500000001 63.059375 400.3812500000001 58.28125Q400.3812500000001 53.33125 398.12968750000005 50.375Q395.87812500000007 47.41875 391.4437500000001 47.41875Q388.3843750000001 47.41875 386.42500000000007 48.79375Q384.46562500000005 50.16875 383.52031250000005 52.609375Q382.57500000000005 55.05 382.57500000000005 58.28125Q382.57500000000005 63.265625 384.8265625 66.2046875Q387.07812500000006 69.14375 391.4437500000001 69.14375Z\"></path><path d=\"M411.31250000000006 76.84375 424.58125000000007 58.075 411.58750000000003 39.71875H422.58750000000003L430.01250000000005 50.71875L437.30000000000007 39.71875H448.30000000000007L435.30625000000003 58.075L448.64375000000007 76.84375H437.64375000000007L430.01250000000005 65.43125L422.31250000000006 76.84375Z\"></path></g></svg>\n  }\n  @case ('stacked') {\n    <svg viewBox=\"0 0 162.0 146.9\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.10279\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(25.13 7.75) scale(1.5)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M15.999999999999998 130.91 22.159999999999997 110.75H27.843999999999998L34.004 130.91H30.083999999999996L28.781999999999996 126.71H21.194L19.919999999999998 130.91ZM27.689999999999998 123.154 24.959999999999997 114.32 22.272 123.154Z\"></path><path d=\"M35.824 130.91V110.75H39.632V130.91Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M47.528000000000006 130.91V114.306H41.172000000000004V110.75H57.69200000000001V114.306H51.336000000000006V130.91Z\"></path><path d=\"M65.756 131.32999999999998Q63.474000000000004 131.32999999999998 61.752 130.308Q60.03 129.286 59.071 127.487Q58.112 125.688 58.112 123.35Q58.112 120.984 59.092 119.185Q60.072 117.386 61.794000000000004 116.37799999999999Q63.516000000000005 115.36999999999999 65.756 115.36999999999999Q68.03800000000001 115.36999999999999 69.76700000000001 116.392Q71.49600000000001 117.414 72.462 119.213Q73.428 121.012 73.428 123.35Q73.428 125.702 72.455 127.50099999999999Q71.482 129.29999999999998 69.753 130.315Q68.024 131.32999999999998 65.756 131.32999999999998ZM65.756 127.774Q67.59 127.774 68.493 126.535Q69.396 125.29599999999999 69.396 123.35Q69.396 121.334 68.47900000000001 120.13Q67.56200000000001 118.926 65.756 118.926Q64.51 118.926 63.712 119.48599999999999Q62.914 120.04599999999999 62.529 121.03999999999999Q62.144000000000005 122.03399999999999 62.144000000000005 123.35Q62.144000000000005 125.38 63.06100000000001 126.577Q63.978 127.774 65.756 127.774Z\"></path><path d=\"M82.33200000000001 131.32999999999998Q80.05000000000001 131.32999999999998 78.328 130.308Q76.60600000000001 129.286 75.64700000000002 127.487Q74.68800000000002 125.688 74.68800000000002 123.35Q74.68800000000002 120.984 75.668 119.185Q76.64800000000001 117.386 78.37 116.37799999999999Q80.09200000000001 115.36999999999999 82.33200000000001 115.36999999999999Q84.614 115.36999999999999 86.34300000000002 116.392Q88.07200000000002 117.414 89.03800000000001 119.213Q90.00400000000002 121.012 90.00400000000002 123.35Q90.00400000000002 125.702 89.031 127.50099999999999Q88.058 129.29999999999998 86.32900000000001 130.315Q84.60000000000001 131.32999999999998 82.33200000000001 131.32999999999998ZM82.33200000000001 127.774Q84.16600000000001 127.774 85.06900000000002 126.535Q85.97200000000001 125.29599999999999 85.97200000000001 123.35Q85.97200000000001 121.334 85.055 120.13Q84.138 118.926 82.33200000000001 118.926Q81.08600000000001 118.926 80.28800000000001 119.48599999999999Q79.49000000000001 120.04599999999999 79.10500000000002 121.03999999999999Q78.72000000000001 122.03399999999999 78.72000000000001 123.35Q78.72000000000001 125.38 79.63700000000001 126.577Q80.55400000000002 127.774 82.33200000000001 127.774Z\"></path><path d=\"M92.384 130.91V110.33H96.19200000000001V130.91Z\"></path><path d=\"M106.832 131.32999999999998Q104.578 131.32999999999998 103.066 130.28Q102.898 130.168 102.744 130.042V130.91H99.384V110.75H103.22V116.28Q104.634 115.36999999999999 106.636 115.36999999999999Q108.806 115.36999999999999 110.416 116.40599999999999Q112.026 117.442 112.91499999999999 119.24099999999999Q113.804 121.03999999999999 113.804 123.35Q113.804 125.618 112.929 127.42399999999999Q112.054 129.23 110.486 130.27999999999997Q108.918 131.32999999999998 106.832 131.32999999999998ZM106.216 127.942Q107.448 127.942 108.232 127.326Q109.01599999999999 126.71 109.39399999999999 125.667Q109.77199999999999 124.624 109.77199999999999 123.35Q109.77199999999999 122.09 109.38 121.047Q108.988 120.00399999999999 108.169 119.381Q107.35 118.758 106.076 118.758Q104.886 118.758 104.151 119.332Q103.416 119.90599999999999 103.08 120.942Q102.744 121.978 102.744 123.35Q102.744 124.722 103.08 125.758Q103.416 126.794 104.179 127.368Q104.942 127.942 106.216 127.942Z\"></path><path d=\"M122.708 131.32999999999998Q120.426 131.32999999999998 118.70400000000001 130.308Q116.982 129.286 116.023 127.487Q115.06400000000001 125.688 115.06400000000001 123.35Q115.06400000000001 120.984 116.04400000000001 119.185Q117.024 117.386 118.74600000000001 116.37799999999999Q120.468 115.36999999999999 122.708 115.36999999999999Q124.99000000000001 115.36999999999999 126.71900000000001 116.392Q128.448 117.414 129.414 119.213Q130.38 121.012 130.38 123.35Q130.38 125.702 129.40699999999998 127.50099999999999Q128.434 129.29999999999998 126.705 130.315Q124.976 131.32999999999998 122.708 131.32999999999998ZM122.708 127.774Q124.542 127.774 125.445 126.535Q126.348 125.29599999999999 126.348 123.35Q126.348 121.334 125.43100000000001 120.13Q124.51400000000001 118.926 122.708 118.926Q121.462 118.926 120.664 119.48599999999999Q119.866 120.04599999999999 119.481 121.03999999999999Q119.096 122.03399999999999 119.096 123.35Q119.096 125.38 120.013 126.577Q120.93 127.774 122.708 127.774Z\"></path><path d=\"M130.8 130.91 136.204 123.26599999999999 130.912 115.78999999999999H135.392L138.416 120.27L141.38400000000001 115.78999999999999H145.864L140.572 123.26599999999999L146.00400000000002 130.91H141.524L138.416 126.262L135.28 130.91Z\"></path></g></svg>\n  }\n  @case ('mark') {\n    <svg viewBox=\"0 0 74 64\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.15625\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(0 0) scale(1)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g></svg>\n  }\n  @case ('mark-plain') {\n    <svg viewBox=\"0 0 64 64\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.00000\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(0 0) scale(1)\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g></svg>\n  }\n  @case ('wordmark') {\n    <svg viewBox=\"0 0 307.1 68.2\" [attr.height]=\"height()\" [attr.width]=\"height() * 4.50293\" focusable=\"false\" aria-hidden=\"true\"><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M5.28 50.08 19.36 4.0H32.352000000000004L46.432 50.08H37.472L34.496 40.48H17.152L14.24 50.08ZM32.0 32.352 25.76 12.159999999999997 19.616 32.352Z\"></path><path d=\"M50.592 50.08V4.0H59.296V50.08Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M77.344 50.08V12.128H62.815999999999995V4.0H100.576V12.128H86.048V50.08Z\"></path><path d=\"M119.008 51.04Q113.792 51.04 109.856 48.70399999999999Q105.92 46.367999999999995 103.72800000000001 42.256Q101.536 38.144 101.536 32.8Q101.536 27.392 103.77600000000001 23.28Q106.016 19.168 109.952 16.863999999999997Q113.888 14.559999999999995 119.008 14.559999999999995Q124.224 14.559999999999995 128.176 16.895999999999997Q132.128 19.232 134.33599999999998 23.344Q136.54399999999998 27.456 136.54399999999998 32.8Q136.54399999999998 38.176 134.32 42.288Q132.096 46.4 128.144 48.72Q124.19200000000001 51.04 119.008 51.04ZM119.008 42.912Q123.2 42.912 125.26400000000001 40.08Q127.328 37.248 127.328 32.8Q127.328 28.191999999999997 125.232 25.439999999999998Q123.136 22.688 119.008 22.688Q116.16 22.688 114.336 23.967999999999996Q112.512 25.247999999999998 111.632 27.519999999999996Q110.752 29.791999999999998 110.752 32.8Q110.752 37.44 112.848 40.176Q114.944 42.912 119.008 42.912Z\"></path><path d=\"M156.89600000000002 51.04Q151.68 51.04 147.744 48.70399999999999Q143.808 46.367999999999995 141.61599999999999 42.256Q139.424 38.144 139.424 32.8Q139.424 27.392 141.664 23.28Q143.904 19.168 147.84 16.863999999999997Q151.776 14.559999999999995 156.89600000000002 14.559999999999995Q162.112 14.559999999999995 166.06400000000002 16.895999999999997Q170.01600000000002 19.232 172.22400000000002 23.344Q174.43200000000002 27.456 174.43200000000002 32.8Q174.43200000000002 38.176 172.20800000000003 42.288Q169.984 46.4 166.032 48.72Q162.08 51.04 156.89600000000002 51.04ZM156.89600000000002 42.912Q161.088 42.912 163.152 40.08Q165.216 37.248 165.216 32.8Q165.216 28.191999999999997 163.12 25.439999999999998Q161.024 22.688 156.89600000000002 22.688Q154.048 22.688 152.224 23.967999999999996Q150.4 25.247999999999998 149.52 27.519999999999996Q148.64000000000001 29.791999999999998 148.64000000000001 32.8Q148.64000000000001 37.44 150.736 40.176Q152.832 42.912 156.89600000000002 42.912Z\"></path><path d=\"M179.872 50.08V3.039999999999999H188.57600000000002V50.08Z\"></path><path d=\"M212.89600000000002 51.04Q207.74400000000003 51.04 204.288 48.64Q203.90400000000002 48.384 203.55200000000002 48.096V50.08H195.872V4.0H204.64000000000001V16.64Q207.872 14.559999999999995 212.448 14.559999999999995Q217.40800000000002 14.559999999999995 221.08800000000002 16.927999999999997Q224.76800000000003 19.296 226.8 23.408Q228.83200000000002 27.52 228.83200000000002 32.8Q228.83200000000002 37.983999999999995 226.83200000000002 42.111999999999995Q224.83200000000002 46.239999999999995 221.24800000000002 48.64Q217.66400000000002 51.04 212.89600000000002 51.04ZM211.48800000000003 43.296Q214.30400000000003 43.296 216.09600000000003 41.888Q217.88800000000003 40.48 218.752 38.096Q219.616 35.711999999999996 219.616 32.8Q219.616 29.919999999999998 218.72000000000003 27.535999999999998Q217.824 25.151999999999997 215.952 23.727999999999998Q214.08 22.304 211.168 22.304Q208.448 22.304 206.76800000000003 23.616Q205.08800000000002 24.927999999999997 204.32000000000002 27.296Q203.55200000000002 29.663999999999998 203.55200000000002 32.8Q203.55200000000002 35.936 204.32000000000002 38.304Q205.08800000000002 40.672 206.83200000000002 41.983999999999995Q208.57600000000002 43.296 211.48800000000003 43.296Z\"></path><path d=\"M249.18400000000003 51.04Q243.96800000000002 51.04 240.032 48.70399999999999Q236.096 46.367999999999995 233.904 42.256Q231.71200000000002 38.144 231.71200000000002 32.8Q231.71200000000002 27.392 233.952 23.28Q236.192 19.168 240.12800000000001 16.863999999999997Q244.06400000000002 14.559999999999995 249.18400000000003 14.559999999999995Q254.4 14.559999999999995 258.35200000000003 16.895999999999997Q262.30400000000003 19.232 264.51200000000006 23.344Q266.72 27.456 266.72 32.8Q266.72 38.176 264.496 42.288Q262.272 46.4 258.32 48.72Q254.36800000000002 51.04 249.18400000000003 51.04ZM249.18400000000003 42.912Q253.376 42.912 255.44 40.08Q257.504 37.248 257.504 32.8Q257.504 28.191999999999997 255.40800000000002 25.439999999999998Q253.312 22.688 249.18400000000003 22.688Q246.336 22.688 244.512 23.967999999999996Q242.68800000000002 25.247999999999998 241.80800000000002 27.519999999999996Q240.92800000000003 29.791999999999998 240.92800000000003 32.8Q240.92800000000003 37.44 243.024 40.176Q245.12 42.912 249.18400000000003 42.912Z\"></path><path d=\"M267.68 50.08 280.03200000000004 32.608 267.93600000000004 15.519999999999996H278.17600000000004L285.088 25.759999999999998L291.872 15.519999999999996H302.112L290.016 32.608L302.432 50.08H292.192L285.088 39.455999999999996L277.92 50.08Z\"></path></g></svg>\n  }\n}\n", styles: [":host{display:inline-flex;flex:none;line-height:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitLogo, decorators: [{
            type: Component,
            args: [{ selector: 'ait-logo', changeDetection: ChangeDetectionStrategy.OnPush, host: { class: 'ait-logo', role: 'img', '[attr.aria-label]': 'label()' }, template: "<!-- Generated from assets/logos by tools/build-brand.mjs. Do not edit by hand. -->\n@switch (variant()) {\n  @case ('horizontal') {\n    <svg viewBox=\"0 0 464.6 104.2\" [attr.height]=\"height()\" [attr.width]=\"height() * 4.45873\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(10.5 8.44) scale(1.375)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M129.4375 76.84375 144.5625 27.343749999999993H158.51875L173.64375 76.84375H164.01875L160.821875 66.53125H142.190625L139.0625 76.84375ZM158.140625 57.8 151.4375 36.109375 144.8375 57.8Z\"></path><path d=\"M178.1125 76.84375V27.343749999999993H187.4625V76.84375Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M206.85000000000002 76.84375V36.074999999999996H191.24375V27.343749999999993H231.80625V36.074999999999996H216.20000000000002V76.84375Z\"></path><path d=\"M251.60625000000002 77.875Q246.003125 77.875 241.775 75.365625Q237.546875 72.85625 235.1921875 68.4390625Q232.8375 64.021875 232.8375 58.28125Q232.8375 52.471875 235.24375 48.0546875Q237.65 43.637499999999996 241.878125 41.162499999999994Q246.10625000000002 38.6875 251.60625000000002 38.6875Q257.209375 38.6875 261.4546875 41.196875Q265.7 43.70625 268.071875 48.123437499999994Q270.44375 52.540625 270.44375 58.28125Q270.44375 64.05625 268.0546875 68.4734375Q265.665625 72.890625 261.4203125 75.3828125Q257.175 77.875 251.60625000000002 77.875ZM251.60625000000002 69.14375Q256.109375 69.14375 258.3265625 66.1015625Q260.54375 63.059375 260.54375 58.28125Q260.54375 53.33125 258.2921875 50.375Q256.04062500000003 47.41875 251.60625000000002 47.41875Q248.546875 47.41875 246.5875 48.79375Q244.628125 50.16875 243.6828125 52.609375Q242.7375 55.05 242.7375 58.28125Q242.7375 63.265625 244.98906250000002 66.2046875Q247.24062500000002 69.14375 251.60625000000002 69.14375Z\"></path><path d=\"M292.30625000000003 77.875Q286.703125 77.875 282.475 75.365625Q278.24687500000005 72.85625 275.89218750000003 68.4390625Q273.5375 64.021875 273.5375 58.28125Q273.5375 52.471875 275.94375 48.0546875Q278.35 43.637499999999996 282.578125 41.162499999999994Q286.80625000000003 38.6875 292.30625000000003 38.6875Q297.909375 38.6875 302.1546875 41.196875Q306.40000000000003 43.70625 308.771875 48.123437499999994Q311.14375 52.540625 311.14375 58.28125Q311.14375 64.05625 308.75468750000005 68.4734375Q306.365625 72.890625 302.1203125 75.3828125Q297.875 77.875 292.30625000000003 77.875ZM292.30625000000003 69.14375Q296.80937500000005 69.14375 299.02656250000007 66.1015625Q301.24375000000003 63.059375 301.24375000000003 58.28125Q301.24375000000003 53.33125 298.9921875 50.375Q296.740625 47.41875 292.30625000000003 47.41875Q289.24687500000005 47.41875 287.2875 48.79375Q285.328125 50.16875 284.3828125 52.609375Q283.4375 55.05 283.4375 58.28125Q283.4375 63.265625 285.6890625 66.2046875Q287.940625 69.14375 292.30625000000003 69.14375Z\"></path><path d=\"M316.9875 76.84375V26.312499999999993H326.33750000000003V76.84375Z\"></path><path d=\"M352.46250000000003 77.875Q346.928125 77.875 343.21562500000005 75.296875Q342.803125 75.021875 342.425 74.7125V76.84375H334.175V27.343749999999993H343.59375000000006V40.921875Q347.065625 38.6875 351.98125000000005 38.6875Q357.30937500000005 38.6875 361.26250000000005 41.23125Q365.21562500000005 43.775 367.39843750000006 48.1921875Q369.58125000000007 52.609375 369.58125000000007 58.28125Q369.58125000000007 63.85 367.43281250000007 68.284375Q365.28437500000007 72.71875 361.43437500000005 75.296875Q357.584375 77.875 352.46250000000003 77.875ZM350.95000000000005 69.55625Q353.975 69.55625 355.90000000000003 68.04375Q357.82500000000005 66.53125 358.75312500000007 63.9703125Q359.68125000000003 61.409375 359.68125000000003 58.28125Q359.68125000000003 55.1875 358.71875 52.6265625Q357.75625 50.065625 355.74531250000007 48.535937499999996Q353.73437500000006 47.006249999999994 350.60625000000005 47.006249999999994Q347.68437500000005 47.006249999999994 345.87968750000005 48.415625Q344.07500000000005 49.825 343.25 52.36875Q342.425 54.912499999999994 342.425 58.28125Q342.425 61.65 343.25 64.19375Q344.07500000000005 66.7375 345.94843750000007 68.146875Q347.82187500000003 69.55625 350.95000000000005 69.55625Z\"></path><path d=\"M391.4437500000001 77.875Q385.84062500000005 77.875 381.61250000000007 75.365625Q377.3843750000001 72.85625 375.0296875000001 68.4390625Q372.67500000000007 64.021875 372.67500000000007 58.28125Q372.67500000000007 52.471875 375.08125000000007 48.0546875Q377.48750000000007 43.637499999999996 381.71562500000005 41.162499999999994Q385.9437500000001 38.6875 391.4437500000001 38.6875Q397.04687500000006 38.6875 401.29218750000007 41.196875Q405.5375000000001 43.70625 407.90937500000007 48.123437499999994Q410.28125000000006 52.540625 410.28125000000006 58.28125Q410.28125000000006 64.05625 407.8921875000001 68.4734375Q405.50312500000007 72.890625 401.25781250000006 75.3828125Q397.01250000000005 77.875 391.4437500000001 77.875ZM391.4437500000001 69.14375Q395.9468750000001 69.14375 398.1640625000001 66.1015625Q400.3812500000001 63.059375 400.3812500000001 58.28125Q400.3812500000001 53.33125 398.12968750000005 50.375Q395.87812500000007 47.41875 391.4437500000001 47.41875Q388.3843750000001 47.41875 386.42500000000007 48.79375Q384.46562500000005 50.16875 383.52031250000005 52.609375Q382.57500000000005 55.05 382.57500000000005 58.28125Q382.57500000000005 63.265625 384.8265625 66.2046875Q387.07812500000006 69.14375 391.4437500000001 69.14375Z\"></path><path d=\"M411.31250000000006 76.84375 424.58125000000007 58.075 411.58750000000003 39.71875H422.58750000000003L430.01250000000005 50.71875L437.30000000000007 39.71875H448.30000000000007L435.30625000000003 58.075L448.64375000000007 76.84375H437.64375000000007L430.01250000000005 65.43125L422.31250000000006 76.84375Z\"></path></g></svg>\n  }\n  @case ('stacked') {\n    <svg viewBox=\"0 0 162.0 146.9\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.10279\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(25.13 7.75) scale(1.5)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M15.999999999999998 130.91 22.159999999999997 110.75H27.843999999999998L34.004 130.91H30.083999999999996L28.781999999999996 126.71H21.194L19.919999999999998 130.91ZM27.689999999999998 123.154 24.959999999999997 114.32 22.272 123.154Z\"></path><path d=\"M35.824 130.91V110.75H39.632V130.91Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M47.528000000000006 130.91V114.306H41.172000000000004V110.75H57.69200000000001V114.306H51.336000000000006V130.91Z\"></path><path d=\"M65.756 131.32999999999998Q63.474000000000004 131.32999999999998 61.752 130.308Q60.03 129.286 59.071 127.487Q58.112 125.688 58.112 123.35Q58.112 120.984 59.092 119.185Q60.072 117.386 61.794000000000004 116.37799999999999Q63.516000000000005 115.36999999999999 65.756 115.36999999999999Q68.03800000000001 115.36999999999999 69.76700000000001 116.392Q71.49600000000001 117.414 72.462 119.213Q73.428 121.012 73.428 123.35Q73.428 125.702 72.455 127.50099999999999Q71.482 129.29999999999998 69.753 130.315Q68.024 131.32999999999998 65.756 131.32999999999998ZM65.756 127.774Q67.59 127.774 68.493 126.535Q69.396 125.29599999999999 69.396 123.35Q69.396 121.334 68.47900000000001 120.13Q67.56200000000001 118.926 65.756 118.926Q64.51 118.926 63.712 119.48599999999999Q62.914 120.04599999999999 62.529 121.03999999999999Q62.144000000000005 122.03399999999999 62.144000000000005 123.35Q62.144000000000005 125.38 63.06100000000001 126.577Q63.978 127.774 65.756 127.774Z\"></path><path d=\"M82.33200000000001 131.32999999999998Q80.05000000000001 131.32999999999998 78.328 130.308Q76.60600000000001 129.286 75.64700000000002 127.487Q74.68800000000002 125.688 74.68800000000002 123.35Q74.68800000000002 120.984 75.668 119.185Q76.64800000000001 117.386 78.37 116.37799999999999Q80.09200000000001 115.36999999999999 82.33200000000001 115.36999999999999Q84.614 115.36999999999999 86.34300000000002 116.392Q88.07200000000002 117.414 89.03800000000001 119.213Q90.00400000000002 121.012 90.00400000000002 123.35Q90.00400000000002 125.702 89.031 127.50099999999999Q88.058 129.29999999999998 86.32900000000001 130.315Q84.60000000000001 131.32999999999998 82.33200000000001 131.32999999999998ZM82.33200000000001 127.774Q84.16600000000001 127.774 85.06900000000002 126.535Q85.97200000000001 125.29599999999999 85.97200000000001 123.35Q85.97200000000001 121.334 85.055 120.13Q84.138 118.926 82.33200000000001 118.926Q81.08600000000001 118.926 80.28800000000001 119.48599999999999Q79.49000000000001 120.04599999999999 79.10500000000002 121.03999999999999Q78.72000000000001 122.03399999999999 78.72000000000001 123.35Q78.72000000000001 125.38 79.63700000000001 126.577Q80.55400000000002 127.774 82.33200000000001 127.774Z\"></path><path d=\"M92.384 130.91V110.33H96.19200000000001V130.91Z\"></path><path d=\"M106.832 131.32999999999998Q104.578 131.32999999999998 103.066 130.28Q102.898 130.168 102.744 130.042V130.91H99.384V110.75H103.22V116.28Q104.634 115.36999999999999 106.636 115.36999999999999Q108.806 115.36999999999999 110.416 116.40599999999999Q112.026 117.442 112.91499999999999 119.24099999999999Q113.804 121.03999999999999 113.804 123.35Q113.804 125.618 112.929 127.42399999999999Q112.054 129.23 110.486 130.27999999999997Q108.918 131.32999999999998 106.832 131.32999999999998ZM106.216 127.942Q107.448 127.942 108.232 127.326Q109.01599999999999 126.71 109.39399999999999 125.667Q109.77199999999999 124.624 109.77199999999999 123.35Q109.77199999999999 122.09 109.38 121.047Q108.988 120.00399999999999 108.169 119.381Q107.35 118.758 106.076 118.758Q104.886 118.758 104.151 119.332Q103.416 119.90599999999999 103.08 120.942Q102.744 121.978 102.744 123.35Q102.744 124.722 103.08 125.758Q103.416 126.794 104.179 127.368Q104.942 127.942 106.216 127.942Z\"></path><path d=\"M122.708 131.32999999999998Q120.426 131.32999999999998 118.70400000000001 130.308Q116.982 129.286 116.023 127.487Q115.06400000000001 125.688 115.06400000000001 123.35Q115.06400000000001 120.984 116.04400000000001 119.185Q117.024 117.386 118.74600000000001 116.37799999999999Q120.468 115.36999999999999 122.708 115.36999999999999Q124.99000000000001 115.36999999999999 126.71900000000001 116.392Q128.448 117.414 129.414 119.213Q130.38 121.012 130.38 123.35Q130.38 125.702 129.40699999999998 127.50099999999999Q128.434 129.29999999999998 126.705 130.315Q124.976 131.32999999999998 122.708 131.32999999999998ZM122.708 127.774Q124.542 127.774 125.445 126.535Q126.348 125.29599999999999 126.348 123.35Q126.348 121.334 125.43100000000001 120.13Q124.51400000000001 118.926 122.708 118.926Q121.462 118.926 120.664 119.48599999999999Q119.866 120.04599999999999 119.481 121.03999999999999Q119.096 122.03399999999999 119.096 123.35Q119.096 125.38 120.013 126.577Q120.93 127.774 122.708 127.774Z\"></path><path d=\"M130.8 130.91 136.204 123.26599999999999 130.912 115.78999999999999H135.392L138.416 120.27L141.38400000000001 115.78999999999999H145.864L140.572 123.26599999999999L146.00400000000002 130.91H141.524L138.416 126.262L135.28 130.91Z\"></path></g></svg>\n  }\n  @case ('mark') {\n    <svg viewBox=\"0 0 74 64\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.15625\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(0 0) scale(1)\"><mask [attr.id]=\"uid + '-m'\" maskUnits=\"userSpaceOnUse\" x=\"0\" y=\"0\" width=\"74\" height=\"64\"><rect width=\"74\" height=\"64\" fill=\"#fff\"></rect><rect x=\"37\" y=\"3\" width=\"36\" height=\"24\" rx=\"7\" fill=\"#000\"></rect></mask><g [attr.mask]=\"'url(#' + uid + '-m)'\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g><rect x=\"39.5\" y=\"5.5\" width=\"31\" height=\"19\" rx=\"5\" style=\"fill: var(--md-sys-color-ai)\"></rect><g style=\"fill: var(--md-sys-color-on-ai)\"><path d=\"M48.567 20.04 51.647 9.959999999999999H54.489L57.569 20.04H55.609L54.958 17.939999999999998H51.164L50.527 20.04ZM54.412 16.162 53.047 11.745 51.702999999999996 16.162Z\"></path><path d=\"M58.689 20.04V9.959999999999999H60.593V20.04Z\"></path></g></g></svg>\n  }\n  @case ('mark-plain') {\n    <svg viewBox=\"0 0 64 64\" [attr.height]=\"height()\" [attr.width]=\"height() * 1.00000\" focusable=\"false\" aria-hidden=\"true\"><g transform=\"translate(0 0) scale(1)\"><path d=\"M21 23v-6a6 6 0 0 1 6-6h10a6 6 0 0 1 6 6v6\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-box)\" stroke-width=\"6\" stroke-linecap=\"round\"></path><rect x=\"4\" y=\"22\" width=\"56\" height=\"36\" rx=\"10\" style=\"fill: var(--md-sys-color-logo-box)\"></rect><path d=\"M17.5 33l8 7-8 7\" fill=\"none\" style=\"stroke: var(--md-sys-color-on-logo-box)\" stroke-width=\"5.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"></path><path d=\"M33.5 47h13\" fill=\"none\" style=\"stroke: var(--md-sys-color-logo-cursor)\" stroke-width=\"5.5\" stroke-linecap=\"round\"></path></g></svg>\n  }\n  @case ('wordmark') {\n    <svg viewBox=\"0 0 307.1 68.2\" [attr.height]=\"height()\" [attr.width]=\"height() * 4.50293\" focusable=\"false\" aria-hidden=\"true\"><g style=\"fill: var(--md-sys-color-on-surface)\"><path d=\"M5.28 50.08 19.36 4.0H32.352000000000004L46.432 50.08H37.472L34.496 40.48H17.152L14.24 50.08ZM32.0 32.352 25.76 12.159999999999997 19.616 32.352Z\"></path><path d=\"M50.592 50.08V4.0H59.296V50.08Z\"></path></g><g style=\"fill: var(--md-sys-color-primary)\"><path d=\"M77.344 50.08V12.128H62.815999999999995V4.0H100.576V12.128H86.048V50.08Z\"></path><path d=\"M119.008 51.04Q113.792 51.04 109.856 48.70399999999999Q105.92 46.367999999999995 103.72800000000001 42.256Q101.536 38.144 101.536 32.8Q101.536 27.392 103.77600000000001 23.28Q106.016 19.168 109.952 16.863999999999997Q113.888 14.559999999999995 119.008 14.559999999999995Q124.224 14.559999999999995 128.176 16.895999999999997Q132.128 19.232 134.33599999999998 23.344Q136.54399999999998 27.456 136.54399999999998 32.8Q136.54399999999998 38.176 134.32 42.288Q132.096 46.4 128.144 48.72Q124.19200000000001 51.04 119.008 51.04ZM119.008 42.912Q123.2 42.912 125.26400000000001 40.08Q127.328 37.248 127.328 32.8Q127.328 28.191999999999997 125.232 25.439999999999998Q123.136 22.688 119.008 22.688Q116.16 22.688 114.336 23.967999999999996Q112.512 25.247999999999998 111.632 27.519999999999996Q110.752 29.791999999999998 110.752 32.8Q110.752 37.44 112.848 40.176Q114.944 42.912 119.008 42.912Z\"></path><path d=\"M156.89600000000002 51.04Q151.68 51.04 147.744 48.70399999999999Q143.808 46.367999999999995 141.61599999999999 42.256Q139.424 38.144 139.424 32.8Q139.424 27.392 141.664 23.28Q143.904 19.168 147.84 16.863999999999997Q151.776 14.559999999999995 156.89600000000002 14.559999999999995Q162.112 14.559999999999995 166.06400000000002 16.895999999999997Q170.01600000000002 19.232 172.22400000000002 23.344Q174.43200000000002 27.456 174.43200000000002 32.8Q174.43200000000002 38.176 172.20800000000003 42.288Q169.984 46.4 166.032 48.72Q162.08 51.04 156.89600000000002 51.04ZM156.89600000000002 42.912Q161.088 42.912 163.152 40.08Q165.216 37.248 165.216 32.8Q165.216 28.191999999999997 163.12 25.439999999999998Q161.024 22.688 156.89600000000002 22.688Q154.048 22.688 152.224 23.967999999999996Q150.4 25.247999999999998 149.52 27.519999999999996Q148.64000000000001 29.791999999999998 148.64000000000001 32.8Q148.64000000000001 37.44 150.736 40.176Q152.832 42.912 156.89600000000002 42.912Z\"></path><path d=\"M179.872 50.08V3.039999999999999H188.57600000000002V50.08Z\"></path><path d=\"M212.89600000000002 51.04Q207.74400000000003 51.04 204.288 48.64Q203.90400000000002 48.384 203.55200000000002 48.096V50.08H195.872V4.0H204.64000000000001V16.64Q207.872 14.559999999999995 212.448 14.559999999999995Q217.40800000000002 14.559999999999995 221.08800000000002 16.927999999999997Q224.76800000000003 19.296 226.8 23.408Q228.83200000000002 27.52 228.83200000000002 32.8Q228.83200000000002 37.983999999999995 226.83200000000002 42.111999999999995Q224.83200000000002 46.239999999999995 221.24800000000002 48.64Q217.66400000000002 51.04 212.89600000000002 51.04ZM211.48800000000003 43.296Q214.30400000000003 43.296 216.09600000000003 41.888Q217.88800000000003 40.48 218.752 38.096Q219.616 35.711999999999996 219.616 32.8Q219.616 29.919999999999998 218.72000000000003 27.535999999999998Q217.824 25.151999999999997 215.952 23.727999999999998Q214.08 22.304 211.168 22.304Q208.448 22.304 206.76800000000003 23.616Q205.08800000000002 24.927999999999997 204.32000000000002 27.296Q203.55200000000002 29.663999999999998 203.55200000000002 32.8Q203.55200000000002 35.936 204.32000000000002 38.304Q205.08800000000002 40.672 206.83200000000002 41.983999999999995Q208.57600000000002 43.296 211.48800000000003 43.296Z\"></path><path d=\"M249.18400000000003 51.04Q243.96800000000002 51.04 240.032 48.70399999999999Q236.096 46.367999999999995 233.904 42.256Q231.71200000000002 38.144 231.71200000000002 32.8Q231.71200000000002 27.392 233.952 23.28Q236.192 19.168 240.12800000000001 16.863999999999997Q244.06400000000002 14.559999999999995 249.18400000000003 14.559999999999995Q254.4 14.559999999999995 258.35200000000003 16.895999999999997Q262.30400000000003 19.232 264.51200000000006 23.344Q266.72 27.456 266.72 32.8Q266.72 38.176 264.496 42.288Q262.272 46.4 258.32 48.72Q254.36800000000002 51.04 249.18400000000003 51.04ZM249.18400000000003 42.912Q253.376 42.912 255.44 40.08Q257.504 37.248 257.504 32.8Q257.504 28.191999999999997 255.40800000000002 25.439999999999998Q253.312 22.688 249.18400000000003 22.688Q246.336 22.688 244.512 23.967999999999996Q242.68800000000002 25.247999999999998 241.80800000000002 27.519999999999996Q240.92800000000003 29.791999999999998 240.92800000000003 32.8Q240.92800000000003 37.44 243.024 40.176Q245.12 42.912 249.18400000000003 42.912Z\"></path><path d=\"M267.68 50.08 280.03200000000004 32.608 267.93600000000004 15.519999999999996H278.17600000000004L285.088 25.759999999999998L291.872 15.519999999999996H302.112L290.016 32.608L302.432 50.08H292.192L285.088 39.455999999999996L277.92 50.08Z\"></path></g></svg>\n  }\n}\n", styles: [":host{display:inline-flex;flex:none;line-height:0}\n"] }]
        }], propDecorators: { variant: [{ type: i0.Input, args: [{ isSignal: true, alias: "variant", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });
/**
 * Chatbot mark — the assistant's avatar, the `{ >_ }` brace box drawn as one outline. Never the brand mark, never below
 * 24 px: 24 in a message, 32 in the assistant header, 48 in a launcher.
 */
class AitChatbotMark {
    size = input(24, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    /** Accessible name; empty when a visible label sits next to it. */
    label = input('', ...(ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []));
    px = computed(() => Math.max(24, this.size()), ...(ngDevMode ? [{ debugName: "px" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitChatbotMark, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "21.2.25", type: AitChatbotMark, isStandalone: true, selector: "ait-chatbot-mark", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.role": "label() ? \"img\" : null", "attr.aria-label": "label() || null", "attr.aria-hidden": "label() ? null : \"true\"" }, classAttribute: "ait-chatbot-mark" }, ngImport: i0, template: `
    <svg viewBox="0 0 64 64" [attr.width]="px()" [attr.height]="px()" focusable="false" aria-hidden="true">
      <path d="M26 56h-3a9 9 0 0 1-9-9v-4l-5-4 5-4v-4a9 9 0 0 1 9-9h2l7-5 7 5h2a9 9 0 0 1 9 9v4l5 4-5 4v4a9 9 0 0 1-9 9h-3" fill="none" class="line" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M26 37l6 5-6 5" fill="none" class="line" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M35 49h5" fill="none" class="cursor" stroke-width="4.5" stroke-linecap="round" />
    </svg>
  `, isInline: true, styles: [":host{display:inline-flex;flex:none;line-height:0}.line{stroke:var(--md-sys-color-primary)}.cursor{stroke:light-dark(#008857,#00f29e)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitChatbotMark, decorators: [{
            type: Component,
            args: [{ selector: 'ait-chatbot-mark', changeDetection: ChangeDetectionStrategy.OnPush, host: {
                        class: 'ait-chatbot-mark',
                        '[attr.role]': 'label() ? "img" : null',
                        '[attr.aria-label]': 'label() || null',
                        '[attr.aria-hidden]': 'label() ? null : "true"',
                    }, template: `
    <svg viewBox="0 0 64 64" [attr.width]="px()" [attr.height]="px()" focusable="false" aria-hidden="true">
      <path d="M26 56h-3a9 9 0 0 1-9-9v-4l-5-4 5-4v-4a9 9 0 0 1 9-9h2l7-5 7 5h2a9 9 0 0 1 9 9v4l5 4-5 4v4a9 9 0 0 1-9 9h-3" fill="none" class="line" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M26 37l6 5-6 5" fill="none" class="line" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" />
      <path d="M35 49h5" fill="none" class="cursor" stroke-width="4.5" stroke-linecap="round" />
    </svg>
  `, styles: [":host{display:inline-flex;flex:none;line-height:0}.line{stroke:var(--md-sys-color-primary)}.cursor{stroke:light-dark(#008857,#00f29e)}\n"] }]
        }], propDecorators: { size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/** Counts the Run buttons on screen so a second one is reported in development (INV-DS-02). */
class AitRunRegistry {
    active = new Set();
    add(el) {
        this.active.add(el);
        if (isDevMode() && this.active.size > 1) {
            console.warn(`[aitRun] ${this.active.size} Run buttons on screen: the design system allows one per screen. Use aitRunText for repeated row actions.`, [...this.active]);
        }
    }
    delete(el) {
        this.active.delete(el);
    }
    get count() {
        return this.active.size;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRunRegistry, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRunRegistry, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRunRegistry, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
/**
 * Run — the ONE action per screen that starts work (Run, Deploy, Apply, New run): the night "terminal" button with the
 * neon play icon. Use on a filled Material button, with a leading icon:
 *
 * ```html
 * <button mat-flat-button aitRun><mat-icon svgIcon="ait:play" />Request Run</button>
 * ```
 * Never inside a dialog (confirm there with a filled primary button). Development builds warn on both mistakes.
 */
class AitRun {
    constructor() {
        const el = inject((ElementRef)).nativeElement;
        const registry = inject(AitRunRegistry);
        registry.add(el);
        inject(DestroyRef).onDestroy(() => registry.delete(el));
        afterNextRender(() => {
            if (isDevMode() && el.closest('mat-dialog-container, .mat-mdc-dialog-container, [role="dialog"], [role="alertdialog"]')) {
                console.warn('[aitRun] The Run button is never used inside a dialog: confirm with a filled primary button.', el);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRun, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.25", type: AitRun, isStandalone: true, selector: "[aitRun]", host: { classAttribute: "dt-run" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRun, decorators: [{
            type: Directive,
            args: [{
                    selector: '[aitRun]',
                    host: { class: 'dt-run' },
                }]
        }], ctorParameters: () => [] });
/** Repeated run actions (table rows, cards): a text button in on-surface with the tertiary play icon, never filled. */
class AitRunText {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRunText, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.25", type: AitRunText, isStandalone: true, selector: "[aitRunText]", host: { classAttribute: "dt-run-text" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitRunText, decorators: [{
            type: Directive,
            args: [{ selector: '[aitRunText]', host: { class: 'dt-run-text' } }]
        }] });
/** Tonal button (secondary-container) beside a filled one. Works on M2 and M3: `<button mat-flat-button aitTonal>`. */
class AitTonal {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitTonal, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.25", type: AitTonal, isStandalone: true, selector: "[aitTonal]", host: { classAttribute: "dt-tonal" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitTonal, decorators: [{
            type: Directive,
            args: [{ selector: '[aitTonal]', host: { class: 'dt-tonal' } }]
        }] });
/** Destructive action: a text button in error, never a filled red. `<button mat-button aitDanger>Delete</button>` */
class AitDanger {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDanger, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.25", type: AitDanger, isStandalone: true, selector: "[aitDanger]", host: { classAttribute: "dt-danger" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDanger, decorators: [{
            type: Directive,
            args: [{ selector: '[aitDanger]', host: { class: 'dt-danger' } }]
        }] });
/** AI-powered features only (teal), always with the sparkle icon: buttons, chips, cards. */
class AitAi {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAi, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.25", type: AitAi, isStandalone: true, selector: "[aitAi]", host: { classAttribute: "dt-ai" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAi, decorators: [{
            type: Directive,
            args: [{ selector: '[aitAi]', host: { class: 'dt-ai' } }]
        }] });

/**
 * AI chip — marks content a model produced (`ai-container` + sparkle). Only AI features may use it.
 * `<ait-ai-chip>Generated by ui-design</ait-ai-chip>`
 */
class AitAiChip {
    constructor() {
        inject(AitIconRegistry);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAiChip, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.25", type: AitAiChip, isStandalone: true, selector: "ait-ai-chip", host: { classAttribute: "ait-ai-chip" }, ngImport: i0, template: `
    <mat-chip class="dt-ai ait-ai" [disableRipple]="true">
      <mat-icon matChipAvatar svgIcon="ait:sparkle" aria-hidden="true" />
      <ng-content />
    </mat-chip>
  `, isInline: true, styles: [":host{display:inline-flex;vertical-align:middle}:host .mat-mdc-standard-chip.ait-ai{--mat-chip-with-avatar-avatar-size: 18px;--mat-chip-outline-width: 0;--mat-chip-elevated-container-color: var(--md-sys-color-ai-container);--mat-chip-label-text-color: var(--md-sys-color-on-ai-container);cursor:default}mat-icon{width:18px;height:18px;color:var(--md-sys-color-on-ai-container)}\n"], dependencies: [{ kind: "component", type: MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: MatChipAvatar, selector: "mat-chip-avatar, [matChipAvatar]" }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAiChip, decorators: [{
            type: Component,
            args: [{ selector: 'ait-ai-chip', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatChip, MatChipAvatar, MatIcon], host: { class: 'ait-ai-chip' }, template: `
    <mat-chip class="dt-ai ait-ai" [disableRipple]="true">
      <mat-icon matChipAvatar svgIcon="ait:sparkle" aria-hidden="true" />
      <ng-content />
    </mat-chip>
  `, styles: [":host{display:inline-flex;vertical-align:middle}:host .mat-mdc-standard-chip.ait-ai{--mat-chip-with-avatar-avatar-size: 18px;--mat-chip-outline-width: 0;--mat-chip-elevated-container-color: var(--md-sys-color-ai-container);--mat-chip-label-text-color: var(--md-sys-color-on-ai-container);cursor:default}mat-icon{width:18px;height:18px;color:var(--md-sys-color-on-ai-container)}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Empty or error state of a page, panel or table: the circle state mark (56–96 px), a title, the cause and the way out.
 * While the request is pending the same slot shows the pending ring, so nothing moves when it resolves.
 *
 * ```html
 * <ait-empty-state state="error" title="Runs could not load" cause="The run service did not answer in 10 s.">
 *   <button mat-flat-button (click)="retry()">Retry</button>
 * </ait-empty-state>
 * ```
 */
class AitEmptyState {
    state = input('info', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    title = input.required(...(ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []));
    cause = input('', ...(ngDevMode ? [{ debugName: "cause" }] : /* istanbul ignore next */ []));
    /** 56–64 inside a table or panel, 72–96 for a whole page. */
    size = input(64, { ...(ngDevMode ? { debugName: "size" } : /* istanbul ignore next */ {}), transform: numberAttribute });
    isPending = computed(() => this.state() === 'pending', ...(ngDevMode ? [{ debugName: "isPending" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitEmptyState, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitEmptyState, isStandalone: true, selector: "ait-empty-state", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, title: { classPropertyName: "title", publicName: "title", isSignal: true, isRequired: true, transformFunction: null }, cause: { classPropertyName: "cause", publicName: "cause", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.role": "state() === \"error\" ? \"alert\" : \"status\"", "attr.aria-busy": "state() === \"pending\" ? \"true\" : null" }, classAttribute: "ait-empty-state" }, ngImport: i0, template: `
    <ait-state-mark [state]="state()" variant="circle" [size]="size()" />
    <h2 class="title">{{ title() }}</h2>
    @if (cause()) {
      <p class="cause">{{ cause() }}</p>
    }
    <div class="actions"><ng-content /></div>
  `, isInline: true, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;padding:48px 24px}.title{margin:8px 0 0;font:var(--ait-type-title-medium);letter-spacing:var(--ait-type-title-medium-tracking);color:var(--md-sys-color-on-surface)}.cause{margin:0;max-width:480px;font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking);color:var(--md-sys-color-on-surface-variant)}.actions{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:8px}.actions:empty{display:none}\n"], dependencies: [{ kind: "component", type: AitStateMark, selector: "ait-state-mark", inputs: ["state", "variant", "size", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitEmptyState, decorators: [{
            type: Component,
            args: [{ selector: 'ait-empty-state', changeDetection: ChangeDetectionStrategy.OnPush, imports: [AitStateMark], host: {
                        class: 'ait-empty-state',
                        '[attr.role]': 'state() === "error" ? "alert" : "status"',
                        '[attr.aria-busy]': 'state() === "pending" ? "true" : null',
                    }, template: `
    <ait-state-mark [state]="state()" variant="circle" [size]="size()" />
    <h2 class="title">{{ title() }}</h2>
    @if (cause()) {
      <p class="cause">{{ cause() }}</p>
    }
    <div class="actions"><ng-content /></div>
  `, styles: [":host{display:flex;flex-direction:column;align-items:center;text-align:center;gap:8px;padding:48px 24px}.title{margin:8px 0 0;font:var(--ait-type-title-medium);letter-spacing:var(--ait-type-title-medium-tracking);color:var(--md-sys-color-on-surface)}.cause{margin:0;max-width:480px;font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking);color:var(--md-sys-color-on-surface-variant)}.actions{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:8px}.actions:empty{display:none}\n"] }]
        }], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }], title: [{ type: i0.Input, args: [{ isSignal: true, alias: "title", required: true }] }], cause: [{ type: i0.Input, args: [{ isSignal: true, alias: "cause", required: false }] }], size: [{ type: i0.Input, args: [{ isSignal: true, alias: "size", required: false }] }] } });

/**
 * Banner — an inline alert on the state container strip, led by the 28 px state mark (badge). Errors are announced
 * (`role="alert"`), the other states are polite (`role="status"`). Actions are projected text buttons marked `aitBannerAction`.
 *
 * ```html
 * <ait-banner state="warning" heading="Changes requested.">Revision 3 is queued as run-0150.</ait-banner>
 * ```
 */
class AitBanner {
    state = input('info', ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    heading = input('', ...(ngDevMode ? [{ debugName: "heading" }] : /* istanbul ignore next */ []));
    dismissible = input(false, { ...(ngDevMode ? { debugName: "dismissible" } : /* istanbul ignore next */ {}), transform: booleanAttribute });
    dismissed = output();
    constructor() {
        inject(AitIconRegistry);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitBanner, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitBanner, isStandalone: true, selector: "ait-banner", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null }, heading: { classPropertyName: "heading", publicName: "heading", isSignal: true, isRequired: false, transformFunction: null }, dismissible: { classPropertyName: "dismissible", publicName: "dismissible", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { dismissed: "dismissed" }, host: { properties: { "class": "\"ait-banner ait-banner--\" + state()", "attr.role": "state() === \"error\" ? \"alert\" : \"status\"" } }, ngImport: i0, template: `
    <ait-state-mark [state]="state()" variant="badge" [size]="28" />
    <div class="text">
      @if (heading()) {
        <span class="heading">{{ heading() }}</span>
      }
      <ng-content />
    </div>
    <div class="actions"><ng-content select="[aitBannerAction]" /></div>
    @if (dismissible()) {
      <button mat-icon-button type="button" class="close" aria-label="Dismiss" (click)="dismissed.emit()">
        <mat-icon svgIcon="ait:close" />
      </button>
    }
  `, isInline: true, styles: [":host{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:12px 16px;border-radius:12px;font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}:host(.ait-banner--success){background:var(--md-sys-color-success-container);color:var(--md-sys-color-on-success-container)}:host(.ait-banner--info){background:var(--md-sys-color-primary-container);color:var(--md-sys-color-on-primary-container)}:host(.ait-banner--warning){background:var(--md-sys-color-warning-container);color:var(--md-sys-color-on-warning-container)}:host(.ait-banner--error){background:var(--md-sys-color-error-container);color:var(--md-sys-color-on-error-container)}.text{flex:1 1 320px;min-width:0}.heading{font:var(--ait-type-title-small);letter-spacing:var(--ait-type-title-small-tracking);margin-right:4px}.actions{display:flex;gap:4px;--mat-button-text-label-text-color: currentColor}.actions:empty{display:none}.close{color:inherit;margin:-8px -8px -8px 0}\n"], dependencies: [{ kind: "component", type: AitStateMark, selector: "ait-state-mark", inputs: ["state", "variant", "size", "label"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitBanner, decorators: [{
            type: Component,
            args: [{ selector: 'ait-banner', changeDetection: ChangeDetectionStrategy.OnPush, imports: [AitStateMark, MatIconButton, MatIcon], host: {
                        '[class]': '"ait-banner ait-banner--" + state()',
                        '[attr.role]': 'state() === "error" ? "alert" : "status"',
                    }, template: `
    <ait-state-mark [state]="state()" variant="badge" [size]="28" />
    <div class="text">
      @if (heading()) {
        <span class="heading">{{ heading() }}</span>
      }
      <ng-content />
    </div>
    <div class="actions"><ng-content select="[aitBannerAction]" /></div>
    @if (dismissible()) {
      <button mat-icon-button type="button" class="close" aria-label="Dismiss" (click)="dismissed.emit()">
        <mat-icon svgIcon="ait:close" />
      </button>
    }
  `, styles: [":host{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:12px 16px;border-radius:12px;font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}:host(.ait-banner--success){background:var(--md-sys-color-success-container);color:var(--md-sys-color-on-success-container)}:host(.ait-banner--info){background:var(--md-sys-color-primary-container);color:var(--md-sys-color-on-primary-container)}:host(.ait-banner--warning){background:var(--md-sys-color-warning-container);color:var(--md-sys-color-on-warning-container)}:host(.ait-banner--error){background:var(--md-sys-color-error-container);color:var(--md-sys-color-on-error-container)}.text{flex:1 1 320px;min-width:0}.heading{font:var(--ait-type-title-small);letter-spacing:var(--ait-type-title-small-tracking);margin-right:4px}.actions{display:flex;gap:4px;--mat-button-text-label-text-color: currentColor}.actions:empty{display:none}.close{color:inherit;margin:-8px -8px -8px 0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }], heading: [{ type: i0.Input, args: [{ isSignal: true, alias: "heading", required: false }] }], dismissible: [{ type: i0.Input, args: [{ isSignal: true, alias: "dismissible", required: false }] }], dismissed: [{ type: i0.Output, args: ["dismissed"] }] } });

/** Content of the AIToolbox snackbar. Opened through AitSnackBar; not used directly. */
class AitSnackBarContent {
    data = inject(MAT_SNACK_BAR_DATA);
    ref = inject((MatSnackBarRef));
    constructor() {
        inject(AitIconRegistry);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSnackBarContent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitSnackBarContent, isStandalone: true, selector: "ait-snack-bar", host: { classAttribute: "ait-snack-bar" }, ngImport: i0, template: `
    @if (data.state) {
      <span class="ait-on-inverse mark"><ait-state-mark [state]="data.state" variant="badge" [size]="24" /></span>
    }
    <span class="message">{{ data.message }}</span>
    @if (data.action) {
      <button mat-button type="button" (click)="ref.dismissWithAction()">{{ data.action }}</button>
    }
    @if (data.closable) {
      <button mat-icon-button type="button" aria-label="Close" class="close" (click)="ref.dismiss()"><mat-icon svgIcon="ait:close" /></button>
    }
  `, isInline: true, styles: [":host{display:flex;align-items:center;gap:12px;min-height:40px;color:var(--md-sys-color-inverse-on-surface);font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}.mark{display:inline-flex}.message{flex:1}button{--mat-button-text-label-text-color: var(--md-sys-color-inverse-primary);flex:none}.close{color:var(--md-sys-color-inverse-on-surface)}\n"], dependencies: [{ kind: "component", type: AitStateMark, selector: "ait-state-mark", inputs: ["state", "variant", "size", "label"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSnackBarContent, decorators: [{
            type: Component,
            args: [{ selector: 'ait-snack-bar', changeDetection: ChangeDetectionStrategy.OnPush, imports: [AitStateMark, MatButton, MatIconButton, MatIcon], host: { class: 'ait-snack-bar' }, template: `
    @if (data.state) {
      <span class="ait-on-inverse mark"><ait-state-mark [state]="data.state" variant="badge" [size]="24" /></span>
    }
    <span class="message">{{ data.message }}</span>
    @if (data.action) {
      <button mat-button type="button" (click)="ref.dismissWithAction()">{{ data.action }}</button>
    }
    @if (data.closable) {
      <button mat-icon-button type="button" aria-label="Close" class="close" (click)="ref.dismiss()"><mat-icon svgIcon="ait:close" /></button>
    }
  `, styles: [":host{display:flex;align-items:center;gap:12px;min-height:40px;color:var(--md-sys-color-inverse-on-surface);font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}.mark{display:inline-flex}.message{flex:1}button{--mat-button-text-label-text-color: var(--md-sys-color-inverse-primary);flex:none}.close{color:var(--md-sys-color-inverse-on-surface)}\n"] }]
        }], ctorParameters: () => [] });
/**
 * Snackbar with the design-system anatomy: inverse surface, 24 px state mark, one action. Never for an error that needs
 * a decision (use a dialog), never stacked (opening one replaces the previous).
 *
 * ```ts
 * inject(AitSnackBar).open('Design approved · implement Run requested', { state: 'success', action: 'View design' });
 * ```
 */
class AitSnackBar {
    snackBar = inject(MatSnackBar);
    open(message, options = {}) {
        const duration = options.duration ?? (options.action ? 10000 : 6000);
        return this.snackBar.openFromComponent(AitSnackBarContent, {
            data: { message, ...options },
            duration,
            panelClass: 'ait-snackbar-panel',
            politeness: options.state === 'error' ? 'assertive' : 'polite',
        });
    }
    dismiss() {
        this.snackBar.dismiss();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSnackBar, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSnackBar, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSnackBar, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Dialog title with the optional 32 px state mark of a state-driven popin (destructive confirm, warning).
 * `<h2 mat-dialog-title aitDialogTitle state="warning">Cancel run-0147?</h2>`
 */
class AitDialogTitle {
    state = input(undefined, ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDialogTitle, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitDialogTitle, isStandalone: true, selector: "[aitDialogTitle]", inputs: { state: { classPropertyName: "state", publicName: "state", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "ait-dialog-title" }, ngImport: i0, template: `
    @if (state()) {
      <ait-state-mark [state]="state()!" variant="badge" [size]="32" />
    }
    <span><ng-content /></span>
  `, isInline: true, styles: [":host{display:flex!important;align-items:center;gap:12px}\n"], dependencies: [{ kind: "component", type: AitStateMark, selector: "ait-state-mark", inputs: ["state", "variant", "size", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDialogTitle, decorators: [{
            type: Component,
            args: [{ selector: '[aitDialogTitle]', changeDetection: ChangeDetectionStrategy.OnPush, imports: [AitStateMark], host: { class: 'ait-dialog-title' }, template: `
    @if (state()) {
      <ait-state-mark [state]="state()!" variant="badge" [size]="32" />
    }
    <span><ng-content /></span>
  `, styles: [":host{display:flex!important;align-items:center;gap:12px}\n"] }]
        }], propDecorators: { state: [{ type: i0.Input, args: [{ isSignal: true, alias: "state", required: false }] }] } });
class AitConfirmDialog {
    data = inject(MAT_DIALOG_DATA);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConfirmDialog, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitConfirmDialog, isStandalone: true, selector: "ait-confirm-dialog", ngImport: i0, template: `
    <h2 mat-dialog-title aitDialogTitle [state]="data.state ?? (data.destructive ? 'warning' : undefined)">{{ data.title }}</h2>
    <mat-dialog-content><p class="message">{{ data.message }}</p></mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" [mat-dialog-close]="false" cdkFocusInitial>{{ data.dismissLabel ?? 'Cancel' }}</button>
      @if (data.destructive) {
        <button mat-button aitDanger type="button" [mat-dialog-close]="true">{{ data.confirmLabel }}</button>
      } @else {
        <button mat-flat-button type="button" [mat-dialog-close]="true">{{ data.confirmLabel }}</button>
      }
    </mat-dialog-actions>
  `, isInline: true, styles: [".message{margin:0;color:var(--md-sys-color-on-surface-variant)}\n"], dependencies: [{ kind: "directive", type: MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "directive", type: MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "component", type: MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: AitDialogTitle, selector: "[aitDialogTitle]", inputs: ["state"] }, { kind: "directive", type: AitDanger, selector: "[aitDanger]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConfirmDialog, decorators: [{
            type: Component,
            args: [{ selector: 'ait-confirm-dialog', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatDialogTitle, MatDialogContent, MatDialogActions, MatDialogClose, MatButton, AitDialogTitle, AitDanger], template: `
    <h2 mat-dialog-title aitDialogTitle [state]="data.state ?? (data.destructive ? 'warning' : undefined)">{{ data.title }}</h2>
    <mat-dialog-content><p class="message">{{ data.message }}</p></mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button type="button" [mat-dialog-close]="false" cdkFocusInitial>{{ data.dismissLabel ?? 'Cancel' }}</button>
      @if (data.destructive) {
        <button mat-button aitDanger type="button" [mat-dialog-close]="true">{{ data.confirmLabel }}</button>
      } @else {
        <button mat-flat-button type="button" [mat-dialog-close]="true">{{ data.confirmLabel }}</button>
      }
    </mat-dialog-actions>
  `, styles: [".message{margin:0;color:var(--md-sys-color-on-surface-variant)}\n"] }]
        }] });
/**
 * Confirmation dialogs with the design-system rules: 280–560 px, headline-small title, text dismiss, filled primary
 * confirm, text-in-error confirm when destructive; focus starts on the dismiss button.
 *
 * ```ts
 * this.confirm.open({ title: 'Cancel run-0147?', message: '…', confirmLabel: 'Cancel Run', destructive: true })
 *   .subscribe(ok => ok && this.cancel());
 * ```
 */
class AitConfirm {
    dialog = inject(MatDialog);
    windowClass = inject(AitWindowClass);
    open(options) {
        return this.dialog
            .open(AitConfirmDialog, {
            data: options,
            width: '560px',
            maxWidth: this.windowClass.isCompact() ? 'calc(100vw - 32px)' : '560px',
            minWidth: '280px',
            autoFocus: 'first-tabbable',
            role: options.destructive ? 'alertdialog' : 'dialog',
        })
            .afterClosed()
            .pipe(map((v) => v === true));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConfirm, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConfirm, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitConfirm, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Disabled reason (Tooltip E) — why an action is unavailable and how to unlock it, two lines at most, ending with the way
 * out. Pair it with Material's `disabledInteractive` so the button stays focusable and keyboard users get the reason:
 *
 * ```html
 * <button mat-flat-button disabled disabledInteractive aitDisabledReason="Choose a variant for every decision first.">
 *   Approve design
 * </button>
 * ```
 * The reason is also the button's accessible description (MatTooltip registers it with aria-describedby).
 */
class AitDisabledReason {
    aitDisabledReason = input.required(...(ngDevMode ? [{ debugName: "aitDisabledReason" }] : /* istanbul ignore next */ []));
    aitDisabledReasonPosition = input('above', ...(ngDevMode ? [{ debugName: "aitDisabledReasonPosition" }] : /* istanbul ignore next */ []));
    constructor() {
        // Design-system timing: 500 ms show delay on hover (immediate on keyboard focus is Material's default), 150 ms hide.
        const tooltip = inject(MatTooltip);
        tooltip.showDelay = 500;
        tooltip.hideDelay = 150;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDisabledReason, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "21.2.25", type: AitDisabledReason, isStandalone: true, selector: "[aitDisabledReason]", inputs: { aitDisabledReason: { classPropertyName: "aitDisabledReason", publicName: "aitDisabledReason", isSignal: true, isRequired: true, transformFunction: null }, aitDisabledReasonPosition: { classPropertyName: "aitDisabledReasonPosition", publicName: "aitDisabledReasonPosition", isSignal: true, isRequired: false, transformFunction: null } }, hostDirectives: [{ directive: i1.MatTooltip, inputs: ["matTooltip", "aitDisabledReason", "matTooltipPosition", "aitDisabledReasonPosition"] }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitDisabledReason, decorators: [{
            type: Directive,
            args: [{
                    selector: '[aitDisabledReason]',
                    hostDirectives: [{ directive: MatTooltip, inputs: ['matTooltip: aitDisabledReason', 'matTooltipPosition: aitDisabledReasonPosition'] }],
                }]
        }], ctorParameters: () => [], propDecorators: { aitDisabledReason: [{ type: i0.Input, args: [{ isSignal: true, alias: "aitDisabledReason", required: true }] }], aitDisabledReasonPosition: [{ type: i0.Input, args: [{ isSignal: true, alias: "aitDisabledReasonPosition", required: false }] }] } });

const AIT_SHELL = new InjectionToken('AIT_SHELL');

/**
 * Search-or-ask field of the app header: 44 px, radius 16, on surface-container-lowest (light) / -high (dark).
 * Enter searches; the Ask chip (ai-container + Chatbot mark) sends the text to the assistant. ⌘K / Ctrl+K focuses it.
 * `compactAsk` shows the Ask chip as an icon (Medium and Expanded windows).
 */
class AitSearchAsk {
    placeholder = input('Search, or ask the assistant…', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Ask chip as a 36 px icon (Medium and Expanded windows). */
    compactAsk = input(false, ...(ngDevMode ? [{ debugName: "compactAsk" }] : /* istanbul ignore next */ []));
    /** When set, the Ask chip is disabled with this reason (Tooltip E). */
    askDisabledReason = input('', ...(ngDevMode ? [{ debugName: "askDisabledReason" }] : /* istanbul ignore next */ []));
    query = model('', ...(ngDevMode ? [{ debugName: "query" }] : /* istanbul ignore next */ []));
    search = output();
    ask = output();
    uid = aitUid('ait-search');
    shortcut = typeof navigator !== 'undefined' && /Mac|iP(hone|ad)/.test(navigator.platform) ? '⌘K' : 'Ctrl K';
    field = viewChild.required('field');
    constructor() {
        inject(AitIconRegistry);
    }
    /** Moves focus into the field. */
    focus() {
        this.field().nativeElement.focus();
    }
    onAsk() {
        if (!this.askDisabledReason())
            this.ask.emit(this.field().nativeElement.value);
    }
    onDocumentKey(e) {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
            e.preventDefault();
            this.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSearchAsk, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitSearchAsk, isStandalone: true, selector: "ait-search-ask", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, compactAsk: { classPropertyName: "compactAsk", publicName: "compactAsk", isSignal: true, isRequired: false, transformFunction: null }, askDisabledReason: { classPropertyName: "askDisabledReason", publicName: "askDisabledReason", isSignal: true, isRequired: false, transformFunction: null }, query: { classPropertyName: "query", publicName: "query", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { query: "queryChange", search: "search", ask: "ask" }, host: { attributes: { "role": "search" }, listeners: { "document:keydown": "onDocumentKey($event)" }, classAttribute: "ait-search-ask" }, viewQueries: [{ propertyName: "field", first: true, predicate: ["field"], descendants: true, isSignal: true }], ngImport: i0, template: `
    <mat-icon svgIcon="ait:search" class="lead" aria-hidden="true" />
    <label [attr.for]="uid" class="ait-visually-hidden">{{ placeholder() }}</label>
    <input #field [id]="uid" type="search" [placeholder]="placeholder()" [value]="query()" autocomplete="off"
      (input)="query.set(field.value)" (keydown.enter)="search.emit(field.value)" />
    <kbd class="shortcut" aria-hidden="true">{{ shortcut }}</kbd>
    <button type="button" class="ask" [class.ask--icon]="compactAsk()" [attr.aria-label]="compactAsk() ? 'Ask the assistant' : null"
      [matTooltip]="askDisabledReason() || (compactAsk() ? 'Ask the assistant' : '')" [attr.aria-disabled]="askDisabledReason() ? 'true' : null"
      (click)="onAsk()">
      <ait-chatbot-mark [size]="24" />
      @if (!compactAsk()) { <span>Ask</span> }
    </button>
  `, isInline: true, styles: [":host{display:flex;align-items:center;gap:10px;height:44px;padding:0 6px 0 14px;box-sizing:border-box;border-radius:16px;background:light-dark(var(--md-sys-color-surface-container-lowest),var(--md-sys-color-surface-container-high));color:var(--md-sys-color-on-surface-variant);min-width:0}:host:focus-within{box-shadow:inset 0 0 0 2px var(--md-sys-color-primary)}.lead{width:22px;height:22px;flex:none}input{flex:1;min-width:0;height:100%;border:0;outline:none;background:transparent;color:var(--md-sys-color-on-surface);font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}input::placeholder{color:var(--md-sys-color-on-surface-variant)}input::-webkit-search-cancel-button{display:none}.shortcut{font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;padding:0 6px;border-radius:4px;border:1px solid var(--md-sys-color-outline-variant);color:var(--md-sys-color-on-surface-variant)}.ask{display:inline-flex;align-items:center;gap:4px;height:32px;padding:0 12px 0 4px;border:0;border-radius:12px;cursor:pointer;background:var(--md-sys-color-ai-container);color:var(--md-sys-color-on-ai-container);font:var(--ait-type-label-medium);letter-spacing:.5px;flex:none}.ask:hover{box-shadow:inset 0 0 0 100px color-mix(in srgb,var(--md-sys-color-on-ai-container) 6%,transparent)}.ask--icon{width:36px;padding:0;justify-content:center}.ask[aria-disabled=true]{opacity:.5;cursor:not-allowed}\n"], dependencies: [{ kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: AitChatbotMark, selector: "ait-chatbot-mark", inputs: ["size", "label"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitSearchAsk, decorators: [{
            type: Component,
            args: [{ selector: 'ait-search-ask', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIcon, MatTooltip, AitChatbotMark], host: {
                        class: 'ait-search-ask',
                        role: 'search',
                        '(document:keydown)': 'onDocumentKey($event)',
                    }, template: `
    <mat-icon svgIcon="ait:search" class="lead" aria-hidden="true" />
    <label [attr.for]="uid" class="ait-visually-hidden">{{ placeholder() }}</label>
    <input #field [id]="uid" type="search" [placeholder]="placeholder()" [value]="query()" autocomplete="off"
      (input)="query.set(field.value)" (keydown.enter)="search.emit(field.value)" />
    <kbd class="shortcut" aria-hidden="true">{{ shortcut }}</kbd>
    <button type="button" class="ask" [class.ask--icon]="compactAsk()" [attr.aria-label]="compactAsk() ? 'Ask the assistant' : null"
      [matTooltip]="askDisabledReason() || (compactAsk() ? 'Ask the assistant' : '')" [attr.aria-disabled]="askDisabledReason() ? 'true' : null"
      (click)="onAsk()">
      <ait-chatbot-mark [size]="24" />
      @if (!compactAsk()) { <span>Ask</span> }
    </button>
  `, styles: [":host{display:flex;align-items:center;gap:10px;height:44px;padding:0 6px 0 14px;box-sizing:border-box;border-radius:16px;background:light-dark(var(--md-sys-color-surface-container-lowest),var(--md-sys-color-surface-container-high));color:var(--md-sys-color-on-surface-variant);min-width:0}:host:focus-within{box-shadow:inset 0 0 0 2px var(--md-sys-color-primary)}.lead{width:22px;height:22px;flex:none}input{flex:1;min-width:0;height:100%;border:0;outline:none;background:transparent;color:var(--md-sys-color-on-surface);font:var(--ait-type-body-medium);letter-spacing:var(--ait-type-body-medium-tracking)}input::placeholder{color:var(--md-sys-color-on-surface-variant)}input::-webkit-search-cancel-button{display:none}.shortcut{font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;padding:0 6px;border-radius:4px;border:1px solid var(--md-sys-color-outline-variant);color:var(--md-sys-color-on-surface-variant)}.ask{display:inline-flex;align-items:center;gap:4px;height:32px;padding:0 12px 0 4px;border:0;border-radius:12px;cursor:pointer;background:var(--md-sys-color-ai-container);color:var(--md-sys-color-on-ai-container);font:var(--ait-type-label-medium);letter-spacing:.5px;flex:none}.ask:hover{box-shadow:inset 0 0 0 100px color-mix(in srgb,var(--md-sys-color-on-ai-container) 6%,transparent)}.ask--icon{width:36px;padding:0;justify-content:center}.ask[aria-disabled=true]{opacity:.5;cursor:not-allowed}\n"] }]
        }], ctorParameters: () => [], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], compactAsk: [{ type: i0.Input, args: [{ isSignal: true, alias: "compactAsk", required: false }] }], askDisabledReason: [{ type: i0.Input, args: [{ isSignal: true, alias: "askDisabledReason", required: false }] }], query: [{ type: i0.Input, args: [{ isSignal: true, alias: "query", required: false }] }, { type: i0.Output, args: ["queryChange"] }], search: [{ type: i0.Output, args: ["search"] }], ask: [{ type: i0.Output, args: ["ask"] }], field: [{ type: i0.ViewChild, args: ['field', { isSignal: true }] }] } });

/**
 * App header (TopAppBar) of the AIToolbox shell, on nav-container like the drawer. Left to right: logo · search-or-ask
 * field centred · assistant · notifications · help · user chip. Follows the window class:
 * under 600 px 56 px with menu · mark · search icon · bell · avatar; 600–1199 px search flexes, Ask as an icon, avatar
 * only (help from 840 px); from 1200 px 600 px search, labelled Ask, user chip with name and role.
 * ⌘J / Ctrl+J toggles the assistant.
 */
class AitAppHeader {
    windowClass = inject(AitWindowClass);
    shell = inject(AIT_SHELL, { optional: true });
    searchField = viewChild(AitSearchAsk, ...(ngDevMode ? [{ debugName: "searchField" }] : /* istanbul ignore next */ []));
    user = input.required(...(ngDevMode ? [{ debugName: "user" }] : /* istanbul ignore next */ []));
    notificationCount = input(0, ...(ngDevMode ? [{ debugName: "notificationCount" }] : /* istanbul ignore next */ []));
    assistant = input('idle', ...(ngDevMode ? [{ debugName: "assistant" }] : /* istanbul ignore next */ []));
    assistantOpen = input(false, ...(ngDevMode ? [{ debugName: "assistantOpen" }] : /* istanbul ignore next */ []));
    searchPlaceholder = input('Search, or ask the assistant…', ...(ngDevMode ? [{ debugName: "searchPlaceholder" }] : /* istanbul ignore next */ []));
    askDisabledReason = input('', ...(ngDevMode ? [{ debugName: "askDisabledReason" }] : /* istanbul ignore next */ []));
    homeLink = input('/', ...(ngDevMode ? [{ debugName: "homeLink" }] : /* istanbul ignore next */ []));
    search = output();
    ask = output();
    /** Compact windows: the search icon was pressed (open the full-screen search view). */
    searchOpen = output();
    assistantToggle = output();
    notificationsClick = output();
    helpClick = output();
    userMenuAction = output();
    /** Compact windows: the menu button was pressed. The AppShell opens its drawer by itself. */
    menuClick = output();
    compact = this.windowClass.isCompact;
    wide = computed(() => ['large', 'extra-large'].includes(this.windowClass.windowClass()), ...(ngDevMode ? [{ debugName: "wide" }] : /* istanbul ignore next */ []));
    showHelp = computed(() => !['compact', 'medium'].includes(this.windowClass.windowClass()), ...(ngDevMode ? [{ debugName: "showHelp" }] : /* istanbul ignore next */ []));
    shortcutJ = typeof navigator !== 'undefined' && /Mac|iP(hone|ad)/.test(navigator.platform) ? '⌘J' : 'Ctrl+J';
    initials = computed(() => {
        const u = this.user();
        return (u.initials ?? u.name.split(/\s+/).map((p) => p[0]).join('').slice(0, 2)).toUpperCase();
    }, ...(ngDevMode ? [{ debugName: "initials" }] : /* istanbul ignore next */ []));
    badge = computed(() => {
        const n = this.notificationCount();
        return n <= 0 ? '' : n <= 9 ? String(n) : n <= 99 ? '9+' : '99+';
    }, ...(ngDevMode ? [{ debugName: "badge" }] : /* istanbul ignore next */ []));
    bellLabel = computed(() => (this.notificationCount() > 0 ? `Notifications, ${this.notificationCount()} unread` : 'Notifications'), ...(ngDevMode ? [{ debugName: "bellLabel" }] : /* istanbul ignore next */ []));
    assistantLabel = computed(() => {
        const base = this.assistantOpen() ? 'Close assistant' : 'Open assistant';
        return this.assistant() === 'waiting' ? `${base}, answer ready` : this.assistant() === 'typing' ? `${base}, writing an answer` : base;
    }, ...(ngDevMode ? [{ debugName: "assistantLabel" }] : /* istanbul ignore next */ []));
    userLabel = computed(() => `${this.user().name}${this.user().role ? ', ' + this.user().role : ''}, account menu`, ...(ngDevMode ? [{ debugName: "userLabel" }] : /* istanbul ignore next */ []));
    constructor() {
        inject(AitIconRegistry);
    }
    /** Moves focus into the search field (also bound to ⌘K / Ctrl+K). */
    focusSearch() {
        this.searchField()?.focus();
    }
    openNavigation() {
        this.menuClick.emit();
        this.shell?.openDrawer();
    }
    onDocumentKey(e) {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'j') {
            e.preventDefault();
            this.assistantToggle.emit();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAppHeader, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitAppHeader, isStandalone: true, selector: "ait-app-header", inputs: { user: { classPropertyName: "user", publicName: "user", isSignal: true, isRequired: true, transformFunction: null }, notificationCount: { classPropertyName: "notificationCount", publicName: "notificationCount", isSignal: true, isRequired: false, transformFunction: null }, assistant: { classPropertyName: "assistant", publicName: "assistant", isSignal: true, isRequired: false, transformFunction: null }, assistantOpen: { classPropertyName: "assistantOpen", publicName: "assistantOpen", isSignal: true, isRequired: false, transformFunction: null }, searchPlaceholder: { classPropertyName: "searchPlaceholder", publicName: "searchPlaceholder", isSignal: true, isRequired: false, transformFunction: null }, askDisabledReason: { classPropertyName: "askDisabledReason", publicName: "askDisabledReason", isSignal: true, isRequired: false, transformFunction: null }, homeLink: { classPropertyName: "homeLink", publicName: "homeLink", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { search: "search", ask: "ask", searchOpen: "searchOpen", assistantToggle: "assistantToggle", notificationsClick: "notificationsClick", helpClick: "helpClick", userMenuAction: "userMenuAction", menuClick: "menuClick" }, host: { attributes: { "role": "banner" }, listeners: { "document:keydown": "onDocumentKey($event)" }, properties: { "class.ait-app-header--compact": "compact()" }, classAttribute: "ait-app-header dt-nav" }, viewQueries: [{ propertyName: "searchField", first: true, predicate: AitSearchAsk, descendants: true, isSignal: true }], ngImport: i0, template: `
    <div class="start">
      @if (compact()) {
        <button mat-icon-button type="button" aria-label="Open navigation" (click)="openNavigation()"><mat-icon svgIcon="ait:menu" /></button>
        <a [routerLink]="homeLink()" class="home" aria-label="AIToolbox home"><ait-logo variant="mark" [size]="28" label="" /></a>
      } @else {
        <a [routerLink]="homeLink()" class="home"><ait-logo variant="horizontal" [size]="44" label="AIToolbox home" /></a>
      }
    </div>

    @if (!compact()) {
      <ait-search-ask class="search" [compactAsk]="!wide()" [placeholder]="searchPlaceholder()" [askDisabledReason]="askDisabledReason()"
        (search)="search.emit($event)" (ask)="ask.emit($event)" />
    }

    <div class="end">
      @if (compact()) {
        <button mat-icon-button type="button" aria-label="Search" (click)="searchOpen.emit()"><mat-icon svgIcon="ait:search" /></button>
      } @else {
        <button mat-icon-button type="button" class="assistant" [class.assistant--open]="assistantOpen()" [attr.aria-expanded]="assistantOpen()"
          [attr.aria-label]="assistantLabel()" [matTooltip]="(assistantOpen() ? 'Close' : 'Open') + ' assistant ' + shortcutJ" (click)="assistantToggle.emit()">
          <ait-chatbot-mark [size]="24" />
          @if (assistant() === 'typing') { <ait-working-dots kind="ai" class="assistant__dots" label="" aria-hidden="true" /> }
          @if (assistant() === 'waiting') { <span class="assistant__dot" aria-hidden="true"></span> }
        </button>
      }
      <button mat-icon-button type="button" class="bell" [attr.aria-label]="bellLabel()" matTooltip="Notifications" (click)="notificationsClick.emit()">
        <svg viewBox="0 0 64 64" width="24" height="24" aria-hidden="true" focusable="false">
          <circle cx="32" cy="8" r="3.6" class="bell__body" />
          <path d="M32 9C22 9 17 17 17 27V38L12 46Q11 48.5 13.5 48.5H50.5Q53 48.5 52 46L47 38V27C47 17 42 9 32 9Z" class="bell__body" />
          <circle cx="32" cy="53.5" r="5" class="bell__clapper" />
        </svg>
        @if (badge()) { <span class="badge" aria-hidden="true">{{ badge() }}</span> }
      </button>
      @if (showHelp()) {
        <button mat-icon-button type="button" aria-label="Help" matTooltip="Help" (click)="helpClick.emit()"><mat-icon svgIcon="ait:help" /></button>
      }
      @if (!compact()) { <span class="divider" aria-hidden="true"></span> }
      <button type="button" class="user" [matMenuTriggerFor]="userMenu" aria-haspopup="menu" [attr.aria-label]="userLabel()">
        <span class="avatar">{{ initials() }}</span>
        @if (wide()) {
          <span class="user__text"><span class="user__name">{{ user().name }}</span>
            @if (user().role) { <span class="user__role">{{ user().role }}</span> }</span>
          <mat-icon svgIcon="ait:chevron-down" class="user__chev" />
        }
      </button>
      <mat-menu #userMenu="matMenu" xPosition="before">
        <button mat-menu-item (click)="userMenuAction.emit('account')"><mat-icon svgIcon="ait:person" />Account</button>
        <button mat-menu-item (click)="userMenuAction.emit('notifications')"><mat-icon svgIcon="ait:bell" />Notification preferences</button>
        <button mat-menu-item (click)="userMenuAction.emit('tokens')"><mat-icon svgIcon="ait:key" />API tokens</button>
        <button mat-menu-item (click)="userMenuAction.emit('theme')"><mat-icon svgIcon="ait:palette" />Theme</button>
        @if (!showHelp()) {
          <button mat-menu-item (click)="helpClick.emit()"><mat-icon svgIcon="ait:help" />Help</button>
        }
        <mat-divider />
        <button mat-menu-item (click)="userMenuAction.emit('sign-out')"><mat-icon svgIcon="ait:logout" />Sign out</button>
      </mat-menu>
    </div>
  `, isInline: true, styles: [":host{display:grid;grid-template-columns:minmax(max-content,1fr) minmax(240px,600px) minmax(max-content,1fr);align-items:center;gap:12px;height:64px;padding:0 8px 0 12px;box-sizing:border-box;background:var(--md-sys-color-nav-container);color:var(--md-sys-color-on-surface);position:relative;z-index:3}:host(.ait-app-header--compact){grid-template-columns:1fr auto;height:56px;padding:0 4px}.start{display:flex;align-items:center;gap:4px;justify-self:start;min-width:0}.home{display:inline-flex;border-radius:8px}.search{min-width:0}.end{display:flex;align-items:center;justify-self:end;gap:0}button[mat-icon-button]{color:var(--md-sys-color-on-surface-variant);position:relative}.assistant--open{background:var(--md-sys-color-nav-active)}.assistant__dots{position:absolute;bottom:2px;left:50%;transform:translate(-50%) scale(.6)}.assistant__dot{position:absolute;top:8px;right:8px;width:8px;height:8px;border-radius:9999px;background:var(--md-sys-color-tertiary);box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.bell__body{fill:var(--md-sys-color-primary)}.bell__clapper{fill:var(--md-sys-color-ai)}.badge{position:absolute;top:4px;left:22px;min-width:16px;height:16px;padding:0 4px;box-sizing:border-box;border-radius:9999px;background:var(--md-sys-color-error);color:var(--md-sys-color-on-error);font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;text-align:center;box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.divider{width:1px;height:24px;background:var(--md-sys-color-outline-variant);margin:0 6px}.user{display:inline-flex;align-items:center;gap:8px;height:48px;padding:0 8px 0 4px;border:0;border-radius:16px;background:transparent;color:inherit;cursor:pointer;text-align:left}.user:hover{background:color-mix(in srgb,var(--md-sys-color-primary) 6%,transparent)}.avatar{width:32px;height:32px;border-radius:9999px;background:var(--md-sys-color-nav-active);color:var(--md-sys-color-on-secondary-container);display:inline-flex;align-items:center;justify-content:center;font:var(--ait-type-label-large);flex:none}.user__text{display:flex;flex-direction:column;line-height:1.15}.user__name{font:var(--ait-type-title-small);letter-spacing:.1px}.user__role{font:var(--ait-type-body-small);color:var(--md-sys-color-on-surface-variant)}.user__chev{width:18px;height:18px;color:var(--md-sys-color-on-surface-variant)}\n"], dependencies: [{ kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "component", type: AitLogo, selector: "ait-logo", inputs: ["variant", "size", "label"] }, { kind: "component", type: AitChatbotMark, selector: "ait-chatbot-mark", inputs: ["size", "label"] }, { kind: "component", type: AitWorkingDots, selector: "ait-working-dots", inputs: ["kind", "label"] }, { kind: "component", type: AitSearchAsk, selector: "ait-search-ask", inputs: ["placeholder", "compactAsk", "askDisabledReason", "query"], outputs: ["queryChange", "search", "ask"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAppHeader, decorators: [{
            type: Component,
            args: [{ selector: 'ait-app-header', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatIconButton, MatIcon, MatMenu, MatMenuItem, MatMenuTrigger, MatDivider, MatTooltip, RouterLink, AitLogo, AitChatbotMark, AitWorkingDots, AitSearchAsk], host: {
                        class: 'ait-app-header dt-nav',
                        role: 'banner',
                        '[class.ait-app-header--compact]': 'compact()',
                        '(document:keydown)': 'onDocumentKey($event)',
                    }, template: `
    <div class="start">
      @if (compact()) {
        <button mat-icon-button type="button" aria-label="Open navigation" (click)="openNavigation()"><mat-icon svgIcon="ait:menu" /></button>
        <a [routerLink]="homeLink()" class="home" aria-label="AIToolbox home"><ait-logo variant="mark" [size]="28" label="" /></a>
      } @else {
        <a [routerLink]="homeLink()" class="home"><ait-logo variant="horizontal" [size]="44" label="AIToolbox home" /></a>
      }
    </div>

    @if (!compact()) {
      <ait-search-ask class="search" [compactAsk]="!wide()" [placeholder]="searchPlaceholder()" [askDisabledReason]="askDisabledReason()"
        (search)="search.emit($event)" (ask)="ask.emit($event)" />
    }

    <div class="end">
      @if (compact()) {
        <button mat-icon-button type="button" aria-label="Search" (click)="searchOpen.emit()"><mat-icon svgIcon="ait:search" /></button>
      } @else {
        <button mat-icon-button type="button" class="assistant" [class.assistant--open]="assistantOpen()" [attr.aria-expanded]="assistantOpen()"
          [attr.aria-label]="assistantLabel()" [matTooltip]="(assistantOpen() ? 'Close' : 'Open') + ' assistant ' + shortcutJ" (click)="assistantToggle.emit()">
          <ait-chatbot-mark [size]="24" />
          @if (assistant() === 'typing') { <ait-working-dots kind="ai" class="assistant__dots" label="" aria-hidden="true" /> }
          @if (assistant() === 'waiting') { <span class="assistant__dot" aria-hidden="true"></span> }
        </button>
      }
      <button mat-icon-button type="button" class="bell" [attr.aria-label]="bellLabel()" matTooltip="Notifications" (click)="notificationsClick.emit()">
        <svg viewBox="0 0 64 64" width="24" height="24" aria-hidden="true" focusable="false">
          <circle cx="32" cy="8" r="3.6" class="bell__body" />
          <path d="M32 9C22 9 17 17 17 27V38L12 46Q11 48.5 13.5 48.5H50.5Q53 48.5 52 46L47 38V27C47 17 42 9 32 9Z" class="bell__body" />
          <circle cx="32" cy="53.5" r="5" class="bell__clapper" />
        </svg>
        @if (badge()) { <span class="badge" aria-hidden="true">{{ badge() }}</span> }
      </button>
      @if (showHelp()) {
        <button mat-icon-button type="button" aria-label="Help" matTooltip="Help" (click)="helpClick.emit()"><mat-icon svgIcon="ait:help" /></button>
      }
      @if (!compact()) { <span class="divider" aria-hidden="true"></span> }
      <button type="button" class="user" [matMenuTriggerFor]="userMenu" aria-haspopup="menu" [attr.aria-label]="userLabel()">
        <span class="avatar">{{ initials() }}</span>
        @if (wide()) {
          <span class="user__text"><span class="user__name">{{ user().name }}</span>
            @if (user().role) { <span class="user__role">{{ user().role }}</span> }</span>
          <mat-icon svgIcon="ait:chevron-down" class="user__chev" />
        }
      </button>
      <mat-menu #userMenu="matMenu" xPosition="before">
        <button mat-menu-item (click)="userMenuAction.emit('account')"><mat-icon svgIcon="ait:person" />Account</button>
        <button mat-menu-item (click)="userMenuAction.emit('notifications')"><mat-icon svgIcon="ait:bell" />Notification preferences</button>
        <button mat-menu-item (click)="userMenuAction.emit('tokens')"><mat-icon svgIcon="ait:key" />API tokens</button>
        <button mat-menu-item (click)="userMenuAction.emit('theme')"><mat-icon svgIcon="ait:palette" />Theme</button>
        @if (!showHelp()) {
          <button mat-menu-item (click)="helpClick.emit()"><mat-icon svgIcon="ait:help" />Help</button>
        }
        <mat-divider />
        <button mat-menu-item (click)="userMenuAction.emit('sign-out')"><mat-icon svgIcon="ait:logout" />Sign out</button>
      </mat-menu>
    </div>
  `, styles: [":host{display:grid;grid-template-columns:minmax(max-content,1fr) minmax(240px,600px) minmax(max-content,1fr);align-items:center;gap:12px;height:64px;padding:0 8px 0 12px;box-sizing:border-box;background:var(--md-sys-color-nav-container);color:var(--md-sys-color-on-surface);position:relative;z-index:3}:host(.ait-app-header--compact){grid-template-columns:1fr auto;height:56px;padding:0 4px}.start{display:flex;align-items:center;gap:4px;justify-self:start;min-width:0}.home{display:inline-flex;border-radius:8px}.search{min-width:0}.end{display:flex;align-items:center;justify-self:end;gap:0}button[mat-icon-button]{color:var(--md-sys-color-on-surface-variant);position:relative}.assistant--open{background:var(--md-sys-color-nav-active)}.assistant__dots{position:absolute;bottom:2px;left:50%;transform:translate(-50%) scale(.6)}.assistant__dot{position:absolute;top:8px;right:8px;width:8px;height:8px;border-radius:9999px;background:var(--md-sys-color-tertiary);box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.bell__body{fill:var(--md-sys-color-primary)}.bell__clapper{fill:var(--md-sys-color-ai)}.badge{position:absolute;top:4px;left:22px;min-width:16px;height:16px;padding:0 4px;box-sizing:border-box;border-radius:9999px;background:var(--md-sys-color-error);color:var(--md-sys-color-on-error);font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;text-align:center;box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.divider{width:1px;height:24px;background:var(--md-sys-color-outline-variant);margin:0 6px}.user{display:inline-flex;align-items:center;gap:8px;height:48px;padding:0 8px 0 4px;border:0;border-radius:16px;background:transparent;color:inherit;cursor:pointer;text-align:left}.user:hover{background:color-mix(in srgb,var(--md-sys-color-primary) 6%,transparent)}.avatar{width:32px;height:32px;border-radius:9999px;background:var(--md-sys-color-nav-active);color:var(--md-sys-color-on-secondary-container);display:inline-flex;align-items:center;justify-content:center;font:var(--ait-type-label-large);flex:none}.user__text{display:flex;flex-direction:column;line-height:1.15}.user__name{font:var(--ait-type-title-small);letter-spacing:.1px}.user__role{font:var(--ait-type-body-small);color:var(--md-sys-color-on-surface-variant)}.user__chev{width:18px;height:18px;color:var(--md-sys-color-on-surface-variant)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { searchField: [{ type: i0.ViewChild, args: [i0.forwardRef(() => AitSearchAsk), { isSignal: true }] }], user: [{ type: i0.Input, args: [{ isSignal: true, alias: "user", required: true }] }], notificationCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "notificationCount", required: false }] }], assistant: [{ type: i0.Input, args: [{ isSignal: true, alias: "assistant", required: false }] }], assistantOpen: [{ type: i0.Input, args: [{ isSignal: true, alias: "assistantOpen", required: false }] }], searchPlaceholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "searchPlaceholder", required: false }] }], askDisabledReason: [{ type: i0.Input, args: [{ isSignal: true, alias: "askDisabledReason", required: false }] }], homeLink: [{ type: i0.Input, args: [{ isSignal: true, alias: "homeLink", required: false }] }], search: [{ type: i0.Output, args: ["search"] }], ask: [{ type: i0.Output, args: ["ask"] }], searchOpen: [{ type: i0.Output, args: ["searchOpen"] }], assistantToggle: [{ type: i0.Output, args: ["assistantToggle"] }], notificationsClick: [{ type: i0.Output, args: ["notificationsClick"] }], helpClick: [{ type: i0.Output, args: ["helpClick"] }], userMenuAction: [{ type: i0.Output, args: ["userMenuAction"] }], menuClick: [{ type: i0.Output, args: ["menuClick"] }] } });

const DEFAULT_LEGAL = [
    { label: 'Privacy', href: '/legal/privacy' },
    { label: 'Cookies', href: '/legal/cookies' },
    { label: 'Terms', href: '/legal/terms' },
];
/**
 * App shell — header, navigation and page area, following the window class:
 * - from 1200 px a standard 300 px NavigationDrawer that pushes the page; its menu button folds it to the 80 px rail;
 * - 600–1199 px the NavigationRail, whose menu button opens the drawer over the page (scrim);
 * - under 600 px the bottom NavigationBar (items with `bar: true`), the drawer opens from the header menu.
 *
 * ```html
 * <ait-app-shell [items]="nav" version="v4.5">
 *   <ait-app-header aitShellHeader [user]="me" />
 *   <router-outlet />
 * </ait-app-shell>
 * ```
 * Needs the router (`provideRouter`) for `route` items.
 */
class AitAppShell {
    windowClass = inject(AitWindowClass);
    items = input.required(...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** Destinations pinned to the bottom of the drawer and rail (Settings). */
    bottomItems = input([], ...(ngDevMode ? [{ debugName: "bottomItems" }] : /* istanbul ignore next */ []));
    legalLinks = input(DEFAULT_LEGAL, ...(ngDevMode ? [{ debugName: "legalLinks" }] : /* istanbul ignore next */ []));
    /** Shown in the drawer footer and under the rail, e.g. "v4.5". */
    version = input('', ...(ngDevMode ? [{ debugName: "version" }] : /* istanbul ignore next */ []));
    /** Start folded to the rail at Large widths (the choice should be remembered per user). */
    collapsed = input(false, ...(ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []));
    /** Large+: the user folded the drawer to the rail. */
    folded = linkedSignal(() => this.collapsed(), ...(ngDevMode ? [{ debugName: "folded" }] : /* istanbul ignore next */ []));
    /** Over-mode drawer open (rail menu, header menu). */
    overlayOpen = signal(false, ...(ngDevMode ? [{ debugName: "overlayOpen" }] : /* istanbul ignore next */ []));
    nav = this.windowClass.navigation;
    /** drawer · rail · bar — what is on screen. */
    layout = computed(() => (this.nav() === 'drawer' && this.folded() ? 'rail' : this.nav()), ...(ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []));
    drawerMode = computed(() => (this.nav() === 'drawer' && !this.folded() ? 'side' : 'over'), ...(ngDevMode ? [{ debugName: "drawerMode" }] : /* istanbul ignore next */ []));
    drawerOpened = computed(() => (this.drawerMode() === 'side' ? true : this.overlayOpen()), ...(ngDevMode ? [{ debugName: "drawerOpened" }] : /* istanbul ignore next */ []));
    barItems = computed(() => {
        const flagged = this.items().filter((i) => i.bar);
        return (flagged.length ? flagged : this.items()).slice(0, 5);
    }, ...(ngDevMode ? [{ debugName: "barItems" }] : /* istanbul ignore next */ []));
    constructor() {
        inject(AitIconRegistry);
        // Leaving a window class closes a drawer that was open over the page.
        effect(() => {
            this.nav();
            this.overlayOpen.set(false);
        });
    }
    openDrawer() {
        if (this.drawerMode() === 'side')
            return;
        this.overlayOpen.set(true);
    }
    closeDrawer() {
        this.overlayOpen.set(false);
    }
    /** Menu button: at Large, folds or unfolds; below, opens or closes the drawer over the page. */
    toggleFromMenu() {
        if (this.nav() === 'drawer') {
            this.folded.update((v) => !v);
            this.overlayOpen.set(false);
        }
        else {
            this.overlayOpen.update((v) => !v);
        }
    }
    onOpenedChange(open) {
        if (this.drawerMode() === 'over')
            this.overlayOpen.set(open);
    }
    onNavigate() {
        if (this.drawerMode() === 'over')
            this.overlayOpen.set(false);
    }
    badgeText(n) {
        return !n || n <= 0 ? '' : n <= 9 ? String(n) : n <= 99 ? '9+' : '99+';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAppShell, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.25", type: AitAppShell, isStandalone: true, selector: "ait-app-shell", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, bottomItems: { classPropertyName: "bottomItems", publicName: "bottomItems", isSignal: true, isRequired: false, transformFunction: null }, legalLinks: { classPropertyName: "legalLinks", publicName: "legalLinks", isSignal: true, isRequired: false, transformFunction: null }, version: { classPropertyName: "version", publicName: "version", isSignal: true, isRequired: false, transformFunction: null }, collapsed: { classPropertyName: "collapsed", publicName: "collapsed", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class": "\"ait-app-shell--\" + layout()" }, classAttribute: "ait-app-shell" }, providers: [{ provide: AIT_SHELL, useExisting: forwardRef(() => AitAppShell) }], ngImport: i0, template: "<ng-content select=\"ait-app-header, [aitShellHeader]\" />\n\n<ng-template #icon let-item>\n  @if (item.icon) {\n    <mat-icon [svgIcon]=\"item.icon\" aria-hidden=\"true\" />\n  } @else if (item.fontIcon) {\n    <mat-icon [fontIcon]=\"item.fontIcon\" aria-hidden=\"true\" />\n  }\n</ng-template>\n\n<div class=\"body\">\n  @if (layout() === 'rail') {\n    <nav class=\"rail dt-nav\" aria-label=\"Primary\">\n      <button mat-icon-button type=\"button\" class=\"rail__menu\" [attr.aria-label]=\"nav() === 'drawer' ? 'Expand navigation' : 'Open navigation'\"\n        [attr.aria-expanded]=\"overlayOpen()\" (click)=\"toggleFromMenu()\">\n        <mat-icon svgIcon=\"ait:menu\" />\n      </button>\n      @for (item of items(); track item.label) {\n        @if (item.route) {\n          <a class=\"rail__item\" [routerLink]=\"item.route\" routerLinkActive=\"rail__item--active\" #rla=\"routerLinkActive\" [matTooltip]=\"item.label\" matTooltipPosition=\"right\" [matTooltipShowDelay]=\"500\"\n            [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [attr.aria-current]=\"rla.isActive ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n              @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        } @else {\n          <a class=\"rail__item\" [href]=\"item.href\" [class.rail__item--active]=\"item.active\" [matTooltip]=\"item.label\" matTooltipPosition=\"right\" [matTooltipShowDelay]=\"500\" [attr.aria-current]=\"item.active ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n              @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        }\n      }\n      <span class=\"spacer\"></span>\n      @for (item of bottomItems(); track item.label) {\n        @if (item.route) {\n          <a class=\"rail__item\" [routerLink]=\"item.route\" routerLinkActive=\"rail__item--active\" #rlb=\"routerLinkActive\" [attr.aria-current]=\"rlb.isActive ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        } @else {\n          <a class=\"rail__item\" [href]=\"item.href\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        }\n      }\n      <button type=\"button\" class=\"rail__item\" [matMenuTriggerFor]=\"legalMenu\" aria-haspopup=\"menu\">\n        <span class=\"rail__pill\"><mat-icon svgIcon=\"ait:shield\" aria-hidden=\"true\" /></span>\n        <span class=\"rail__label\">Privacy</span>\n      </button>\n      <mat-menu #legalMenu=\"matMenu\" xPosition=\"after\" yPosition=\"above\">\n        @for (link of legalLinks(); track link.href) {\n          <a mat-menu-item [href]=\"link.href\" target=\"_blank\" rel=\"noopener\">{{ link.label }}</a>\n        }\n      </mat-menu>\n      @if (version()) { <span class=\"rail__version\">{{ version() }}</span> }\n    </nav>\n  }\n\n  <mat-sidenav-container class=\"container\" [hasBackdrop]=\"drawerMode() === 'over'\">\n    <mat-sidenav class=\"drawer dt-nav\" [mode]=\"drawerMode()\" [opened]=\"drawerOpened()\" (openedChange)=\"onOpenedChange($event)\"\n      [autoFocus]=\"drawerMode() === 'over' ? 'first-tabbable' : false\" [disableClose]=\"drawerMode() === 'side'\">\n      <nav class=\"drawer__inner\" aria-label=\"Primary\">\n        <button mat-icon-button type=\"button\" class=\"drawer__menu\" (click)=\"toggleFromMenu()\"\n          [attr.aria-label]=\"drawerMode() === 'side' ? 'Collapse navigation to the rail' : 'Close navigation'\">\n          <mat-icon [svgIcon]=\"drawerMode() === 'side' ? 'ait:menu' : 'ait:close'\" />\n        </button>\n        <mat-nav-list>\n          @for (item of items(); track item.label) {\n            @if (item.section) {\n              <mat-divider class=\"drawer__divider\" />\n              <div class=\"drawer__section\">{{ item.section }}</div>\n            }\n            @if (item.route) {\n              <a mat-list-item [routerLink]=\"item.route\" routerLinkActive=\"dt-nav-active\" #rla=\"routerLinkActive\"\n                [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [activated]=\"rla.isActive\" [attr.aria-current]=\"rla.isActive ? 'page' : null\" (click)=\"onNavigate()\">\n                <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n                  @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n                <span matListItemTitle>{{ item.label }}</span>\n                @if (item.count != null) { <span matListItemMeta class=\"drawer__count\">{{ item.count }}</span> }\n              </a>\n            } @else {\n              <a mat-list-item [href]=\"item.href\" [class.dt-nav-active]=\"item.active\" [activated]=\"!!item.active\" [attr.aria-current]=\"item.active ? 'page' : null\" (click)=\"onNavigate()\">\n                <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n                  @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n                <span matListItemTitle>{{ item.label }}</span>\n                @if (item.count != null) { <span matListItemMeta class=\"drawer__count\">{{ item.count }}</span> }\n              </a>\n            }\n          }\n        </mat-nav-list>\n        <span class=\"spacer\"></span>\n        @if (bottomItems().length) {\n          <mat-nav-list>\n            @for (item of bottomItems(); track item.label) {\n              @if (item.route) {\n                <a mat-list-item [routerLink]=\"item.route\" routerLinkActive=\"dt-nav-active\" #rla2=\"routerLinkActive\" [activated]=\"rla2.isActive\"\n                  [attr.aria-current]=\"rla2.isActive ? 'page' : null\" (click)=\"onNavigate()\">\n                  <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n                  <span matListItemTitle>{{ item.label }}</span>\n                </a>\n              } @else {\n                <a mat-list-item [href]=\"item.href\">\n                  <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n                  <span matListItemTitle>{{ item.label }}</span>\n                </a>\n              }\n            }\n          </mat-nav-list>\n        }\n        <p class=\"drawer__footer\">\n          @for (link of legalLinks(); track link.href; let last = $last) {\n            <a [href]=\"link.href\" target=\"_blank\" rel=\"noopener\">{{ link.label }}</a>@if (!last || version()) { <span aria-hidden=\"true\"> \u00B7 </span> }\n          }\n          @if (version()) { <span>{{ version() }}</span> }\n        </p>\n      </nav>\n    </mat-sidenav>\n\n    <mat-sidenav-content class=\"content\">\n      <ng-content />\n    </mat-sidenav-content>\n  </mat-sidenav-container>\n</div>\n\n@if (layout() === 'bar') {\n  <nav class=\"bar dt-nav\" aria-label=\"Primary\">\n    @for (item of barItems(); track item.label) {\n      @if (item.route) {\n        <a class=\"bar__item\" [routerLink]=\"item.route\" routerLinkActive=\"bar__item--active\" #rla=\"routerLinkActive\"\n          [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [attr.aria-current]=\"rla.isActive ? 'page' : null\">\n          <span class=\"bar__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n            @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n          <span class=\"bar__label\">{{ item.label }}</span>\n        </a>\n      } @else {\n        <a class=\"bar__item\" [href]=\"item.href\" [class.bar__item--active]=\"item.active\" [attr.aria-current]=\"item.active ? 'page' : null\">\n          <span class=\"bar__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n          <span class=\"bar__label\">{{ item.label }}</span>\n        </a>\n      }\n    }\n  </nav>\n}\n", styles: [":host{display:flex;flex-direction:column;height:100vh;height:100dvh;background:var(--md-sys-color-surface);color:var(--md-sys-color-on-surface)}.body{flex:1;min-height:0;display:flex;gap:2px;padding-top:2px}.container{flex:1;min-width:0;height:100%;background:transparent}.content{background:var(--md-sys-color-surface)}.spacer{flex:1}.badge{position:absolute;top:-6px;right:-8px;min-width:16px;height:16px;padding:0 4px;box-sizing:border-box;border-radius:9999px;background:var(--md-sys-color-error);color:var(--md-sys-color-on-error);font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;text-align:center;box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.drawer{width:300px;border:0;border-radius:0 16px 16px 0;background:var(--md-sys-color-nav-container);color:var(--md-sys-color-on-surface-variant);--mat-list-list-item-one-line-container-height: 56px;--mat-list-active-indicator-shape: 16px;--mat-list-active-indicator-color: var(--md-sys-color-nav-active);--mat-list-list-item-label-text-color: var(--md-sys-color-on-surface-variant);--mat-list-list-item-label-text-font: var(--ait-font-ui);--mat-list-list-item-label-text-size: 14px;--mat-list-list-item-label-text-weight: 500;--mat-list-list-item-label-text-tracking: .1px;--mat-list-list-item-leading-icon-color: var(--md-sys-color-on-surface-variant)}.drawer__inner{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:12px}.drawer__menu{margin:0 0 4px 4px;color:var(--md-sys-color-on-surface-variant)}mat-nav-list{padding:0}.mat-mdc-list-item{border-radius:16px;margin-bottom:0}.mat-mdc-list-item.dt-nav-active{--mat-list-list-item-label-text-color: var(--md-sys-color-on-secondary-container);--mat-list-list-item-leading-icon-color: var(--md-sys-color-on-secondary-container);background:var(--md-sys-color-nav-active);box-shadow:inset 3px 0 0 var(--md-sys-color-primary)}.drawer__icon{position:relative;overflow:visible}.drawer__icon mat-icon{width:24px;height:24px}.drawer__count{font:var(--ait-type-label-medium);letter-spacing:.5px;color:inherit}.drawer__divider{margin:8px 16px 0;--mat-divider-color: var(--md-sys-color-outline-variant)}.drawer__section{padding:16px 16px 8px;font:var(--ait-type-label-medium);letter-spacing:.5px;color:var(--md-sys-color-on-surface-variant)}.drawer__footer{margin:24px 16px 4px;font:var(--ait-type-body-small);letter-spacing:.4px;color:var(--md-sys-color-on-surface-variant)}.drawer__footer a{color:inherit;text-decoration:underline}.rail{flex:none;width:80px;display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 0;box-sizing:border-box;background:var(--md-sys-color-nav-container);border-radius:0 16px 16px 0;overflow-y:auto}.rail__menu{color:var(--md-sys-color-on-surface-variant);margin-bottom:8px}.rail__item{display:flex;flex-direction:column;align-items:center;gap:4px;width:72px;padding:4px 0 8px;border:0;background:none;text-decoration:none;color:var(--md-sys-color-on-surface-variant);cursor:pointer;border-radius:16px}.rail__pill{position:relative;display:flex;align-items:center;justify-content:center;width:56px;height:32px;border-radius:16px}.rail__item:hover .rail__pill{background:color-mix(in srgb,var(--md-sys-color-primary) 6%,transparent)}.rail__item--active{color:var(--md-sys-color-on-secondary-container)}.rail__item--active .rail__pill,.rail__item--active:hover .rail__pill{background:var(--md-sys-color-nav-active);box-shadow:inset 3px 0 0 var(--md-sys-color-primary)}.rail__label{font:var(--ait-type-label-medium);letter-spacing:.5px;text-align:center;max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rail__version{font-family:var(--ait-font-body);font-size:10px;line-height:14px;color:var(--md-sys-color-on-surface-variant);margin-top:4px}.bar{flex:none;height:80px;display:flex;justify-content:space-around;align-items:center;padding:0 8px;background:var(--md-sys-color-nav-container)}.bar__item{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;text-decoration:none;color:var(--md-sys-color-on-surface-variant)}.bar__pill{position:relative;display:flex;align-items:center;justify-content:center;width:64px;height:32px;border-radius:16px}.bar__item--active{color:var(--md-sys-color-on-surface)}.bar__item--active .bar__pill{background:var(--md-sys-color-nav-active);box-shadow:inset 0 3px 0 var(--md-sys-color-primary)}.bar__label{font:var(--ait-type-label-medium);letter-spacing:.5px}.bar__item--active .bar__label{font-family:var(--ait-font-body);font-weight:600}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "component", type: MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { kind: "component", type: MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { kind: "component", type: MatSidenavContent, selector: "mat-sidenav-content" }, { kind: "component", type: MatNavList, selector: "mat-nav-list", exportAs: ["matNavList"] }, { kind: "component", type: MatListItem, selector: "mat-list-item, a[mat-list-item], button[mat-list-item]", inputs: ["activated"], exportAs: ["matListItem"] }, { kind: "directive", type: MatListItemIcon, selector: "[matListItemIcon]" }, { kind: "directive", type: MatListItemTitle, selector: "[matListItemTitle]" }, { kind: "directive", type: MatListItemMeta, selector: "[matListItemMeta]" }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "component", type: MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.25", ngImport: i0, type: AitAppShell, decorators: [{
            type: Component,
            args: [{ selector: 'ait-app-shell', changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        NgTemplateOutlet, RouterLink, RouterLinkActive, MatSidenavContainer, MatSidenav, MatSidenavContent, MatNavList, MatListItem,
                        MatListItemIcon, MatListItemTitle, MatListItemMeta, MatIcon, MatIconButton, MatDivider, MatMenu, MatMenuItem, MatMenuTrigger, MatTooltip,
                    ], providers: [{ provide: AIT_SHELL, useExisting: forwardRef(() => AitAppShell) }], host: { class: 'ait-app-shell', '[class]': '"ait-app-shell--" + layout()' }, template: "<ng-content select=\"ait-app-header, [aitShellHeader]\" />\n\n<ng-template #icon let-item>\n  @if (item.icon) {\n    <mat-icon [svgIcon]=\"item.icon\" aria-hidden=\"true\" />\n  } @else if (item.fontIcon) {\n    <mat-icon [fontIcon]=\"item.fontIcon\" aria-hidden=\"true\" />\n  }\n</ng-template>\n\n<div class=\"body\">\n  @if (layout() === 'rail') {\n    <nav class=\"rail dt-nav\" aria-label=\"Primary\">\n      <button mat-icon-button type=\"button\" class=\"rail__menu\" [attr.aria-label]=\"nav() === 'drawer' ? 'Expand navigation' : 'Open navigation'\"\n        [attr.aria-expanded]=\"overlayOpen()\" (click)=\"toggleFromMenu()\">\n        <mat-icon svgIcon=\"ait:menu\" />\n      </button>\n      @for (item of items(); track item.label) {\n        @if (item.route) {\n          <a class=\"rail__item\" [routerLink]=\"item.route\" routerLinkActive=\"rail__item--active\" #rla=\"routerLinkActive\" [matTooltip]=\"item.label\" matTooltipPosition=\"right\" [matTooltipShowDelay]=\"500\"\n            [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [attr.aria-current]=\"rla.isActive ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n              @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        } @else {\n          <a class=\"rail__item\" [href]=\"item.href\" [class.rail__item--active]=\"item.active\" [matTooltip]=\"item.label\" matTooltipPosition=\"right\" [matTooltipShowDelay]=\"500\" [attr.aria-current]=\"item.active ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n              @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        }\n      }\n      <span class=\"spacer\"></span>\n      @for (item of bottomItems(); track item.label) {\n        @if (item.route) {\n          <a class=\"rail__item\" [routerLink]=\"item.route\" routerLinkActive=\"rail__item--active\" #rlb=\"routerLinkActive\" [attr.aria-current]=\"rlb.isActive ? 'page' : null\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        } @else {\n          <a class=\"rail__item\" [href]=\"item.href\">\n            <span class=\"rail__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n            <span class=\"rail__label\">{{ item.label }}</span>\n          </a>\n        }\n      }\n      <button type=\"button\" class=\"rail__item\" [matMenuTriggerFor]=\"legalMenu\" aria-haspopup=\"menu\">\n        <span class=\"rail__pill\"><mat-icon svgIcon=\"ait:shield\" aria-hidden=\"true\" /></span>\n        <span class=\"rail__label\">Privacy</span>\n      </button>\n      <mat-menu #legalMenu=\"matMenu\" xPosition=\"after\" yPosition=\"above\">\n        @for (link of legalLinks(); track link.href) {\n          <a mat-menu-item [href]=\"link.href\" target=\"_blank\" rel=\"noopener\">{{ link.label }}</a>\n        }\n      </mat-menu>\n      @if (version()) { <span class=\"rail__version\">{{ version() }}</span> }\n    </nav>\n  }\n\n  <mat-sidenav-container class=\"container\" [hasBackdrop]=\"drawerMode() === 'over'\">\n    <mat-sidenav class=\"drawer dt-nav\" [mode]=\"drawerMode()\" [opened]=\"drawerOpened()\" (openedChange)=\"onOpenedChange($event)\"\n      [autoFocus]=\"drawerMode() === 'over' ? 'first-tabbable' : false\" [disableClose]=\"drawerMode() === 'side'\">\n      <nav class=\"drawer__inner\" aria-label=\"Primary\">\n        <button mat-icon-button type=\"button\" class=\"drawer__menu\" (click)=\"toggleFromMenu()\"\n          [attr.aria-label]=\"drawerMode() === 'side' ? 'Collapse navigation to the rail' : 'Close navigation'\">\n          <mat-icon [svgIcon]=\"drawerMode() === 'side' ? 'ait:menu' : 'ait:close'\" />\n        </button>\n        <mat-nav-list>\n          @for (item of items(); track item.label) {\n            @if (item.section) {\n              <mat-divider class=\"drawer__divider\" />\n              <div class=\"drawer__section\">{{ item.section }}</div>\n            }\n            @if (item.route) {\n              <a mat-list-item [routerLink]=\"item.route\" routerLinkActive=\"dt-nav-active\" #rla=\"routerLinkActive\"\n                [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [activated]=\"rla.isActive\" [attr.aria-current]=\"rla.isActive ? 'page' : null\" (click)=\"onNavigate()\">\n                <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n                  @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n                <span matListItemTitle>{{ item.label }}</span>\n                @if (item.count != null) { <span matListItemMeta class=\"drawer__count\">{{ item.count }}</span> }\n              </a>\n            } @else {\n              <a mat-list-item [href]=\"item.href\" [class.dt-nav-active]=\"item.active\" [activated]=\"!!item.active\" [attr.aria-current]=\"item.active ? 'page' : null\" (click)=\"onNavigate()\">\n                <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n                  @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n                <span matListItemTitle>{{ item.label }}</span>\n                @if (item.count != null) { <span matListItemMeta class=\"drawer__count\">{{ item.count }}</span> }\n              </a>\n            }\n          }\n        </mat-nav-list>\n        <span class=\"spacer\"></span>\n        @if (bottomItems().length) {\n          <mat-nav-list>\n            @for (item of bottomItems(); track item.label) {\n              @if (item.route) {\n                <a mat-list-item [routerLink]=\"item.route\" routerLinkActive=\"dt-nav-active\" #rla2=\"routerLinkActive\" [activated]=\"rla2.isActive\"\n                  [attr.aria-current]=\"rla2.isActive ? 'page' : null\" (click)=\"onNavigate()\">\n                  <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n                  <span matListItemTitle>{{ item.label }}</span>\n                </a>\n              } @else {\n                <a mat-list-item [href]=\"item.href\">\n                  <span matListItemIcon class=\"drawer__icon\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n                  <span matListItemTitle>{{ item.label }}</span>\n                </a>\n              }\n            }\n          </mat-nav-list>\n        }\n        <p class=\"drawer__footer\">\n          @for (link of legalLinks(); track link.href; let last = $last) {\n            <a [href]=\"link.href\" target=\"_blank\" rel=\"noopener\">{{ link.label }}</a>@if (!last || version()) { <span aria-hidden=\"true\"> \u00B7 </span> }\n          }\n          @if (version()) { <span>{{ version() }}</span> }\n        </p>\n      </nav>\n    </mat-sidenav>\n\n    <mat-sidenav-content class=\"content\">\n      <ng-content />\n    </mat-sidenav-content>\n  </mat-sidenav-container>\n</div>\n\n@if (layout() === 'bar') {\n  <nav class=\"bar dt-nav\" aria-label=\"Primary\">\n    @for (item of barItems(); track item.label) {\n      @if (item.route) {\n        <a class=\"bar__item\" [routerLink]=\"item.route\" routerLinkActive=\"bar__item--active\" #rla=\"routerLinkActive\"\n          [routerLinkActiveOptions]=\"{ exact: !!item.exact }\" [attr.aria-current]=\"rla.isActive ? 'page' : null\">\n          <span class=\"bar__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" />\n            @if (badgeText(item.badge)) { <span class=\"badge\" aria-hidden=\"true\">{{ badgeText(item.badge) }}</span> }</span>\n          <span class=\"bar__label\">{{ item.label }}</span>\n        </a>\n      } @else {\n        <a class=\"bar__item\" [href]=\"item.href\" [class.bar__item--active]=\"item.active\" [attr.aria-current]=\"item.active ? 'page' : null\">\n          <span class=\"bar__pill\"><ng-container *ngTemplateOutlet=\"icon; context: { $implicit: item }\" /></span>\n          <span class=\"bar__label\">{{ item.label }}</span>\n        </a>\n      }\n    }\n  </nav>\n}\n", styles: [":host{display:flex;flex-direction:column;height:100vh;height:100dvh;background:var(--md-sys-color-surface);color:var(--md-sys-color-on-surface)}.body{flex:1;min-height:0;display:flex;gap:2px;padding-top:2px}.container{flex:1;min-width:0;height:100%;background:transparent}.content{background:var(--md-sys-color-surface)}.spacer{flex:1}.badge{position:absolute;top:-6px;right:-8px;min-width:16px;height:16px;padding:0 4px;box-sizing:border-box;border-radius:9999px;background:var(--md-sys-color-error);color:var(--md-sys-color-on-error);font-family:var(--ait-font-body);font-weight:600;font-size:11px;line-height:16px;text-align:center;box-shadow:0 0 0 2px var(--md-sys-color-nav-container)}.drawer{width:300px;border:0;border-radius:0 16px 16px 0;background:var(--md-sys-color-nav-container);color:var(--md-sys-color-on-surface-variant);--mat-list-list-item-one-line-container-height: 56px;--mat-list-active-indicator-shape: 16px;--mat-list-active-indicator-color: var(--md-sys-color-nav-active);--mat-list-list-item-label-text-color: var(--md-sys-color-on-surface-variant);--mat-list-list-item-label-text-font: var(--ait-font-ui);--mat-list-list-item-label-text-size: 14px;--mat-list-list-item-label-text-weight: 500;--mat-list-list-item-label-text-tracking: .1px;--mat-list-list-item-leading-icon-color: var(--md-sys-color-on-surface-variant)}.drawer__inner{display:flex;flex-direction:column;min-height:100%;box-sizing:border-box;padding:12px}.drawer__menu{margin:0 0 4px 4px;color:var(--md-sys-color-on-surface-variant)}mat-nav-list{padding:0}.mat-mdc-list-item{border-radius:16px;margin-bottom:0}.mat-mdc-list-item.dt-nav-active{--mat-list-list-item-label-text-color: var(--md-sys-color-on-secondary-container);--mat-list-list-item-leading-icon-color: var(--md-sys-color-on-secondary-container);background:var(--md-sys-color-nav-active);box-shadow:inset 3px 0 0 var(--md-sys-color-primary)}.drawer__icon{position:relative;overflow:visible}.drawer__icon mat-icon{width:24px;height:24px}.drawer__count{font:var(--ait-type-label-medium);letter-spacing:.5px;color:inherit}.drawer__divider{margin:8px 16px 0;--mat-divider-color: var(--md-sys-color-outline-variant)}.drawer__section{padding:16px 16px 8px;font:var(--ait-type-label-medium);letter-spacing:.5px;color:var(--md-sys-color-on-surface-variant)}.drawer__footer{margin:24px 16px 4px;font:var(--ait-type-body-small);letter-spacing:.4px;color:var(--md-sys-color-on-surface-variant)}.drawer__footer a{color:inherit;text-decoration:underline}.rail{flex:none;width:80px;display:flex;flex-direction:column;align-items:center;gap:4px;padding:12px 0;box-sizing:border-box;background:var(--md-sys-color-nav-container);border-radius:0 16px 16px 0;overflow-y:auto}.rail__menu{color:var(--md-sys-color-on-surface-variant);margin-bottom:8px}.rail__item{display:flex;flex-direction:column;align-items:center;gap:4px;width:72px;padding:4px 0 8px;border:0;background:none;text-decoration:none;color:var(--md-sys-color-on-surface-variant);cursor:pointer;border-radius:16px}.rail__pill{position:relative;display:flex;align-items:center;justify-content:center;width:56px;height:32px;border-radius:16px}.rail__item:hover .rail__pill{background:color-mix(in srgb,var(--md-sys-color-primary) 6%,transparent)}.rail__item--active{color:var(--md-sys-color-on-secondary-container)}.rail__item--active .rail__pill,.rail__item--active:hover .rail__pill{background:var(--md-sys-color-nav-active);box-shadow:inset 3px 0 0 var(--md-sys-color-primary)}.rail__label{font:var(--ait-type-label-medium);letter-spacing:.5px;text-align:center;max-width:72px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.rail__version{font-family:var(--ait-font-body);font-size:10px;line-height:14px;color:var(--md-sys-color-on-surface-variant);margin-top:4px}.bar{flex:none;height:80px;display:flex;justify-content:space-around;align-items:center;padding:0 8px;background:var(--md-sys-color-nav-container)}.bar__item{flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;text-decoration:none;color:var(--md-sys-color-on-surface-variant)}.bar__pill{position:relative;display:flex;align-items:center;justify-content:center;width:64px;height:32px;border-radius:16px}.bar__item--active{color:var(--md-sys-color-on-surface)}.bar__item--active .bar__pill{background:var(--md-sys-color-nav-active);box-shadow:inset 0 3px 0 var(--md-sys-color-primary)}.bar__label{font:var(--ait-type-label-medium);letter-spacing:.5px}.bar__item--active .bar__label{font-family:var(--ait-font-body);font-weight:600}\n"] }]
        }], ctorParameters: () => [], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: true }] }], bottomItems: [{ type: i0.Input, args: [{ isSignal: true, alias: "bottomItems", required: false }] }], legalLinks: [{ type: i0.Input, args: [{ isSignal: true, alias: "legalLinks", required: false }] }], version: [{ type: i0.Input, args: [{ isSignal: true, alias: "version", required: false }] }], collapsed: [{ type: i0.Input, args: [{ isSignal: true, alias: "collapsed", required: false }] }] } });

/*
 * @aitoolbox/ui — public API.
 * Theme: import one of styles/aitoolbox-m3.scss (Angular Material 22, also 21) or styles/aitoolbox-m2.scss (21, M2 API).
 */
// Core

/**
 * Generated bundle index. Do not edit.
 */

export { AIT_BREAKPOINTS, AIT_COLORS, AIT_ICONS, AIT_SHELL, AIT_STATE_LABELS, AIT_TOKENS_VERSION, AitAi, AitAiChip, AitAppHeader, AitAppShell, AitBanner, AitBrandLoader, AitChatbotMark, AitConfirm, AitConfirmDialog, AitConstructorProgress, AitDanger, AitDialogTitle, AitDisabledReason, AitEmptyState, AitGuideLine, AitIconRegistry, AitLogLevel, AitLogo, AitPenOrbit, AitRun, AitRunRegistry, AitRunText, AitSearchAsk, AitSnackBar, AitSnackBarContent, AitStateMark, AitStatusChip, AitTonal, AitWindow, AitWindowClass, AitWorkingDots, aitUid, provideAitIcons };
//# sourceMappingURL=aitoolbox-ui.mjs.map

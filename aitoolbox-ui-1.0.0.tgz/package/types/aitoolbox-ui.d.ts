import * as _angular_core from '@angular/core';
import { InjectionToken } from '@angular/core';
import { MatSnackBarRef } from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import * as i1 from '@angular/material/tooltip';
import * as _aitoolbox_ui from '@aitoolbox/ui';

/** The four feedback states of the design system. Loading is not a state: it is `pending`. */
type AitState = 'success' | 'info' | 'warning' | 'error';
/** A state, or `pending` while a request has not resolved yet. */
type AitStateOrPending = AitState | 'pending';
/** Health shown by a StatusChip: the four states plus `unknown`. */
type AitHealth = AitState | 'unknown';
/** Default words for each state, used as accessible names when no label is given. */
declare const AIT_STATE_LABELS: Record<AitStateOrPending | 'unknown', string>;
/** Unique id prefix for SVG masks and ARIA relations, stable for the life of one component. */
declare function aitUid(prefix?: string): string;

/** AIToolbox colour roles, light and dark. In templates and styles use the CSS custom properties (`var(--md-sys-color-<role>)`) instead. */
declare const AIT_COLORS: {
    readonly primary: {
        readonly light: "#35307e";
        readonly dark: "#c4c0ff";
    };
    readonly "on-primary": {
        readonly light: "#ffffff";
        readonly dark: "#2a2473";
    };
    readonly "primary-container": {
        readonly light: "#e3dfff";
        readonly dark: "#413c8a";
    };
    readonly "on-primary-container": {
        readonly light: "#14085e";
        readonly dark: "#e3dfff";
    };
    readonly secondary: {
        readonly light: "#514f71";
        readonly dark: "#c6c2ea";
    };
    readonly "on-secondary": {
        readonly light: "#ffffff";
        readonly dark: "#2e2d4d";
    };
    readonly "secondary-container": {
        readonly light: "#e3dfff";
        readonly dark: "#454364";
    };
    readonly "on-secondary-container": {
        readonly light: "#191836";
        readonly dark: "#e3dfff";
    };
    readonly tertiary: {
        readonly light: "#005232";
        readonly dark: "#00f29e";
    };
    readonly run: {
        readonly light: "#0d0b14";
        readonly dark: "#ece5f8";
    };
    readonly "on-run": {
        readonly light: "#ffffff";
        readonly dark: "#14121e";
    };
    readonly "run-icon": {
        readonly light: "#00f29e";
        readonly dark: "#006c44";
    };
    readonly "on-tertiary": {
        readonly light: "#ffffff";
        readonly dark: "#002111";
    };
    readonly "tertiary-container": {
        readonly light: "#50ffaf";
        readonly dark: "#005232";
    };
    readonly "on-tertiary-container": {
        readonly light: "#002111";
        readonly dark: "#50ffaf";
    };
    readonly error: {
        readonly light: "#93000a";
        readonly dark: "#ffb4ab";
    };
    readonly "on-error": {
        readonly light: "#ffffff";
        readonly dark: "#690005";
    };
    readonly "error-container": {
        readonly light: "#ffdad6";
        readonly dark: "#93000a";
    };
    readonly "on-error-container": {
        readonly light: "#410002";
        readonly dark: "#ffdad6";
    };
    readonly surface: {
        readonly light: "#fdf8fd";
        readonly dark: "#14121e";
    };
    readonly "on-surface": {
        readonly light: "#1c1b1e";
        readonly dark: "#ece5f8";
    };
    readonly "surface-variant": {
        readonly light: "#e6e0ec";
        readonly dark: "#494458";
    };
    readonly "on-surface-variant": {
        readonly light: "#48454e";
        readonly dark: "#cac3dc";
    };
    readonly "surface-dim": {
        readonly light: "#ddd9dd";
        readonly dark: "#14121e";
    };
    readonly "surface-bright": {
        readonly light: "#fdf8fd";
        readonly dark: "#484553";
    };
    readonly "nav-container": {
        readonly light: "#ede4ff";
        readonly dark: "#1d1a27";
    };
    readonly "nav-active": {
        readonly light: "#d4d0f9";
        readonly dark: "#454364";
    };
    readonly "surface-container-lowest": {
        readonly light: "#ffffff";
        readonly dark: "#0f0c19";
    };
    readonly "surface-container-low": {
        readonly light: "#faf4ff";
        readonly dark: "#1d1a27";
    };
    readonly "surface-container": {
        readonly light: "#f8f1ff";
        readonly dark: "#23202d";
    };
    readonly "surface-container-high": {
        readonly light: "#f2ebfa";
        readonly dark: "#2b2836";
    };
    readonly "surface-container-highest": {
        readonly light: "#ece5f4";
        readonly dark: "#363341";
    };
    readonly outline: {
        readonly light: "#79757f";
        readonly dark: "#948da5";
    };
    readonly "outline-variant": {
        readonly light: "#cac4cf";
        readonly dark: "#494458";
    };
    readonly "inverse-surface": {
        readonly light: "#313033";
        readonly dark: "#e6dff2";
    };
    readonly "inverse-on-surface": {
        readonly light: "#f4eff4";
        readonly dark: "#322e3c";
    };
    readonly "inverse-primary": {
        readonly light: "#c4c0ff";
        readonly dark: "#413c8a";
    };
    readonly scrim: {
        readonly light: "#000000";
        readonly dark: "#000000";
    };
    readonly shadow: {
        readonly light: "#000000";
        readonly dark: "#000000";
    };
    readonly ai: {
        readonly light: "#80d5d4";
        readonly dark: "#80d5d4";
    };
    readonly "on-ai": {
        readonly light: "#003737";
        readonly dark: "#003737";
    };
    readonly "ai-container": {
        readonly light: "#9cf1f0";
        readonly dark: "#004f50";
    };
    readonly "on-ai-container": {
        readonly light: "#002020";
        readonly dark: "#9cf1f0";
    };
    readonly "focus-ring": {
        readonly light: "#35307e";
        readonly dark: "#c4c0ff";
    };
    readonly "ai-strong": {
        readonly light: "#006a6a";
        readonly dark: "#80d5d4";
    };
    readonly "logo-box": {
        readonly light: "#0d0b14";
        readonly dark: "#c4c0ff";
    };
    readonly "on-logo-box": {
        readonly light: "#ffffff";
        readonly dark: "#0d0b14";
    };
    readonly "logo-cursor": {
        readonly light: "#00f29e";
        readonly dark: "#006c44";
    };
    readonly success: {
        readonly light: "#1b5f1f";
        readonly dark: "#91d888";
    };
    readonly "on-success": {
        readonly light: "#ffffff";
        readonly dark: "#003908";
    };
    readonly "success-container": {
        readonly light: "#acf4a2";
        readonly dark: "#0b5314";
    };
    readonly "on-success-container": {
        readonly light: "#002203";
        readonly dark: "#acf4a2";
    };
    readonly warning: {
        readonly light: "#6a4e00";
        readonly dark: "#fcbc00";
    };
    readonly "on-warning": {
        readonly light: "#ffffff";
        readonly dark: "#402d00";
    };
    readonly "warning-container": {
        readonly light: "#ffdea0";
        readonly dark: "#5c4300";
    };
    readonly "on-warning-container": {
        readonly light: "#261900";
        readonly dark: "#ffdea0";
    };
};
type AitColorRole = keyof typeof AIT_COLORS;
/** Version of the design-system token set this library was built from. */
declare const AIT_TOKENS_VERSION = "4.5.0";

/**
 * The outlined icons the UI Components use internally (24 px grid, 2 px stroke, currentColor), registered in the
 * `ait` namespace of MatIconRegistry: `<mat-icon svgIcon="ait:search">`. Static literals only; nothing user-provided.
 */
declare const AIT_ICONS: Record<string, string>;
/** Registers the `ait:` icons once per injector tree. The UI Components inject it themselves. */
declare class AitIconRegistry {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitIconRegistry, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AitIconRegistry>;
}
/** Registers the `ait:` icon set at startup, for apps that use `<mat-icon svgIcon="ait:…">` in their own templates. */
declare function provideAitIcons(): _angular_core.EnvironmentProviders;

declare const AIT_BREAKPOINTS: {
    readonly medium: 600;
    readonly expanded: 840;
    readonly large: 1200;
    readonly extraLarge: 1600;
};
declare const AitWindow: {
    readonly Compact: "(max-width: 599.98px)";
    readonly Medium: "(min-width: 600px) and (max-width: 839.98px)";
    readonly Expanded: "(min-width: 840px) and (max-width: 1199.98px)";
    readonly Large: "(min-width: 1200px) and (max-width: 1599.98px)";
    readonly ExtraLarge: "(min-width: 1600px)";
    readonly ShortHeight: "(max-height: 479.98px)";
};
type AitSizeClass = 'compact' | 'medium' | 'expanded' | 'large' | 'extra-large';
type AitNavigation = 'bar' | 'rail' | 'drawer';
type AitAssistantMode = 'full-screen' | 'in-place' | 'docked';
/** Current window class and the shell decisions that follow from it (signals). */
declare class AitWindowClass {
    private readonly observer;
    private readonly state;
    readonly windowClass: _angular_core.Signal<AitSizeClass>;
    readonly isCompact: _angular_core.Signal<boolean>;
    /** bottom NavigationBar under 600 px (rail on a phone in landscape), rail 600–1199 px, drawer from 1200 px. */
    readonly navigation: _angular_core.Signal<AitNavigation>;
    /** mat-sidenav mode for the drawer: side from 1200 px, over below. */
    readonly drawerMode: _angular_core.Signal<"side" | "over">;
    readonly assistantMode: _angular_core.Signal<AitAssistantMode>;
    /** forms in dialogs open full screen under 600 px or on a short screen. */
    readonly fullScreenDialogs: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitWindowClass, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AitWindowClass>;
}

/**
 * How the state mark is dressed, chosen by size:
 * - `badge` (A) alone on a surface, 24–40 px: snackbars, dialog headers, inline alerts, banners.
 * - `circle` (B) 56–96 px: empty states, table-, panel- or dialog-level errors.
 * - `tile` (C, filled) 18–20 px: table status columns, list rows, menu items.
 * - `tinted` (C, tinted) 18–20 px: inside a chip or alert that already carries the state container.
 * `pending` is not a dressing: set `state="pending"` and the mark shows the pen-orbit ring around the plain toolbox.
 */
type AitStateMarkVariant = 'badge' | 'circle' | 'tile' | 'tinted';
/**
 * StateMark — the feedback icon of the system: the logo's construction with the state in the corner badge.
 * Decorative by default (`aria-hidden`), because the word next to it carries the state; give it a `label` when it stands alone.
 *
 * ```html
 * <ait-state-mark state="error" variant="tile" /> Failed
 * <ait-state-mark state="warning" variant="badge" [size]="32" label="Warning" />
 * ```
 */
declare class AitStateMark {
    /** success · info · warning · error, or pending while a request runs. */
    readonly state: _angular_core.InputSignal<AitStateOrPending>;
    /** Dressing, chosen by size (see AitStateMarkVariant). Ignored while pending. */
    readonly variant: _angular_core.InputSignal<AitStateMarkVariant>;
    /** Height in px. Defaults: badge 24, circle 64, tile 20, tinted 18, pending 64. Never below 18. */
    readonly size: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    /** Accessible name. Leave empty when a visible word next to the mark already says the state. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly uid: string;
    protected readonly shape: _angular_core.Signal<"pending" | AitStateMarkVariant>;
    protected readonly resolvedSize: _angular_core.Signal<number>;
    /** Default word for the state, for callers that need it. */
    static labelFor(state: AitStateOrPending): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitStateMark, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitStateMark, "ait-state-mark", never, { "state": { "alias": "state"; "required": true; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * StatusChip — health on a `*-container` fill, led by the 18 px tinted tile glyph, never colour alone.
 * Built on `mat-chip` with the `dt-chip-*` classes of the theme files; not interactive.
 *
 * ```html
 * <ait-status-chip state="success">Healthy</ait-status-chip>
 * <ait-status-chip state="unknown">No data</ait-status-chip>
 * ```
 */
declare class AitStatusChip {
    /** success · warning · error · info, or unknown (outline dot on surface-container-highest). */
    readonly state: _angular_core.InputSignal<AitHealth>;
    protected readonly chipClass: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitStatusChip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitStatusChip, "ait-status-chip", never, { "state": { "alias": "state"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
/** Log level word in a Trace or log view: only the word is coloured (Open Sans 600). */
declare class AitLogLevel {
    readonly level: _angular_core.InputSignal<"DEBUG" | "INFO" | "WARN" | "ERR">;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitLogLevel, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitLogLevel, "ait-log-level", never, { "level": { "alias": "level"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Pen orbit — the circular indicator of the Constructor family (skin of `mat-progress-spinner`): a violet arc with
 * the teal pen at its head on a faint primary-container track. 48 px in content, 24 px inline, 18 px inside a button.
 * Indeterminate by default; give `value` (0–100) for a determinate arc.
 */
declare class AitPenOrbit {
    /** 48 (content) · 24 (inline) · 18 (inside a button). */
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    /** 0–100 for a determinate arc; leave unset for indeterminate. */
    readonly value: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    protected readonly stroke: _angular_core.Signal<5 | 4>;
    protected readonly pen: _angular_core.Signal<4.5 | 3.6>;
    /** Arc length in degrees: 190° while indeterminate, the value otherwise. */
    protected readonly sweep: _angular_core.Signal<number>;
    protected readonly headAngle: _angular_core.Signal<number>;
    protected readonly dash: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitPenOrbit, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitPenOrbit, "ait-pen-orbit", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Guide line — the linear indicator (skin of `mat-progress-bar`): a dashed teal construction guide, the violet bar
 * runs along it with the pen on its leading edge. Indeterminate by default; `value` (0–100) for determinate.
 */
declare class AitGuideLine {
    readonly value: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    protected readonly clamped: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitGuideLine, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitGuideLine, "ait-guide-line", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Working dots — three dots on a 1.4 s rhythm. The colour says who works: `run` (green, a command executes) or
 * `ai` (teal, a model is thinking). Inline after a log line or a chat message.
 */
declare class AitWorkingDots {
    readonly kind: _angular_core.InputSignal<"run" | "ai">;
    readonly label: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitWorkingDots, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitWorkingDots, "ait-working-dots", never, { "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Constructor determinate — long operations with a known value (install, deploy, migration): the pen draws the box in
 * proportion to progress and at 100 % the toolbox fills. 64–96 px in dialogs and empty states.
 */
declare class AitConstructorProgress {
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Height in px, 64–96. */
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    protected readonly clamped: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitConstructorProgress, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitConstructorProgress, "ait-constructor-progress", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Brand loader "Constructor" — app-level waits only (boot, workspace switch), never inside a screen. The AI tag comes
 * in, construction guides appear, a teal pen draws the toolbox in one trip and the night box becomes solid; 4.8 s loop.
 * `once` plays one time and stays on the logo (splash). 96 px for splash and workspace boot, 40 px minimum.
 * Under reduced motion it shows the finished logo; the label carries the state.
 */
declare class AitBrandLoader {
    /** Height in px: 96 for splash and workspace boot, 40 minimum. */
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Play one time and stay on the logo. */
    readonly once: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** Visible label under the loader, e.g. "Preparing your toolbox…". */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly uid: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitBrandLoader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitBrandLoader, "ait-brand-loader", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "once": { "alias": "once"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * - `horizontal` default lockup (clear space included) · `stacked` square slots and splash screens
 * - `mark` the toolbox prompt with the AI badge, from 24 px · `mark-plain` without the badge, under 24 px
 * - `wordmark` "AIToolbox", outlined (never retyped)
 */
type AitLogoVariant = 'horizontal' | 'stacked' | 'mark' | 'mark-plain' | 'wordmark';
/**
 * Logo — the toolbox-prompt mark and its lockups, drawn from the design-system files with the logo tokens, so it is the
 * night box on light grounds and the lavender box on dark grounds without picking a file.
 * Under 32 px use the favicon (assets/logos/favicon-*.svg) instead of the mark.
 */
declare class AitLogo {
    readonly variant: _angular_core.InputSignal<AitLogoVariant>;
    /** Rendered height in px. Defaults: horizontal 44, stacked 96, mark 32, mark-plain 24, wordmark 24. */
    readonly size: _angular_core.InputSignalWithTransform<number | undefined, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    protected readonly uid: string;
    protected readonly height: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitLogo, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitLogo, "ait-logo", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
/**
 * Chatbot mark — the assistant's avatar, the `{ >_ }` brace box drawn as one outline. Never the brand mark, never below
 * 24 px: 24 in a message, 32 in the assistant header, 48 in a launcher.
 */
declare class AitChatbotMark {
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    /** Accessible name; empty when a visible label sits next to it. */
    readonly label: _angular_core.InputSignal<string>;
    protected readonly px: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitChatbotMark, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitChatbotMark, "ait-chatbot-mark", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Counts the Run buttons on screen so a second one is reported in development (INV-DS-02). */
declare class AitRunRegistry {
    private readonly active;
    add(el: HTMLElement): void;
    delete(el: HTMLElement): void;
    get count(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitRunRegistry, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AitRunRegistry>;
}
/**
 * Run — the ONE action per screen that starts work (Run, Deploy, Apply, New run): the night "terminal" button with the
 * neon play icon. Use on a filled Material button, with a leading icon:
 *
 * ```html
 * <button mat-flat-button aitRun><mat-icon svgIcon="ait:play" />Request Run</button>
 * ```
 * Never inside a dialog (confirm there with a filled primary button). Development builds warn on both mistakes.
 */
declare class AitRun {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitRun, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitRun, "[aitRun]", never, {}, {}, never, never, true, never>;
}
/** Repeated run actions (table rows, cards): a text button in on-surface with the tertiary play icon, never filled. */
declare class AitRunText {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitRunText, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitRunText, "[aitRunText]", never, {}, {}, never, never, true, never>;
}
/** Tonal button (secondary-container) beside a filled one. Works on M2 and M3: `<button mat-flat-button aitTonal>`. */
declare class AitTonal {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitTonal, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitTonal, "[aitTonal]", never, {}, {}, never, never, true, never>;
}
/** Destructive action: a text button in error, never a filled red. `<button mat-button aitDanger>Delete</button>` */
declare class AitDanger {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitDanger, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitDanger, "[aitDanger]", never, {}, {}, never, never, true, never>;
}
/** AI-powered features only (teal), always with the sparkle icon: buttons, chips, cards. */
declare class AitAi {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitAi, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitAi, "[aitAi]", never, {}, {}, never, never, true, never>;
}

/**
 * AI chip — marks content a model produced (`ai-container` + sparkle). Only AI features may use it.
 * `<ait-ai-chip>Generated by ui-design</ait-ai-chip>`
 */
declare class AitAiChip {
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitAiChip, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitAiChip, "ait-ai-chip", never, {}, {}, never, ["*"], true, never>;
}

/**
 * Empty or error state of a page, panel or table: the circle state mark (56–96 px), a title, the cause and the way out.
 * While the request is pending the same slot shows the pending ring, so nothing moves when it resolves.
 *
 * ```html
 * <ait-empty-state state="error" title="Runs could not load" cause="The run service did not answer in 10 s.">
 *   <button mat-flat-button (click)="retry()">Retry</button>
 * </ait-empty-state>
 * ```
 */
declare class AitEmptyState {
    readonly state: _angular_core.InputSignal<AitStateOrPending>;
    readonly title: _angular_core.InputSignal<string>;
    readonly cause: _angular_core.InputSignal<string>;
    /** 56–64 inside a table or panel, 72–96 for a whole page. */
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    protected readonly isPending: _angular_core.Signal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitEmptyState, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitEmptyState, "ait-empty-state", never, { "state": { "alias": "state"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "cause": { "alias": "cause"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Banner — an inline alert on the state container strip, led by the 28 px state mark (badge). Errors are announced
 * (`role="alert"`), the other states are polite (`role="status"`). Actions are projected text buttons marked `aitBannerAction`.
 *
 * ```html
 * <ait-banner state="warning" heading="Changes requested.">Revision 3 is queued as run-0150.</ait-banner>
 * ```
 */
declare class AitBanner {
    readonly state: _angular_core.InputSignal<AitState>;
    readonly heading: _angular_core.InputSignal<string>;
    readonly dismissible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly dismissed: _angular_core.OutputEmitterRef<void>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitBanner, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitBanner, "ait-banner", never, { "state": { "alias": "state"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; }, { "dismissed": "dismissed"; }, never, ["*", "[aitBannerAction]"], true, never>;
}

interface AitSnackBarOptions {
    /** Leading 24 px state mark. Omit for a neutral confirmation. */
    state?: AitState;
    /** One optional action, in inverse-primary. */
    action?: string;
    /** 4–10 s; defaults to 6 s, or no auto-dismiss when there is an action the user must be able to reach. */
    duration?: number;
    /** Show a close icon button. */
    closable?: boolean;
}
interface AitSnackBarData extends AitSnackBarOptions {
    message: string;
}
/** Content of the AIToolbox snackbar. Opened through AitSnackBar; not used directly. */
declare class AitSnackBarContent {
    protected readonly data: AitSnackBarData;
    protected readonly ref: MatSnackBarRef<any>;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitSnackBarContent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitSnackBarContent, "ait-snack-bar", never, {}, {}, never, never, true, never>;
}
/**
 * Snackbar with the design-system anatomy: inverse surface, 24 px state mark, one action. Never for an error that needs
 * a decision (use a dialog), never stacked (opening one replaces the previous).
 *
 * ```ts
 * inject(AitSnackBar).open('Design approved · implement Run requested', { state: 'success', action: 'View design' });
 * ```
 */
declare class AitSnackBar {
    private readonly snackBar;
    open(message: string, options?: AitSnackBarOptions): MatSnackBarRef<AitSnackBarContent>;
    dismiss(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitSnackBar, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AitSnackBar>;
}

/**
 * Dialog title with the optional 32 px state mark of a state-driven popin (destructive confirm, warning).
 * `<h2 mat-dialog-title aitDialogTitle state="warning">Cancel run-0147?</h2>`
 */
declare class AitDialogTitle {
    readonly state: _angular_core.InputSignal<AitState | undefined>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitDialogTitle, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitDialogTitle, "[aitDialogTitle]", never, { "state": { "alias": "state"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
interface AitConfirmOptions {
    title: string;
    /** One or two sentences: what happens, and what is kept. */
    message: string;
    confirmLabel: string;
    dismissLabel?: string;
    /** Destructive confirm: a text button in error, never a filled red. */
    destructive?: boolean;
    /** 32 px state mark next to the title. Defaults to `warning` for destructive confirms. */
    state?: AitState;
}
declare class AitConfirmDialog {
    protected readonly data: AitConfirmOptions;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitConfirmDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitConfirmDialog, "ait-confirm-dialog", never, {}, {}, never, never, true, never>;
}
/**
 * Confirmation dialogs with the design-system rules: 280–560 px, headline-small title, text dismiss, filled primary
 * confirm, text-in-error confirm when destructive; focus starts on the dismiss button.
 *
 * ```ts
 * this.confirm.open({ title: 'Cancel run-0147?', message: '…', confirmLabel: 'Cancel Run', destructive: true })
 *   .subscribe(ok => ok && this.cancel());
 * ```
 */
declare class AitConfirm {
    private readonly dialog;
    private readonly windowClass;
    open(options: AitConfirmOptions): Observable<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitConfirm, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<AitConfirm>;
}

/**
 * Disabled reason (Tooltip E) — why an action is unavailable and how to unlock it, two lines at most, ending with the way
 * out. Pair it with Material's `disabledInteractive` so the button stays focusable and keyboard users get the reason:
 *
 * ```html
 * <button mat-flat-button disabled disabledInteractive aitDisabledReason="Choose a variant for every decision first.">
 *   Approve design
 * </button>
 * ```
 * The reason is also the button's accessible description (MatTooltip registers it with aria-describedby).
 */
declare class AitDisabledReason {
    readonly aitDisabledReason: _angular_core.InputSignal<string>;
    readonly aitDisabledReasonPosition: _angular_core.InputSignal<"above" | "below" | "left" | "right" | "before" | "after">;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitDisabledReason, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AitDisabledReason, "[aitDisabledReason]", never, { "aitDisabledReason": { "alias": "aitDisabledReason"; "required": true; "isSignal": true; }; "aitDisabledReasonPosition": { "alias": "aitDisabledReasonPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.MatTooltip; inputs: { "matTooltip": "aitDisabledReason"; "matTooltipPosition": "aitDisabledReasonPosition"; }; outputs: {}; }]>;
}

/** What the header needs from the shell around it (avoids a circular import between the two components). */
interface AitShellApi {
    openDrawer(): void;
    closeDrawer(): void;
}
declare const AIT_SHELL: InjectionToken<AitShellApi>;

/**
 * Search-or-ask field of the app header: 44 px, radius 16, on surface-container-lowest (light) / -high (dark).
 * Enter searches; the Ask chip (ai-container + Chatbot mark) sends the text to the assistant. ⌘K / Ctrl+K focuses it.
 * `compactAsk` shows the Ask chip as an icon (Medium and Expanded windows).
 */
declare class AitSearchAsk {
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Ask chip as a 36 px icon (Medium and Expanded windows). */
    readonly compactAsk: _angular_core.InputSignal<boolean>;
    /** When set, the Ask chip is disabled with this reason (Tooltip E). */
    readonly askDisabledReason: _angular_core.InputSignal<string>;
    readonly query: _angular_core.ModelSignal<string>;
    readonly search: _angular_core.OutputEmitterRef<string>;
    readonly ask: _angular_core.OutputEmitterRef<string>;
    protected readonly uid: string;
    protected readonly shortcut: string;
    private readonly field;
    constructor();
    /** Moves focus into the field. */
    focus(): void;
    protected onAsk(): void;
    protected onDocumentKey(e: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitSearchAsk, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitSearchAsk, "ait-search-ask", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "compactAsk": { "alias": "compactAsk"; "required": false; "isSignal": true; }; "askDisabledReason": { "alias": "askDisabledReason"; "required": false; "isSignal": true; }; "query": { "alias": "query"; "required": false; "isSignal": true; }; }, { "query": "queryChange"; "search": "search"; "ask": "ask"; }, never, never, true, never>;
}

interface AitUser {
    name: string;
    /** Shown under the name from 1200 px, e.g. "platform · admin". */
    role?: string;
    /** Two letters for the avatar; derived from the name when omitted. */
    initials?: string;
}
type AitUserMenuAction = 'account' | 'notifications' | 'tokens' | 'theme' | 'sign-out';
/** idle · typing (an answer is being written while the block is closed) · waiting (a reply waits to be read). */
type AitAssistantState = 'idle' | 'typing' | 'waiting';
/**
 * App header (TopAppBar) of the AIToolbox shell, on nav-container like the drawer. Left to right: logo · search-or-ask
 * field centred · assistant · notifications · help · user chip. Follows the window class:
 * under 600 px 56 px with menu · mark · search icon · bell · avatar; 600–1199 px search flexes, Ask as an icon, avatar
 * only (help from 840 px); from 1200 px 600 px search, labelled Ask, user chip with name and role.
 * ⌘J / Ctrl+J toggles the assistant.
 */
declare class AitAppHeader {
    private readonly windowClass;
    private readonly shell;
    private readonly searchField;
    readonly user: _angular_core.InputSignal<AitUser>;
    readonly notificationCount: _angular_core.InputSignal<number>;
    readonly assistant: _angular_core.InputSignal<AitAssistantState>;
    readonly assistantOpen: _angular_core.InputSignal<boolean>;
    readonly searchPlaceholder: _angular_core.InputSignal<string>;
    readonly askDisabledReason: _angular_core.InputSignal<string>;
    readonly homeLink: _angular_core.InputSignal<string | unknown[]>;
    readonly search: _angular_core.OutputEmitterRef<string>;
    readonly ask: _angular_core.OutputEmitterRef<string>;
    /** Compact windows: the search icon was pressed (open the full-screen search view). */
    readonly searchOpen: _angular_core.OutputEmitterRef<void>;
    readonly assistantToggle: _angular_core.OutputEmitterRef<void>;
    readonly notificationsClick: _angular_core.OutputEmitterRef<void>;
    readonly helpClick: _angular_core.OutputEmitterRef<void>;
    readonly userMenuAction: _angular_core.OutputEmitterRef<AitUserMenuAction>;
    /** Compact windows: the menu button was pressed. The AppShell opens its drawer by itself. */
    readonly menuClick: _angular_core.OutputEmitterRef<void>;
    protected readonly compact: _angular_core.Signal<boolean>;
    protected readonly wide: _angular_core.Signal<boolean>;
    protected readonly showHelp: _angular_core.Signal<boolean>;
    protected readonly shortcutJ: string;
    protected readonly initials: _angular_core.Signal<string>;
    protected readonly badge: _angular_core.Signal<string>;
    protected readonly bellLabel: _angular_core.Signal<string>;
    protected readonly assistantLabel: _angular_core.Signal<string>;
    protected readonly userLabel: _angular_core.Signal<string>;
    constructor();
    /** Moves focus into the search field (also bound to ⌘K / Ctrl+K). */
    focusSearch(): void;
    protected openNavigation(): void;
    protected onDocumentKey(e: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitAppHeader, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitAppHeader, "ait-app-header", never, { "user": { "alias": "user"; "required": true; "isSignal": true; }; "notificationCount": { "alias": "notificationCount"; "required": false; "isSignal": true; }; "assistant": { "alias": "assistant"; "required": false; "isSignal": true; }; "assistantOpen": { "alias": "assistantOpen"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "askDisabledReason": { "alias": "askDisabledReason"; "required": false; "isSignal": true; }; "homeLink": { "alias": "homeLink"; "required": false; "isSignal": true; }; }, { "search": "search"; "ask": "ask"; "searchOpen": "searchOpen"; "assistantToggle": "assistantToggle"; "notificationsClick": "notificationsClick"; "helpClick": "helpClick"; "userMenuAction": "userMenuAction"; "menuClick": "menuClick"; }, never, never, true, never>;
}

/** One destination of the navigation. */
interface AitNavItem {
    label: string;
    /** Registered SVG icon (`ait:runs`, `myset:deploy`) — or use `fontIcon` with a Material Symbols ligature. */
    icon?: string;
    fontIcon?: string;
    /** Router destination; `exact` matches the URL exactly. */
    route?: string | unknown[];
    exact?: boolean;
    /** Plain link when the destination is outside the app. */
    href?: string;
    /** Active state for `href` items (router items compute it). */
    active?: boolean;
    /** Trailing count in the drawer (label-medium). */
    count?: number | string;
    /** Unread or alert count: an error badge on the icon. */
    badge?: number;
    /** Starts a new group with an inset divider and this label. */
    section?: string;
    /** Show in the bottom NavigationBar on phones (3–5 destinations). */
    bar?: boolean;
}
interface AitLegalLink {
    label: string;
    href: string;
}
/**
 * App shell — header, navigation and page area, following the window class:
 * - from 1200 px a standard 300 px NavigationDrawer that pushes the page; its menu button folds it to the 80 px rail;
 * - 600–1199 px the NavigationRail, whose menu button opens the drawer over the page (scrim);
 * - under 600 px the bottom NavigationBar (items with `bar: true`), the drawer opens from the header menu.
 *
 * ```html
 * <ait-app-shell [items]="nav" version="v4.5">
 *   <ait-app-header aitShellHeader [user]="me" />
 *   <router-outlet />
 * </ait-app-shell>
 * ```
 * Needs the router (`provideRouter`) for `route` items.
 */
declare class AitAppShell implements AitShellApi {
    private readonly windowClass;
    readonly items: _angular_core.InputSignal<AitNavItem[]>;
    /** Destinations pinned to the bottom of the drawer and rail (Settings). */
    readonly bottomItems: _angular_core.InputSignal<AitNavItem[]>;
    readonly legalLinks: _angular_core.InputSignal<AitLegalLink[]>;
    /** Shown in the drawer footer and under the rail, e.g. "v4.5". */
    readonly version: _angular_core.InputSignal<string>;
    /** Start folded to the rail at Large widths (the choice should be remembered per user). */
    readonly collapsed: _angular_core.InputSignal<boolean>;
    /** Large+: the user folded the drawer to the rail. */
    protected readonly folded: _angular_core.WritableSignal<boolean>;
    /** Over-mode drawer open (rail menu, header menu). */
    protected readonly overlayOpen: _angular_core.WritableSignal<boolean>;
    protected readonly nav: _angular_core.Signal<_aitoolbox_ui.AitNavigation>;
    /** drawer · rail · bar — what is on screen. */
    protected readonly layout: _angular_core.Signal<_aitoolbox_ui.AitNavigation>;
    protected readonly drawerMode: _angular_core.Signal<"side" | "over">;
    protected readonly drawerOpened: _angular_core.Signal<boolean>;
    protected readonly barItems: _angular_core.Signal<AitNavItem[]>;
    constructor();
    openDrawer(): void;
    closeDrawer(): void;
    /** Menu button: at Large, folds or unfolds; below, opens or closes the drawer over the page. */
    protected toggleFromMenu(): void;
    protected onOpenedChange(open: boolean): void;
    protected onNavigate(): void;
    protected badgeText(n?: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AitAppShell, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AitAppShell, "ait-app-shell", never, { "items": { "alias": "items"; "required": true; "isSignal": true; }; "bottomItems": { "alias": "bottomItems"; "required": false; "isSignal": true; }; "legalLinks": { "alias": "legalLinks"; "required": false; "isSignal": true; }; "version": { "alias": "version"; "required": false; "isSignal": true; }; "collapsed": { "alias": "collapsed"; "required": false; "isSignal": true; }; }, {}, never, ["ait-app-header, [aitShellHeader]", "*"], true, never>;
}

export { AIT_BREAKPOINTS, AIT_COLORS, AIT_ICONS, AIT_SHELL, AIT_STATE_LABELS, AIT_TOKENS_VERSION, AitAi, AitAiChip, AitAppHeader, AitAppShell, AitBanner, AitBrandLoader, AitChatbotMark, AitConfirm, AitConfirmDialog, AitConstructorProgress, AitDanger, AitDialogTitle, AitDisabledReason, AitEmptyState, AitGuideLine, AitIconRegistry, AitLogLevel, AitLogo, AitPenOrbit, AitRun, AitRunRegistry, AitRunText, AitSearchAsk, AitSnackBar, AitSnackBarContent, AitStateMark, AitStatusChip, AitTonal, AitWindow, AitWindowClass, AitWorkingDots, aitUid, provideAitIcons };
export type { AitAssistantMode, AitAssistantState, AitColorRole, AitConfirmOptions, AitHealth, AitLegalLink, AitLogoVariant, AitNavItem, AitNavigation, AitShellApi, AitSizeClass, AitSnackBarOptions, AitState, AitStateMarkVariant, AitStateOrPending, AitUser, AitUserMenuAction };

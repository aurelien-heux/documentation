# AIToolbox · architecture update (2026-11-03)

Drop-in for the global toolbox package. Paths assume the brand package layout (`brand/feature-marks/<feature>/light|dark`).

| From this package | Into the toolbox zip | What changed |
|---|---|---|
| `brand/feature-marks/architecture/` | `brand/feature-marks/architecture/` (new) | Architecture feature mark: static, once, loop SVG and PNG 24–512 px, light and dark. Minimum 24 px. No lockup or GIF yet. |
| `design-system/README.md` | the design system's `README.md` | New "Feature marks" section (before "State marks"). Nothing else changed. |
| `design-system/assets/Features/README.md` | `assets/Features/README.md` (new) | The Features asset group: Architecture mark files and rules. |
| `architecture/architecture-meridian-bank.html` | the architecture HTML artifact | Architecture feature mockup, Catalogue / Views / Process with levels, Meridian Bank example, page fixes of 2026-11-03. Self-contained (LikeC4 views embedded). |
| `architecture/architecture-environments.html` | optional | Same page on the single-application environments example. |
| `architecture/architecture-change-process.html`, `wide-views-demo.html` | optional | Change process (TOGAF × toolbox × Git, parallel changes) and the wide-views demo. |

Also update the feature-marks index in the brand package (`brand/feature-marks/README.md` / `index.html`) with an Architecture row: once 1.6 s (layers drop in, links appear, dot pops), loop 2.8 s (links flow, layers dim in turn, dot beats).
